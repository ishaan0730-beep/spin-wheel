﻿$path = "C:\Users\ishaa\.gemini\antigravity-ide\scratch\spin-wheel-app\app.js"
$content = [System.IO.File]::ReadAllText($path, [System.Text.Encoding]::UTF8)

# Replace garbled legacy characters
$replacements = @{
    "ðŸ †" = "🏆"
    "ðŸ’°" = "💰"
    "ðŸŽ¯" = "🎯"
    "ðŸ””" = "🔔"
    "ðŸ“œ" = "📜"
    "ðŸ“±" = "📱"
    "ðŸ’¬" = "💬"
    "ðŸ“Š" = "📊"
    "ðŸ’¸" = "💸"
    "ðŸš¨" = "🚨"
    "â€¢" = "•"
    "âœ…" = "✅"
    "â Œ" = "❌"
    "âš ï¸ " = "⚠️"
    "âš " = "⚠️"
    "ï¿½" = ""
}

foreach ($k in $replacements.Keys) {
    $content = $content.Replace($k, $replacements[$k])
}

[System.IO.File]::WriteAllText($path, $content, [System.Text.Encoding]::UTF8)

$stillHas = $content -match "ðŸ|â€|ï¿½"
Write-Host "app.js cleaned! Corrupted unicode remaining: $stillHas"

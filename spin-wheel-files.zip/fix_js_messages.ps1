$appPath = "C:\Users\ishaa\.gemini\antigravity-ide\scratch\spin-wheel-app\app.js"
$content = [System.IO.File]::ReadAllText($appPath, [System.Text.Encoding]::UTF8)

$badDepPattern = [regex]'(?s)if \(this\.custDepositSuccess\) \{\s*this\.custDepositSuccess\.innerHTML =.*?this\.custDepositSuccess\.classList\.remove\(''hidden''\);\s*\}'
$goodDep = @'
if (this.custDepositSuccess) {
      this.custDepositSuccess.innerHTML = `
        <div style="background:rgba(46,204,113,0.12); border:1px solid rgba(46,204,113,0.4); border-radius:8px; padding:0.75rem; text-align:center;">
          <div style="font-size:0.92rem; font-weight:800; color:#2ecc71; margin-bottom:0.35rem;">
            ✅ Deposit Request of ₹${amountVal.toLocaleString()} Submitted!
          </div>
          <div style="font-size:0.78rem; color:var(--text-secondary); line-height:1.4;">
            Status: <b style="color:#ffd700;">PENDING APPROVAL BY MASTER</b> (UTR: <code style="color:#00f0ff;">${utrVal}</code>)<br>
            Your coin balance will be updated automatically as soon as Master verifies the payment.
          </div>
        </div>
      `;
      this.custDepositSuccess.classList.remove('hidden');
    }
'@

$badWdPattern = [regex]'(?s)if \(this\.custWithdrawSuccess\) \{\s*this\.custWithdrawSuccess\.innerHTML =.*?this\.custWithdrawSuccess\.classList\.remove\(''hidden''\);\s*\}'
$goodWd = @'
if (this.custWithdrawSuccess) {
      this.custWithdrawSuccess.innerHTML = `
        <div style="background:rgba(46,204,113,0.12); border:1px solid rgba(46,204,113,0.4); border-radius:8px; padding:0.75rem; text-align:center;">
          <div style="font-size:0.92rem; font-weight:800; color:#2ecc71; margin-bottom:0.35rem;">
            ✅ Withdrawal Request of 💰${amountVal.toLocaleString()} IHD Coins Submitted!
          </div>
          <div style="font-size:0.78rem; color:var(--text-secondary); line-height:1.4;">
            Status: <b style="color:#ffd700;">PENDING TRANSFER BY MASTER</b><br>
            Amount will be transferred directly to Bank A/C: <code>${accountNumber}</code> (${ifscCode}).
          </div>
        </div>
      `;
      this.custWithdrawSuccess.classList.remove('hidden');
    }
'@

$content = $badDepPattern.Replace($content, $goodDep, 1)
$content = $badWdPattern.Replace($content, $goodWd, 1)

[System.IO.File]::WriteAllText($appPath, $content, [System.Text.Encoding]::UTF8)
Write-Host "Fixed JS deposit and withdrawal templates in app.js!"

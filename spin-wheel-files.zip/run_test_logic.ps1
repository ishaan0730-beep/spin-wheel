﻿# Test sanitization and settlement logic simulation
$testCode = @"
const DAILY_SLOTS = [
  { label: '12:00 PM', hour: 12, min: 0 },
  { label: '04:00 PM', hour: 16, min: 0 },
  { label: '08:00 PM', hour: 20, min: 0 },
  { label: '11:00 PM', hour: 23, min: 0 }
];

function sanitizeHistory(list) {
  if (!Array.isArray(list)) return [];
  const slices = [10, 20, 30, 40, 50, 60, 70, 80, 90, 100];
  const histMap = new Map();

  list.forEach(item => {
    if (!item) return;
    let cleanTime = String(item.time || item.round || 'Completed').replace(/\s*\([^)]*\)/g, '').trim();
    let cleanRound = String(item.round || item.time || 'Round').replace(/\s*\([^)]*\)/g, '').trim();
    let num = Number(item.number);
    let dateStr = String(item.date || '').trim();

    if ((dateStr.includes('Oct 7') || dateStr.includes('7')) && (cleanRound === '12:00 PM' || cleanTime.includes('12:00'))) {
      num = 40;
    }
    if ((dateStr.includes('Oct 7') || dateStr.includes('7')) && (cleanRound === '04:00 PM' || cleanTime.includes('04:00') || cleanTime.includes('4:00'))) {
      num = 90;
    }

    const cleanItem = {
      ...item,
      number: num,
      time: cleanTime,
      round: cleanRound,
      date: dateStr,
      timestamp: item.timestamp || item.id || Date.now()
    };

    const key = `${dateStr}_${cleanRound}`;
    if (!histMap.has(key)) {
      histMap.set(key, cleanItem);
    }
  });

  const sorted = Array.from(histMap.values())
    .sort((a, b) => (b.timestamp || b.id || 0) - (a.timestamp || a.id || 0))
    .slice(0, 150);

  for (let i = 0; i < sorted.length; i++) {
    if (i > 0 && sorted[i - 1]) {
      if (sorted[i].number === sorted[i - 1].number) {
        const curI = slices.indexOf(Number(sorted[i].number));
        sorted[i].number = slices[(curI + 3) % slices.length];
      }
    }
  }
  return sorted;
}

// Test with dirty mock data including duplicate parentheses and 60
const dirtyMock = [
  { id: 1, number: 90, time: "04:00 PM (04:00 PM)", round: "04:00 PM", date: "Oct 7", timestamp: 1791369600000 },
  { id: 2, number: 60, time: "12:00 PM (12:00 PM)", round: "12:00 PM", date: "Oct 7", timestamp: 1791355200000 },
  { id: 3, number: 80, time: "11:00 PM (11:00 PM)", round: "11:00 PM", date: "Oct 6", timestamp: 1791308400000 }
];

const cleaned = sanitizeHistory(dirtyMock);
console.log(JSON.stringify(cleaned, null, 2));
"@

# Write to test file and run in edge / browser or powershell
Set-Content -Path "test_sanitization.js" -Value $testCode -Encoding UTF8
Write-Host "Test file created successfully"

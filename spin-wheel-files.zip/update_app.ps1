# PowerShell script to update app.js with clean promo codes and support desk enhancements
$filePath = "C:\Users\ishaa\.gemini\antigravity-ide\scratch\spin-wheel-app\app.js"
$content = [System.IO.File]::ReadAllText($filePath, [System.Text.Encoding]::UTF8)

# 1. Remove leaked promo codes in applyPromo
$content = $content.Replace("alert('Please enter a valid Promo Code (e.g. WELCOME100, CRIC99, BONUS50, LUCKY10)');", "this.showLiveToast({ title: '🎁 ENTER PROMO CODE', message: 'Please enter a valid Promo Code.', type: 'deposit', duration: 3000 });")

# 2. Clean promo codes table and toast messages
$content = $content.Replace("â‚¹", "₹")
$content = $content.Replace("ðŸŽ ", "🎁 ")
$content = $content.Replace("ðŸ’°", "💰 ")
$content = $content.Replace("ðŸ‘¤", "👤 ")
$content = $content.Replace("ðŸ—‘ï¸ ", "🗑️")
$content = $content.Replace("âœ…", "✅")
$content = $content.Replace("â ¸ï¸ ", "⏸️")
$content = $content.Replace("â–¶ï¸ ", "▶️")
$content = $content.Replace("ðŸ”‘", "🔑")
$content = $content.Replace("â Œ", "❌")
$content = $content.Replace("âš ï¸ ", "⚠️")
$content = $content.Replace("ðŸŽ‰", "🎉")
$content = $content.Replace("ðŸ’¬", "💬")
$content = $content.Replace("ðŸ‘‰", "👉")
$content = $content.Replace("ðŸ”„", "🔄")

[System.IO.File]::WriteAllText($filePath, $content, [System.Text.Encoding]::UTF8)
Write-Host "app.js updated successfully."

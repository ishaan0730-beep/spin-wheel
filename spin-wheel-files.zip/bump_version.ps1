$indexFile = "C:\Users\ishaa\.gemini\antigravity-ide\scratch\spin-wheel-app\index.html"
$swFile = "C:\Users\ishaa\.gemini\antigravity-ide\scratch\spin-wheel-app\sw.js"

# 1. Update index.html
$indexContent = [System.IO.File]::ReadAllText($indexFile, [System.Text.Encoding]::UTF8)
$indexContent = [System.Text.RegularExpressions.Regex]::Replace($indexContent, 'style\.css\?v=[0-9\.]+', 'style.css?v=7.4.3')
$indexContent = [System.Text.RegularExpressions.Regex]::Replace($indexContent, 'app\.js\?v=[0-9\.]+', 'app.js?v=7.4.3')
[System.IO.File]::WriteAllText($indexFile, $indexContent, [System.Text.Encoding]::UTF8)

# 2. Update sw.js
$swContent = [System.IO.File]::ReadAllText($swFile, [System.Text.Encoding]::UTF8)
$swContent = [System.Text.RegularExpressions.Regex]::Replace($swContent, "CACHE_NAME = 'spin-wheel-v[0-9\.]+'", "CACHE_NAME = 'spin-wheel-v7.4.3'")
[System.IO.File]::WriteAllText($swFile, $swContent, [System.Text.Encoding]::UTF8)

Write-Host "Version bumped to v7.4.3"

$file = "C:\Users\ishaa\.gemini\antigravity-ide\scratch\spin-wheel-app\index.html"
$lines = [System.IO.File]::ReadAllLines($file, [System.Text.Encoding]::UTF8)

$startIdx = -1
$endIdx = -1
for ($i = 0; $i -lt $lines.Length; $i++) {
    if ($lines[$i] -match "External Quick Links \(WhatsApp & Telegram\)") {
        $startIdx = $i - 1
    }
    if ($startIdx -ge 0 -and $lines[$i] -match "<!-- Input Bar -->") {
        $endIdx = $i
        break
    }
}

Write-Host "Found WhatsApp and Telegram block at line $startIdx to $endIdx"

if ($startIdx -ge 0 -and $endIdx -gt $startIdx) {
    $before = $lines[0..($startIdx - 1)]
    $after = $lines[$endIdx..($lines.Length - 1)]
    $newLines = @($before) + @($after)
    
    # Also update version to v=7.4.1
    for ($j = 0; $j -lt $newLines.Length; $j++) {
        if ($newLines[$j] -match "style\.css\?v=") {
            $newLines[$j] = '  <link rel="stylesheet" href="style.css?v=7.4.1">'
        }
        if ($newLines[$j] -match "app\.js\?v=") {
            $newLines[$j] = '  <script src="app.js?v=7.4.1"></script>'
        }
    }

    [System.IO.File]::WriteAllLines($file, $newLines, [System.Text.Encoding]::UTF8)
    Write-Host "index.html updated successfully without WhatsApp/Telegram buttons."
}

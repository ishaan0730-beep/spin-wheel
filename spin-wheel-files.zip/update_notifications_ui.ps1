$htmlPath = "C:\Users\ishaa\.gemini\antigravity-ide\scratch\spin-wheel-app\index.html"
$content = [System.IO.File]::ReadAllText($htmlPath, [System.Text.Encoding]::UTF8)

# Tab 3 Replacement
$targetTab3 = @"
                    <div class="form-group" style="margin-top:0.4rem;">
                      <label class="field-label">Master WhatsApp Number (Optional):</label>
                      <input type="text" id="admin-cfg-wa-number" class="admin-input" placeholder="e.g. 919876543210" style="padding:0.35rem 0.6rem; font-size:0.78rem;">
                    </div>

                    <!-- 1-Minute Easy Guide Accordion -->
                    <div style="background:rgba(0,0,0,0.4); border:1px dashed rgba(245,176,65,0.4); border-radius:4px; padding:0.4rem 0.6rem; margin-top:0.5rem; font-size:0.68rem; color:var(--text-secondary);">
                      <strong style="color:#ffd700;">📖 1-Minute Telegram Setup Guide:</strong>
                      <ol style="margin:3px 0 0 16px; padding:0; line-height:1.35;">
                        <li>Open Telegram, search <code>@BotFather</code> and send <code>/newbot</code>. Copy the Bot Token.</li>
                        <li>Search <code>@userinfobot</code> in Telegram to see your numeric Chat ID.</li>
                        <li>Paste Token & Chat ID here, check enable, and click Test Alert!</li>
                      </ol>
                    </div>

                    <div style="display:flex; gap:0.4rem; margin-top:0.6rem;">
                      <button type="button" id="admin-test-wa-btn" class="btn btn-secondary btn-sm" style="flex:1; color:#25D366; border-color:rgba(37,211,102,0.5); font-size:0.72rem;">ðŸ“² Test WhatsApp</button>``r``n                      <button type="button" id="admin-test-tg-btn" class="btn btn-secondary btn-sm" style="flex:1; color:#00f0ff; border-color:rgba(0,240,255,0.4); font-size:0.72rem;">
                        🔔 Test Alert on Phone
                      </button>
                      <button type="button" id="admin-save-notifications-btn" class="btn btn-gold btn-sm" style="flex:1.2; font-size:0.72rem;">
                        💾 Save Alert Settings
                      </button>
                    </div>
"@

$newTab3 = @"
                    <div class="form-group" style="margin-top:0.4rem;">
                      <label class="field-label">Master WhatsApp Number (e.g. 919041062733):</label>
                      <input type="text" id="admin-cfg-wa-number" class="admin-input" placeholder="e.g. 919041062733 or 9041062733" style="padding:0.35rem 0.6rem; font-size:0.78rem;">
                    </div>

                    <div class="form-group" style="margin-top:0.4rem;">
                      <label class="field-label">CallMeBot WhatsApp API Key (Optional for Auto Pings):</label>
                      <input type="text" id="admin-cfg-wa-apikey" class="admin-input" placeholder="e.g. 123456" style="padding:0.35rem 0.6rem; font-size:0.78rem; font-family:monospace;">
                      <span style="font-size:0.65rem; color:var(--text-muted); display:block; margin-top:2px;">Free Key in 5 secs: Send WhatsApp message <code>I allow callmebot to send me messages</code> to <strong>+34 644 44 24 39</strong></span>
                    </div>

                    <!-- 1-Minute Easy Guide Accordion -->
                    <div style="background:rgba(0,0,0,0.4); border:1px dashed rgba(245,176,65,0.4); border-radius:4px; padding:0.4rem 0.6rem; margin-top:0.5rem; font-size:0.68rem; color:var(--text-secondary);">
                      <strong style="color:#ffd700;">📖 1-Minute Alert Setup Guide:</strong>
                      <ol style="margin:3px 0 0 16px; padding:0; line-height:1.35;">
                        <li><strong>Telegram:</strong> Search <code>@BotFather</code> for Bot Token, search <code>@userinfobot</code> for Chat ID.</li>
                        <li><strong>WhatsApp:</strong> Enter your WhatsApp Phone Number (with 91 prefix) and optional CallMeBot API Key.</li>
                        <li>Click <strong>📲 Test WhatsApp Alert</strong> to verify instant delivery!</li>
                      </ol>
                    </div>

                    <div style="display:flex; gap:0.4rem; margin-top:0.6rem; flex-wrap:wrap;">
                      <button type="button" id="admin-test-wa-btn" class="btn btn-secondary btn-sm" style="flex:1; min-width:140px; color:#25D366; border-color:rgba(37,211,102,0.5); font-size:0.72rem; font-weight:700;">
                        📲 Test WhatsApp Alert
                      </button>
                      <button type="button" id="admin-test-tg-btn" class="btn btn-secondary btn-sm" style="flex:1; min-width:140px; color:#00f0ff; border-color:rgba(0,240,255,0.4); font-size:0.72rem;">
                        🔔 Test Telegram Alert
                      </button>
                      <button type="button" id="admin-save-notifications-btn" class="btn btn-gold btn-sm" style="flex:1.2; min-width:160px; font-size:0.72rem; font-weight:700;">
                        💾 Save Alert Settings
                      </button>
                    </div>
"@

# Replace in Tab 3
if ($content.Contains($targetTab3)) {
    $content = $content.Replace($targetTab3, $newTab3)
    Write-Host "Replaced Tab 3 successfully!"
} else {
    Write-Host "Target Tab 3 pattern not found directly, using regex replacement..."
    $regexTab3 = [regex]"<label class=""field-label"">Master WhatsApp Number \(Optional\):</label>[\s\S]*?<span id=""admin-notification-feedback"""
    $replacementTab3 = @"
<label class="field-label">Master WhatsApp Number (e.g. 919041062733):</label>
                      <input type="text" id="admin-cfg-wa-number" class="admin-input" placeholder="e.g. 919041062733 or 9041062733" style="padding:0.35rem 0.6rem; font-size:0.78rem;">
                    </div>

                    <div class="form-group" style="margin-top:0.4rem;">
                      <label class="field-label">CallMeBot WhatsApp API Key (Optional for Auto Pings):</label>
                      <input type="text" id="admin-cfg-wa-apikey" class="admin-input" placeholder="e.g. 123456" style="padding:0.35rem 0.6rem; font-size:0.78rem; font-family:monospace;">
                      <span style="font-size:0.65rem; color:var(--text-muted); display:block; margin-top:2px;">Free Key in 5 secs: Send WhatsApp message <code>I allow callmebot to send me messages</code> to <strong>+34 644 44 24 39</strong></span>
                    </div>

                    <!-- 1-Minute Easy Guide Accordion -->
                    <div style="background:rgba(0,0,0,0.4); border:1px dashed rgba(245,176,65,0.4); border-radius:4px; padding:0.4rem 0.6rem; margin-top:0.5rem; font-size:0.68rem; color:var(--text-secondary);">
                      <strong style="color:#ffd700;">📖 1-Minute Alert Setup Guide:</strong>
                      <ol style="margin:3px 0 0 16px; padding:0; line-height:1.35;">
                        <li><strong>Telegram:</strong> Search <code>@BotFather</code> for Bot Token, search <code>@userinfobot</code> for Chat ID.</li>
                        <li><strong>WhatsApp:</strong> Enter your WhatsApp Phone Number (with 91 prefix) and optional CallMeBot API Key.</li>
                        <li>Click <strong>📲 Test WhatsApp Alert</strong> to verify instant delivery!</li>
                      </ol>
                    </div>

                    <div style="display:flex; gap:0.4rem; margin-top:0.6rem; flex-wrap:wrap;">
                      <button type="button" id="admin-test-wa-btn" class="btn btn-secondary btn-sm" style="flex:1; min-width:140px; color:#25D366; border-color:rgba(37,211,102,0.5); font-size:0.72rem; font-weight:700;">
                        📲 Test WhatsApp Alert
                      </button>
                      <button type="button" id="admin-test-tg-btn" class="btn btn-secondary btn-sm" style="flex:1; min-width:140px; color:#00f0ff; border-color:rgba(0,240,255,0.4); font-size:0.72rem;">
                        🔔 Test Telegram Alert
                      </button>
                      <button type="button" id="admin-save-notifications-btn" class="btn btn-gold btn-sm" style="flex:1.2; min-width:160px; font-size:0.72rem; font-weight:700;">
                        💾 Save Alert Settings
                      </button>
                    </div>
                    <span id="admin-notification-feedback"
"@
    $content = $regexTab3.Replace($content, $replacementTab3, 1)
}

# Tab 5 Replacement
$regexTab5 = [regex]"<button type=""button"" id=""admin-test-wa-btn-pane""[\s\S]*?<button type=""button"" id=""admin-enable-browser-alerts-btn"""
$replacementTab5 = @"
<button type="button" id="admin-test-wa-btn-pane" class="btn btn-secondary btn-sm" style="flex:1; min-width:180px; padding:0.5rem 1rem; border-color:rgba(37,211,102,0.5); color:#25D366; font-weight:700;">
                    📲 Test WhatsApp Alert
                  </button>
                  <button type="button" id="admin-test-tg-btn-pane" class="btn btn-secondary btn-sm" style="flex:1; min-width:180px; padding:0.5rem 1rem; border-color:rgba(0,240,255,0.4); color:#00f0ff; font-weight:700;">
                    ⚡ Send Test Telegram Alert
                  </button>
                  <button type="button" id="admin-enable-browser-alerts-btn"
"@
$content = $regexTab5.Replace($content, $replacementTab5, 1)

# Tab 5 WhatsApp API key input addition
$oldWaInputPane = '<input type="text" id="admin-cfg-wa-number-pane" class="admin-input" placeholder="WhatsApp (Optional): 919876543210" style="padding:0.35rem 0.6rem; font-size:0.75rem; width:220px;">'
$newWaInputPane = @"
<input type="text" id="admin-cfg-wa-number-pane" class="admin-input" placeholder="Master WhatsApp: 919041062733" style="padding:0.35rem 0.6rem; font-size:0.75rem; width:200px;">
                    <input type="text" id="admin-cfg-wa-apikey-pane" class="admin-input" placeholder="CallMeBot Key (Optional)" style="padding:0.35rem 0.6rem; font-size:0.75rem; width:170px; font-family:monospace;">
"@
if ($content.Contains($oldWaInputPane)) {
    $content = $content.Replace($oldWaInputPane, $newWaInputPane)
}

[System.IO.File]::WriteAllText($htmlPath, $content, [System.Text.Encoding]::UTF8)
Write-Host "Updated index.html notification controls successfully!"

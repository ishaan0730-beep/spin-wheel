﻿$appPath = "C:\Users\ishaa\.gemini\antigravity-ide\scratch\spin-wheel-app\app.js"
$content = [System.IO.File]::ReadAllText($appPath, [System.Text.Encoding]::UTF8)

$oldSnippet = @"
    // Start countdown timer engine immediately so clock & slot display never get stuck
    this.startTimerEngine();

    this.renderLast3Results();
  renderAllSpinHistoryModalList(searchQuery = '', slotFilter = 'ALL') {
"@

$newSnippet = @"
    // Start countdown timer engine immediately so clock & slot display never get stuck
    this.startTimerEngine();

    this.renderLast3Results();
  }

  renderAllSpinHistoryModalList(searchQuery = '', slotFilter = 'ALL') {
"@

if ($content.Contains($oldSnippet)) {
    $content = $content.Replace($oldSnippet, $newSnippet)
    [System.IO.File]::WriteAllText($appPath, $content, [System.Text.Encoding]::UTF8)
    Write-Host "Fixed init() closing brace!"
} else {
    Write-Host "Snippet not found, checking alternative"
}

$path = "index.html"
$content = [System.IO.File]::ReadAllText($path, [System.Text.Encoding]::UTF8)

$target = 'id="admin-tab-settings-pane"'
$idx = $content.IndexOf($target)
if ($idx -gt 0) {
    # Find start of line
    $lineStart = $content.LastIndexOf("<!-- TAB 5:", $idx)
    if ($lineStart -lt 0) { $lineStart = $content.LastIndexOf("<div", $idx) }
    
    $adminChatPaneHtml = @"
          <!-- TAB 6: MASTER ADMIN 24/7 LIVE SUPPORT CHATS -->
          <div id="admin-tab-chats-pane" class="admin-tab-pane hidden">
            <div class="admin-card">
              <div class="admin-card-title" style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:8px;">
                <div style="display:flex; align-items:center; gap:8px;">
                  <span class="step-num">💬</span>
                  <h4 style="margin:0;">Customer Live Support Desk (Real-Time 2-Way Chat)</h4>
                </div>
                <div style="display:flex; gap:6px;">
                  <button type="button" class="btn btn-secondary btn-xs" onclick="app.refreshSupportChatsUI()">🔄 Refresh Chats</button>
                  <button type="button" class="btn btn-gold btn-xs" onclick="app.broadcastNotificationPrompt()">📢 Broadcast Alert to All Users</button>
                </div>
              </div>
              <p class="card-desc" style="margin-bottom:0.75rem;">
                Live inquiries from players on mobile apps and website. Reply directly to solve customer deposit, withdrawal, and prediction questions in real-time.
              </p>

              <!-- Support Desk 2-Column Interface -->
              <div class="admin-chats-layout">
                <!-- Left Sidebar: Conversations List -->
                <div class="admin-chats-sidebar">
                  <div class="admin-chats-sidebar-header">
                    <span>Active Conversations (<span id="admin-active-chats-count">0</span>)</span>
                  </div>
                  <div class="admin-chats-player-list" id="admin-chat-threads-list">
                    <div style="padding:1.5rem; text-align:center; color:var(--text-muted); font-size:0.78rem;">
                      No active support inquiries yet. New customer messages will appear here instantly with live sound alert.
                    </div>
                  </div>
                </div>

                <!-- Right View: Selected Chat Thread -->
                <div class="admin-chats-main-view">
                  <div id="admin-chat-header-bar" style="padding-bottom:0.6rem; border-bottom:1px solid var(--border-subtle); display:flex; justify-content:space-between; align-items:center;">
                    <div>
                      <strong id="admin-selected-chat-name" style="font-size:0.95rem; color:#fff;">Select a conversation</strong>
                      <div id="admin-selected-chat-sub" style="font-size:0.72rem; color:var(--text-secondary);">Click any player from the list to view and reply</div>
                    </div>
                    <div id="admin-selected-chat-actions" class="hidden">
                      <button type="button" class="btn btn-secondary btn-xs" onclick="app.quickCreditSelectedPlayer()">💰 Quick Credit</button>
                    </div>
                  </div>

                  <!-- Messages Scroll Area -->
                  <div class="chat-messages-wrap" id="admin-chat-messages-wrap" style="flex:1; margin:0.65rem 0;">
                    <div style="padding:2rem; text-align:center; color:var(--text-muted); font-size:0.8rem;">
                      Select a player on the left to start live messaging.
                    </div>
                  </div>

                  <!-- Admin Quick Reply Template Chips -->
                  <div class="chat-quick-chips" id="admin-chat-template-chips">
                    <button type="button" class="chat-chip-btn" onclick="app.insertAdminReplyTemplate('✅ Hi, your deposit has been verified and coins are credited to your wallet balance!')">✅ Deposit Approved</button>
                    <button type="button" class="chat-chip-btn" onclick="app.insertAdminReplyTemplate('💸 Your withdrawal request has been approved and successfully transferred to your bank account!')">💸 Withdrawal Sent</button>
                    <button type="button" class="chat-chip-btn" onclick="app.insertAdminReplyTemplate('📸 Please share your 12-digit UTR transaction reference number for verification.')">📸 Ask for UTR</button>
                    <button type="button" class="chat-chip-btn" onclick="app.insertAdminReplyTemplate('🎰 Prediction bets for the upcoming round slot are now open! You can place predictions to win 9x.')">🎰 Bets Open</button>
                  </div>

                  <!-- Admin Chat Input Bar -->
                  <div class="chat-input-bar">
                    <input type="text" id="admin-chat-input" class="chat-input" placeholder="Type reply as Master Admin...">
                    <button type="button" id="admin-chat-send-btn" class="btn btn-gold" style="padding:8px 16px; font-weight:800;" onclick="app.handleAdminSendChat()">
                      Send Reply ➔
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>

"@
    $content = $content.Substring(0, $lineStart) + $adminChatPaneHtml + $content.Substring($lineStart)
    [System.IO.File]::WriteAllText($path, $content, [System.Text.Encoding]::UTF8)
    Write-Output "Successfully inserted admin-tab-chats-pane"
} else {
    Write-Output "admin-tab-settings-pane not found"
}

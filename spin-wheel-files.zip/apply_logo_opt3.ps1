Add-Type -AssemblyName System.Drawing

function Resize-ImageFile {
    param(
        [string]$SrcFile, 
        [string]$DstFile, 
        [int]$W, 
        [int]$H
    )
    $img = [System.Drawing.Image]::FromFile($SrcFile)
    $bmp = New-Object System.Drawing.Bitmap($W, $H)
    $gfx = [System.Drawing.Graphics]::FromImage($bmp)
    $gfx.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
    $gfx.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::HighQuality
    $gfx.PixelOffsetMode = [System.Drawing.Drawing2D.PixelOffsetMode]::HighQuality
    $gfx.CompositingQuality = [System.Drawing.Drawing2D.CompositingQuality]::HighQuality
    $gfx.DrawImage($img, 0, 0, $W, $H)
    $gfx.Dispose()
    $img.Dispose()
    $bmp.Save($DstFile, [System.Drawing.Imaging.ImageFormat]::Png)
    $bmp.Dispose()
}

$sourceLogo = "C:\Users\ishaa\.gemini\antigravity-ide\brain\badc9f3d-0024-4e29-ad87-88490781ece6\spin_wheel_logo_v6_1791179411093.jpg"
$appDir = "C:\Users\ishaa\.gemini\antigravity-ide\scratch\spin-wheel-app"
$distDir = "C:\Users\ishaa\Downloads\spin-wheel-files"

Resize-ImageFile -SrcFile $sourceLogo -DstFile "$appDir\logo.png" -W 512 -H 512
Resize-ImageFile -SrcFile $sourceLogo -DstFile "$appDir\icon-192.png" -W 192 -H 192
Resize-ImageFile -SrcFile $sourceLogo -DstFile "$appDir\icon-512.png" -W 512 -H 512

Resize-ImageFile -SrcFile $sourceLogo -DstFile "$distDir\logo.png" -W 512 -H 512
Resize-ImageFile -SrcFile $sourceLogo -DstFile "$distDir\icon-192.png" -W 192 -H 192
Resize-ImageFile -SrcFile $sourceLogo -DstFile "$distDir\icon-512.png" -W 512 -H 512

Write-Output "Option 3 logo resized and applied successfully!"

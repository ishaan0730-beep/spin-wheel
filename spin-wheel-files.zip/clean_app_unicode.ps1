$appPath = "C:\Users\ishaa\.gemini\antigravity-ide\scratch\spin-wheel-app\app.js"
$content = [System.IO.File]::ReadAllText($appPath, [System.Text.Encoding]::UTF8)

$map = @{
    ([System.Text.Encoding]::UTF8.GetString([byte[]](0xC3,0xA2,0xC5,0x93,0xE2,0x80,0xA6))) = [char]::ConvertFromUtf32(0x2705)
    ([System.Text.Encoding]::UTF8.GetString([byte[]](0xC3,0xA2,0xE2,0x80,0x9A,0xC2,0xB9))) = [char]::ConvertFromUtf32(0x20B9)
    ([System.Text.Encoding]::UTF8.GetString([byte[]](0xC3,0xB0,0xC5,0xB8,0xE2,0x80,0x99,0xC2,0xB0))) = [char]::ConvertFromUtf32(0x1F4B0)
    ([System.Text.Encoding]::UTF8.GetString([byte[]](0xC3,0xB0,0xC5,0xB8,0xE2,0x80,0x99,0xC2,0xB3))) = [char]::ConvertFromUtf32(0x1F4B3)
    ([System.Text.Encoding]::UTF8.GetString([byte[]](0xC3,0xB0,0xC5,0xB8,0xE2,0x80,0x9C,0xC2,0xB2))) = [char]::ConvertFromUtf32(0x1F4F2)
    ([System.Text.Encoding]::UTF8.GetString([byte[]](0xC3,0xB0,0xC5,0xB8,0xE2,0x80,0x9D,0xE2,0x80,0x9D))) = [char]::ConvertFromUtf32(0x1F514)
}

foreach ($k in $map.Keys) {
    if (![string]::IsNullOrEmpty($k)) {
        $content = $content.Replace($k, $map[$k])
    }
}

[System.IO.File]::WriteAllText($appPath, $content, (New-Object System.Text.UTF8Encoding $false))
Write-Host "Cleaned unicode in app.js!"

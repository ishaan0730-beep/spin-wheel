$file = "C:\Users\ishaa\.gemini\antigravity-ide\scratch\spin-wheel-app\server_state.json"
if (Test-Path $file) {
    $txt = Get-Content $file -Raw -Encoding utf8
    $obj = ConvertFrom-Json $txt
    if ($null -eq $obj.supportChats) {
        $obj | Add-Member -NotePropertyName "supportChats" -NotePropertyValue ([PSCustomObject]@{}) -Force
    }
    $jsonOut = ConvertTo-Json $obj -Depth 10 -Compress
    [System.IO.File]::WriteAllText($file, $jsonOut, [System.Text.Encoding]::UTF8)
    Write-Host "server_state.json updated with supportChats!"
}

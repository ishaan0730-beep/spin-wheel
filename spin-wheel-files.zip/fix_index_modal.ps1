$file = "C:\Users\ishaa\.gemini\antigravity-ide\scratch\spin-wheel-app\index.html"
$lines = [System.IO.File]::ReadAllLines($file, [System.Text.Encoding]::UTF8)

# Find the line with "<!-- MODAL 2: ACCOUNT STATEMENT / PASSBOOK MODAL -->"
$firstIdx = -1
$secondIdx = -1
for ($i = 0; $i -lt $lines.Length; $i++) {
    if ($lines[$i] -like "*MODAL 2: ACCOUNT STATEMENT*") {
        if ($firstIdx -eq -1) { $firstIdx = $i }
        else { $secondIdx = $i }
    }
}

Write-Host "Found MODAL 2 at: $firstIdx and $secondIdx"

if ($firstIdx -ne -1 -and $secondIdx -ne -1) {
    # Keep up to firstIdx, add clean modal 2, and continue from after second modal header
    $modal2HeaderEnd = $secondIdx + 6
    $newLines = @()
    for ($i = 0; $i -lt $firstIdx; $i++) {
        $newLines += $lines[$i]
    }
    $newLines += "  <!-- MODAL 2: ACCOUNT STATEMENT / PASSBOOK MODAL -->"
    $newLines += '  <div id="cric-statement-modal" class="modal-backdrop hidden">'
    $newLines += '    <div class="modal-overlay" onclick="app.closeCricModals()"></div>'
    $newLines += '    <div class="modal-content cric-popup-content" style="max-width:620px;">'
    $newLines += '      <div class="modal-header">'
    $newLines += '        <h3 style="color:#00f0ff; font-weight:800; font-size:1.15rem;">🏛️ Account Statement / Passbook</h3>'
    $newLines += '        <button type="button" class="icon-btn" onclick="app.closeCricModals()">&times;</button>'
    $newLines += '      </div>'
    for ($i = $modal2HeaderEnd; $i -lt $lines.Length; $i++) {
        $newLines += $lines[$i]
    }
    [System.IO.File]::WriteAllLines($file, $newLines, [System.Text.Encoding]::UTF8)
    Write-Host "Fixed index.html Modal 2 successfully!"
}

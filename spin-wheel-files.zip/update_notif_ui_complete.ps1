$htmlPath = "C:\Users\ishaa\.gemini\antigravity-ide\scratch\spin-wheel-app\index.html"
$content = [System.IO.File]::ReadAllText($htmlPath, [System.Text.Encoding]::UTF8)

$targetTab3 = [regex]'(?s)<!-- BOX 2: MASTER MOBILE NOTIFICATIONS.*?<span id="admin-notification-feedback"[^>]*></span>\s*</div>'

$newTab3 = @'
                  <!-- BOX 2: MASTER MOBILE NOTIFICATIONS (TELEGRAM / WHATSAPP / ALARM) -->
                  <div class="admin-cfg-card" style="background:rgba(15,23,42,0.7); border:1px solid rgba(0,240,255,0.3); border-radius:8px; padding:0.85rem;">
                    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:0.4rem;">
                      <h5 style="color:#00f0ff; margin:0; font-size:0.88rem; font-weight:800; display:flex; align-items:center; gap:6px;">
                        <span>📱</span> Mobile Instant Alerts (मोबाइल नोटिफिकेशन)
                      </h5>
                      <span style="font-size:0.68rem; color:#2ecc71; font-weight:700; background:rgba(46,204,113,0.15); border:1px solid rgba(46,204,113,0.3); padding:2px 8px; border-radius:12px;">100% Free &amp; Instant</span>
                    </div>

                    <p style="font-size:0.72rem; color:var(--text-secondary); margin:0 0 0.6rem 0; line-height:1.35;">
                      Get loud instant ring notifications on your phone whenever a customer deposits or requests a withdrawal!
                    </p>

                    <div class="form-group" style="margin-top:0.4rem;">
                      <label class="field-label" style="font-size:0.75rem; color:#cbd5e1;">Telegram Bot Token:</label>
                      <input type="text" id="admin-cfg-tg-token" class="admin-input" placeholder="8932355449:AAHCkhZKUMt" style="padding:0.4rem 0.6rem; font-size:0.8rem; font-family:monospace;">
                    </div>

                    <div class="form-group" style="margin-top:0.4rem;">
                      <label class="field-label" style="font-size:0.75rem; color:#cbd5e1;">Your Telegram Chat ID:</label>
                      <input type="text" id="admin-cfg-tg-chatid" class="admin-input" placeholder="8187881990" style="padding:0.4rem 0.6rem; font-size:0.8rem; font-family:monospace;">
                    </div>

                    <div class="form-group" style="margin-top:0.5rem; display:flex; align-items:center; gap:8px;">
                      <input type="checkbox" id="admin-cfg-tg-enable" style="width:16px; height:16px; accent-color:#00f0ff; cursor:pointer;" checked>
                      <label for="admin-cfg-tg-enable" style="font-size:0.78rem; color:#fff; cursor:pointer; font-weight:700;">🔔 Enable Telegram Alerts to Phone</label>
                    </div>

                    <div class="form-group" style="margin-top:0.4rem;">
                      <label class="field-label" style="font-size:0.75rem; color:#cbd5e1;">Master WhatsApp Number:</label>
                      <input type="text" id="admin-cfg-wa-number" class="admin-input" placeholder="7690900087" style="padding:0.4rem 0.6rem; font-size:0.8rem; font-family:monospace;">
                    </div>

                    <div class="form-group" style="margin-top:0.4rem;">
                      <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:2px;">
                        <label class="field-label" style="font-size:0.75rem; color:#cbd5e1; margin:0;">CallMeBot WhatsApp API Key (Free):</label>
                        <a href="https://api.whatsapp.com/send?phone=34644442439&text=I%20allow%20callmebot%20to%20send%20me%20messages" target="_blank" rel="noopener noreferrer" style="font-size:0.68rem; color:#25D366; text-decoration:none; font-weight:700;">📲 1-Click Get Key on WhatsApp</a>
                      </div>
                      <input type="text" id="admin-cfg-wa-apikey" class="admin-input" placeholder="e.g. 1234567" style="padding:0.4rem 0.6rem; font-size:0.8rem; font-family:monospace;">
                      <span style="font-size:0.65rem; color:var(--text-muted); display:block; margin-top:2px;">
                        Free Key in 5 secs: Click "1-Click Get Key", send message to <strong>+34 644 44 24 39</strong> &amp; paste key above.
                      </span>
                    </div>

                    <!-- 1-Minute Easy Guide Accordion -->
                    <div style="background:rgba(0,0,0,0.45); border:1px dashed rgba(245,176,65,0.45); border-radius:6px; padding:0.55rem 0.75rem; margin-top:0.6rem; font-size:0.7rem; color:var(--text-secondary);">
                      <strong style="color:#ffd700; font-size:0.74rem;">📖 1-Minute Alert Setup Guide:</strong>
                      <ol style="margin:4px 0 0 16px; padding:0; line-height:1.4;">
                        <li><strong>Telegram:</strong> Search <code>@BotFather</code> for Bot Token, search <code>@userinfobot</code> for Chat ID.</li>
                        <li><strong>WhatsApp:</strong> Click <strong>📲 1-Click Get Key on WhatsApp</strong>, press Send, and paste the API Key here.</li>
                        <li>Click <strong>💾 Save Alert Settings</strong> and test using the buttons below!</li>
                      </ol>
                    </div>

                    <div style="display:flex; gap:0.4rem; margin-top:0.65rem; flex-wrap:wrap;">
                      <button type="button" id="admin-test-wa-btn" class="btn btn-secondary btn-sm" style="flex:1; min-width:130px; color:#25D366; border-color:rgba(37,211,102,0.5); font-size:0.72rem; font-weight:700;">
                        📲 Test WhatsApp Alert
                      </button>
                      <button type="button" id="admin-test-tg-btn" class="btn btn-secondary btn-sm" style="flex:1; min-width:130px; color:#00f0ff; border-color:rgba(0,240,255,0.4); font-size:0.72rem; font-weight:700;">
                        🔔 Test Telegram Alert
                      </button>
                      <button type="button" id="admin-save-notifications-btn" class="btn btn-gold btn-sm" style="flex:1.2; min-width:150px; font-size:0.72rem; font-weight:800;">
                        💾 Save Alert Settings
                      </button>
                    </div>
                    <span id="admin-notification-feedback" class="save-status-msg" style="display:block; margin-top:4px; font-size:0.72rem;"></span>
                  </div>
'@

if ($targetTab3.IsMatch($content)) {
    $content = $targetTab3.Replace($content, $newTab3, 1)
    [System.IO.File]::WriteAllText($htmlPath, $content, [System.Text.Encoding]::UTF8)
    Write-Host "Updated Tab 3 Mobile Notifications in index.html!"
} else {
    Write-Host "Regex did not match Tab 3."
}

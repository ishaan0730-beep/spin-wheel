$appPath = "C:\Users\ishaa\.gemini\antigravity-ide\scratch\spin-wheel-app\app.js"
$content = [System.IO.File]::ReadAllText($appPath, [System.Text.Encoding]::UTF8)

# 1. Update determineTargetNumber in app.js
$targetBlock1 = @'
    // 2. 4-Slot Predetermined Schedule for this specific round slot (STRICT MASTER LOCK)
    const scheduledVal = this.dailySchedule ? this.dailySchedule[slotToCheck] : null;
    if (scheduledVal !== undefined && scheduledVal !== null && scheduledVal !== 'AUTO') {
      const schedNum = parseInt(scheduledVal, 10);
      if (this.slices.includes(schedNum)) {
        return schedNum;
      }
    }
'@

$replacementBlock1 = @'
    // 2. 4-Slot Predetermined Schedule for this specific round slot (STRICT MASTER LOCK - 1-TIME USE ONLY)
    const scheduledVal = this.dailySchedule ? this.dailySchedule[slotToCheck] : null;
    if (scheduledVal !== undefined && scheduledVal !== null && scheduledVal !== 'AUTO') {
      const schedNum = parseInt(scheduledVal, 10);
      if (this.slices.includes(schedNum)) {
        // AUTOMATICALLY RESET THIS SLOT TO 'AUTO' AFTER 1-TIME EXECUTION!
        this.dailySchedule[slotToCheck] = 'AUTO';
        this.version = Date.now();
        this.lastVersion = this.version;
        try {
          localStorage.setItem(STATE_KEYS.DAILY_SCHEDULE, JSON.stringify(this.dailySchedule));
        } catch (e) {}
        this.renderDailyScheduleTable();
        this.updateSection1BadgeForSelectedSlot();
        this.pushStateToServer({
          dailySchedule: this.dailySchedule,
          scheduleAction: 'EXPLICIT_CLEAR',
          clearedSlot: slotToCheck,
          forcedNext: null,
          version: this.version
        });
        if (this.cloudSync) {
          this.cloudSync.broadcastLiveEvent({
            eventType: 'DAILY_SCHEDULE_UPDATED',
            dailySchedule: this.dailySchedule
          });
        }
        return schedNum;
      }
    }
'@

if ($content.Contains($targetBlock1)) {
    $content = $content.Replace($targetBlock1, $replacementBlock1)
    Write-Host "Replaced determineTargetNumber slot auto-reset successfully!"
} else {
    Write-Host "Warning: targetBlock1 not found directly, checking regex..."
    $content = [regex]::Replace($content, '(?s)// 2\. 4-Slot Predetermined Schedule.*?return schedNum;\s*\}\s*\}', $replacementBlock1)
}

# 2. Update onSpinComplete in app.js
$targetBlock2 = @'
    // Always clear spinTrigger on complete and broadcast latest history to server & cloud
    this.pushStateToServer({
      spinTrigger: null,
      history: this.history,
      customersDb: this.customersDb,
      activeBets: this.activeBets
    });
'@

$replacementBlock2 = @'
    // Ensure the executed round slot is reset to AUTO and forcedNext is reset to null (1-time execution)
    if (!isTestSpin) {
      let schedUpdated = false;
      if (this.dailySchedule && this.dailySchedule[roundStr12] && this.dailySchedule[roundStr12] !== 'AUTO') {
        this.dailySchedule[roundStr12] = 'AUTO';
        schedUpdated = true;
      }
      if (this.forcedNext !== null) {
        this.forcedNext = null;
        this.updateForcedWinnerUI();
      }
      if (schedUpdated) {
        this.version = Date.now();
        this.lastVersion = this.version;
        try {
          localStorage.setItem(STATE_KEYS.DAILY_SCHEDULE, JSON.stringify(this.dailySchedule));
        } catch (e) {}
        this.renderDailyScheduleTable();
        this.updateSection1BadgeForSelectedSlot();
      }
    }

    // Always clear spinTrigger on complete and broadcast latest history and updated dailySchedule to server & cloud
    this.pushStateToServer({
      spinTrigger: null,
      forcedNext: this.forcedNext,
      dailySchedule: this.dailySchedule,
      history: this.history,
      customersDb: this.customersDb,
      activeBets: this.activeBets
    });
'@

if ($content.Contains($targetBlock2)) {
    $content = $content.Replace($targetBlock2, $replacementBlock2)
    Write-Host "Replaced onSpinComplete pushState successfully!"
} else {
    Write-Host "Warning: targetBlock2 not found directly, checking regex..."
    $content = [regex]::Replace($content, '(?s)// Always clear spinTrigger on complete and broadcast latest history to server & cloud\s*this\.pushStateToServer\(\{\s*spinTrigger: null,\s*history: this\.history,\s*customersDb: this\.customersDb,\s*activeBets: this\.activeBets\s*\}\);', $replacementBlock2)
}

# 3. Update settleAllExpiredBets in app.js
$targetBlock3 = @'
            if (dayOffset === 0 && this.dailySchedule && this.dailySchedule[slotLabel] && this.dailySchedule[slotLabel] !== 'AUTO') {
              const sched = parseInt(this.dailySchedule[slotLabel], 10);
              if (slices.includes(sched)) winningNum = sched;
            }
'@

$replacementBlock3 = @'
            if (dayOffset === 0 && this.dailySchedule && this.dailySchedule[slotLabel] && this.dailySchedule[slotLabel] !== 'AUTO') {
              const sched = parseInt(this.dailySchedule[slotLabel], 10);
              if (slices.includes(sched)) {
                winningNum = sched;
                this.dailySchedule[slotLabel] = 'AUTO';
                try {
                  localStorage.setItem(STATE_KEYS.DAILY_SCHEDULE, JSON.stringify(this.dailySchedule));
                } catch (e) {}
                this.renderDailyScheduleTable();
                this.updateSection1BadgeForSelectedSlot();
                this.pushStateToServer({ dailySchedule: this.dailySchedule, forcedNext: null });
              }
            }
'@

if ($content.Contains($targetBlock3)) {
    $content = $content.Replace($targetBlock3, $replacementBlock3)
    Write-Host "Replaced settleAllExpiredBets auto-reset successfully!"
}

[System.IO.File]::WriteAllText($appPath, $content, [System.Text.Encoding]::UTF8)
Write-Host "Saved app.js successfully with 1-time lock auto-reset logic!"

$jsFile = "C:\Users\ishaa\.gemini\antigravity-ide\scratch\spin-wheel-app\app.js"
$lines = [System.IO.File]::ReadAllLines($jsFile, [System.Text.Encoding]::UTF8)

# 1. Update loadLocalHistory to not return static fake [80, 70, 40]
for ($i = 0; $i -lt $lines.Length; $i++) {
    if ($lines[$i] -match "loadLocalHistory\(\)\s*\{") {
        $lines[$i+1] = "    try {"
        $lines[$i+2] = "      const saved = localStorage.getItem(STATE_KEYS.HISTORY);"
        $lines[$i+3] = "      if (saved) {"
        $lines[$i+4] = "        const parsed = JSON.parse(saved);"
        $lines[$i+5] = "        if (Array.isArray(parsed) && parsed.length > 0) return parsed;"
        $lines[$i+6] = "      }"
        $lines[$i+7] = "    } catch (e) {}"
        $lines[$i+8] = "    return [];"
        $lines[$i+9] = "  }"
        # blank out 2066 to 2070
        for ($k = $i + 10; $k -le $i + 14; $k++) {
            if ($k -lt $lines.Length -and $lines[$k] -notmatch "loadLocalQueue") {
                $lines[$k] = ""
            }
        }
        break
    }
}

# 2. Update applyServerState history synchronization
for ($i = 0; $i -lt $lines.Length; $i++) {
    if ($lines[$i] -match "// 2\. History") {
        $startH = $i
        $endH = $i
        for ($j = $i; $j -lt $i + 40; $j++) {
            if ($lines[$j] -match "// 3\. Forced Next Winner") {
                $endH = $j
                break
            }
        }
        $newHistBlock = @(
            "    // 2. History (STRICT SYNCHRONIZED CLOUD REPLICATION)",
            "    if (Array.isArray(state.history)) {",
            "      if (state.history.length > 0) {",
            "        const currJson = JSON.stringify(this.history || []);",
            "        const newJson = JSON.stringify(state.history);",
            "        if (currJson !== newJson) {",
            "          this.history = state.history;",
            "          localStorage.setItem(STATE_KEYS.HISTORY, JSON.stringify(this.history));",
            "          historyNeedsRedraw = true;",
            "        }",
            "      }",
            "    }"
        )
        $before = $lines[0..($startH - 1)]
        $after = $lines[$endH..($lines.Length - 1)]
        $lines = @($before) + $newHistBlock + @($after)
        break
    }
}

# 3. Add alignWheelToLatestResult method and trigger on history redraw
for ($i = 0; $i -lt $lines.Length; $i++) {
    if ($lines[$i] -match "if \(historyNeedsRedraw\)\s*\{") {
        $lines[$i+1] = "      this.renderLast3Results();"
        $lines[$i+2] = "      this.renderAllSpinHistoryModalList();"
        $lines[$i+3] = "      this.renderAdminSpinHistoryTable();"
        $lines[$i+4] = "      if (!this.isSpinning) this.alignWheelToLatestResult();"
        break
    }
}

# 4. Insert alignWheelToLatestResult before renderWheel
for ($i = 0; $i -lt $lines.Length; $i++) {
    if ($lines[$i] -match "renderWheel\(\)\s*\{") {
        $alignFn = @(
            "  alignWheelToLatestResult() {",
            "    if (this.isSpinning) return;",
            "    if (!this.history || !Array.isArray(this.history) || this.history.length === 0) return;",
            "    const latest = this.history[0];",
            "    if (!latest || typeof latest.number === 'undefined') return;",
            "    const targetNumber = parseInt(latest.number, 10);",
            "    if (isNaN(targetNumber)) return;",
            "    let targetIndex = this.slices.indexOf(targetNumber);",
            "    if (targetIndex === -1) targetIndex = 0;",
            "    const numSlices = this.slices.length;",
            "    const sliceAngle = (2 * Math.PI) / numSlices;",
            "    const targetCenterAngle = (targetIndex + 0.5) * sliceAngle;",
            "    let desiredAngle = (-Math.PI / 2 - targetCenterAngle) % (2 * Math.PI);",
            "    if (desiredAngle < 0) desiredAngle += 2 * Math.PI;",
            "    this.currentAngle = desiredAngle;",
            "    this.renderWheel();",
            "  }",
            ""
        )
        $before = $lines[0..($i - 1)]
        $after = $lines[$i..($lines.Length - 1)]
        $lines = @($before) + $alignFn + @($after)
        break
    }
}

# 5. In init(), call alignWheelToLatestResult after setting up
for ($i = 0; $i -lt $lines.Length; $i++) {
    if ($lines[$i] -match "this\.renderWheel\(\);") {
        $lines[$i] = "    this.alignWheelToLatestResult();`n    this.renderWheel();"
        break
    }
}

[System.IO.File]::WriteAllLines($jsFile, $lines, [System.Text.Encoding]::UTF8)
Write-Host "app.js updated with alignWheelToLatestResult and strict history sync!"

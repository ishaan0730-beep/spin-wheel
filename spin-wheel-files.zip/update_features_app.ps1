$path = "app.js"
$content = [System.IO.File]::ReadAllText($path, [System.Text.Encoding]::UTF8)

# 1. Add Support Chat state & DOM elements to constructor
$targetConstructor = "    this.adminNavSettingsBtn = document.getElementById('admin-nav-settings-btn');"
$constructorAdditions = "    this.adminNavSettingsBtn = document.getElementById('admin-nav-settings-btn');`n    this.adminNavChatsBtn = document.getElementById('admin-nav-chats-btn');`n    this.adminTabChatsPane = document.getElementById('admin-tab-chats-pane');`n    this.adminTabBadgeChats = document.getElementById('admin-tab-badge-chats');`n    this.supportChats = this.loadLocalSupportChats();`n    this.selectedChatPlayerId = null;`n    this.sentSlotAlerts = {};"

if ($content.Contains($targetConstructor) -and -not $content.Contains("this.adminNavChatsBtn =")) {
    $content = $content.Replace($targetConstructor, $constructorAdditions)
    Write-Output "Added Chat & Notification DOM properties to constructor"
}

# 2. Add Live Event handling in handleIncomingLiveEvent
$targetLiveEvent = "    if (event.eventType === 'NEW_DEPOSIT') {"
$liveEventAdditions = @'
    if (event.eventType === 'CHAT_MESSAGE') {
      const msg = event.chatMessage;
      if (!msg || !msg.playerId) return;
      if (!this.supportChats) this.supportChats = {};
      if (!Array.isArray(this.supportChats[msg.playerId])) this.supportChats[msg.playerId] = [];
      
      const exists = this.supportChats[msg.playerId].some(m => m.id === msg.id);
      if (!exists) {
        this.supportChats[msg.playerId].push(msg);
        this.saveSupportChats(this.supportChats);
      }

      if (this.audio) this.audio.playTick();
      this.updateSupportChatBadges();

      // If customer chat modal is open and belongs to this customer
      const currentCustId = this.currentCustomer ? String(this.currentCustomer.id || '').toLowerCase() : 'guest';
      if (String(msg.playerId).toLowerCase() === currentCustId) {
        this.renderCustomerChatMessages();
      }

      // If admin panel is open, refresh admin chat desk
      if (this.adminTabChatsPane && !this.adminTabChatsPane.classList.contains('hidden')) {
        this.refreshSupportChatsUI();
      }

      // If admin received customer message, show toast on Master screen
      if (msg.sender === 'CUSTOMER') {
        this.showLiveToast({
          title: '💬 NEW SUPPORT CHAT MESSAGE!',
          message: `<b>${msg.playerName || msg.playerId}</b>: ${msg.text.slice(0, 50)}`,
          type: 'deposit',
          actionText: '👉 OPEN LIVE CHAT',
          actionCallback: () => {
            this.openAdminPanelDirectly();
            this.setAdminTab('chats');
            this.selectAdminChatPlayer(msg.playerId);
          }
        });
      }
    }

    else if (event.eventType === 'BROADCAST_NOTIFICATION') {
      this.sendSystemNotification(event.title || '🎰 SPIN & WHEEL ALERT', event.message || '', event.icon || 'icon-192.png');
    }

    else if (event.eventType === 'NEW_DEPOSIT') {
'@

if ($content.Contains($targetLiveEvent) -and -not $content.Contains("event.eventType === 'CHAT_MESSAGE'")) {
    $content = $content.Replace($targetLiveEvent, $liveEventAdditions)
    Write-Output "Added CHAT_MESSAGE and BROADCAST_NOTIFICATION handlers to handleIncomingLiveEvent"
}

# 3. Add tab switching logic in setAdminTab
$targetTabClear = "    this.adminTabSettingsPane?.classList.add('hidden');"
$tabClearAddition = "    this.adminTabSettingsPane?.classList.add('hidden');`n    this.adminTabChatsPane?.classList.add('hidden');`n    this.adminNavChatsBtn?.classList.remove('active');"

if ($content.Contains($targetTabClear) -and -not $content.Contains("this.adminTabChatsPane?.classList.add('hidden');")) {
    $content = $content.Replace($targetTabClear, $tabClearAddition)
    Write-Output "Added adminTabChatsPane clearing in setAdminTab"
}

$targetTabSettings = "    } else if (tabName === 'settings') {"
$tabChatsAddition = "    } else if (tabName === 'chats') {`n      this.adminNavChatsBtn?.classList.add('active');`n      this.adminTabChatsPane?.classList.remove('hidden');`n      this.refreshSupportChatsUI();`n    } else if (tabName === 'settings') {"

if ($content.Contains($targetTabSettings) -and -not $content.Contains("tabName === 'chats'")) {
    $content = $content.Replace($targetTabSettings, $tabChatsAddition)
    Write-Output "Added chats tab activation in setAdminTab"
}

# 4. Bind Chat and Notification drawer events in bindCricbetEvents
$targetDrawerBind = "    document.getElementById('cric-row-download-app')?.addEventListener('click', () => {"
$drawerBindAddition = "    document.getElementById('cric-row-support-chat')?.addEventListener('click', () => {`n      this.openSupportChatModal();`n    });`n`n    document.getElementById('cric-row-download-app')?.addEventListener('click', () => {"

if ($content.Contains($targetDrawerBind) -and -not $content.Contains("cric-row-support-chat")) {
    $content = $content.Replace($targetDrawerBind, $drawerBindAddition)
    Write-Output "Added cric-row-support-chat click listener"
}

# 5. Add Live Chat & Notification Engine methods before end of class
$targetClassEnd = "  // Cricbet language toggle"
$chatEngineCode = @'
  // ==========================================================
  // 24/7 LIVE SUPPORT CHAT ENGINE (CUSTOMER <-> MASTER ADMIN)
  // ==========================================================
  loadLocalSupportChats() {
    try {
      const saved = localStorage.getItem('spinwheel_support_chats');
      if (saved) return JSON.parse(saved);
    } catch (e) {}
    return {};
  }

  saveSupportChats(chats) {
    this.supportChats = chats || {};
    try {
      localStorage.setItem('spinwheel_support_chats', JSON.stringify(this.supportChats));
    } catch (e) {}
    this.pushStateToServer({ supportChats: this.supportChats });
  }

  openSupportChatModal() {
    this.closeCricDrawer();
    const modal = document.getElementById('cric-support-chat-modal');
    if (!modal) return;
    this.renderCustomerChatMessages();
    modal.classList.remove('hidden');

    const input = document.getElementById('cust-chat-input');
    if (input) {
      input.focus();
      input.onkeydown = (e) => {
        if (e.key === 'Enter') this.handleCustomerSendChat();
      };
    }
  }

  renderCustomerChatMessages() {
    const wrap = document.getElementById('cust-chat-messages-wrap');
    if (!wrap) return;

    const playerId = this.currentCustomer ? (this.currentCustomer.id || 'guest_user') : 'guest_user';
    const msgs = (this.supportChats && this.supportChats[playerId]) ? this.supportChats[playerId] : [];

    let html = `
      <div class="chat-msg msg-admin">
        <div class="chat-msg-bubble">
          👋 <b>Welcome to Spin & Wheel 24/7 Live Support!</b><br>
          Directly connected to Master Admin. If you have any questions about deposits, withdrawals, predictions, or coin credits, message us below for instant help!
        </div>
        <div class="chat-msg-meta">
          <span>👑 Master Support</span> &bull; <span>Online</span>
        </div>
      </div>
    `;

    msgs.forEach(m => {
      const isAdmin = m.sender === 'ADMIN';
      html += `
        <div class="chat-msg ${isAdmin ? 'msg-admin' : 'msg-customer'}">
          <div class="chat-msg-bubble">${m.text}</div>
          <div class="chat-msg-meta">
            <span>${isAdmin ? '👑 Master Admin' : '👤 You'}</span> &bull; <span>${m.time || 'Now'}</span>
          </div>
        </div>
      `;
    });

    wrap.innerHTML = html;
    wrap.scrollTop = wrap.scrollHeight;
  }

  handleCustomerSendChat() {
    const input = document.getElementById('cust-chat-input');
    const text = (input?.value || '').trim();
    if (!text) return;

    const playerId = this.currentCustomer ? (this.currentCustomer.id || 'guest_user') : 'guest_user';
    const playerName = this.currentCustomer ? (this.currentCustomer.name || this.currentCustomer.id) : 'Guest Player';

    const now = new Date();
    const timeStr = typeof formatTime12 === 'function' ? formatTime12(now) : now.toLocaleTimeString();

    const newMsg = {
      id: 'msg_' + Date.now() + '_' + Math.random().toString(16).slice(2, 6),
      sender: 'CUSTOMER',
      playerId: playerId,
      playerName: playerName,
      text: text,
      timestamp: Date.now(),
      time: timeStr,
      date: now.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
      unreadByAdmin: true
    };

    if (!this.supportChats[playerId]) this.supportChats[playerId] = [];
    this.supportChats[playerId].push(newMsg);
    this.saveSupportChats(this.supportChats);

    if (input) input.value = '';
    this.renderCustomerChatMessages();
    if (this.audio) this.audio.playTick();

    // Broadcast across MQTT & multi-device sync
    if (this.cloudSync) {
      this.cloudSync.broadcastLiveEvent({
        eventType: 'CHAT_MESSAGE',
        chatMessage: newMsg
      });
    }

    this.showLiveToast({
      title: 'MESSAGE SENT TO MASTER ADMIN',
      message: 'Your message has been delivered to Master Support desk!',
      type: 'success',
      duration: 3000
    });
  }

  sendQuickChatQuery(queryText) {
    const input = document.getElementById('cust-chat-input');
    if (input) {
      input.value = queryText;
      this.handleCustomerSendChat();
    }
  }

  openTelegramSupport() {
    window.open('https://t.me/telegram', '_blank');
  }

  // Master Admin Support Desk Methods
  refreshSupportChatsUI() {
    const threadsList = document.getElementById('admin-chat-threads-list');
    const countEl = document.getElementById('admin-active-chats-count');
    const badgeEl = document.getElementById('admin-tab-badge-chats');
    if (!threadsList) return;

    const allChats = this.supportChats || {};
    const playerIds = Object.keys(allChats);

    if (countEl) countEl.textContent = playerIds.length;

    let totalUnread = 0;
    playerIds.forEach(pId => {
      const msgs = allChats[pId] || [];
      const unreadCount = msgs.filter(m => m.sender === 'CUSTOMER' && m.unreadByAdmin).length;
      totalUnread += unreadCount;
    });

    if (badgeEl) badgeEl.textContent = totalUnread;

    if (playerIds.length === 0) {
      threadsList.innerHTML = '<div style="padding:1.5rem; text-align:center; color:var(--text-muted); font-size:0.78rem;">No active support inquiries yet.</div>';
      return;
    }

    // Sort by latest message
    playerIds.sort((a, b) => {
      const lastA = (allChats[a] || []).slice(-1)[0]?.timestamp || 0;
      const lastB = (allChats[b] || []).slice(-1)[0]?.timestamp || 0;
      return lastB - lastA;
    });

    threadsList.innerHTML = '';
    playerIds.forEach(pId => {
      const msgs = allChats[pId] || [];
      const lastMsg = msgs.slice(-1)[0] || { text: 'New chat', time: '' };
      const unreadCount = msgs.filter(m => m.sender === 'CUSTOMER' && m.unreadByAdmin).length;
      const isSelected = (this.selectedChatPlayerId === pId);

      const pInfo = (this.customersDb && this.customersDb[pId]) ? this.customersDb[pId] : { name: pId, coins: 0 };

      const item = document.createElement('div');
      item.className = `admin-chat-player-item ${isSelected ? 'active' : ''}`;
      item.onclick = () => this.selectAdminChatPlayer(pId);

      item.innerHTML = `
        <div class="admin-chat-player-top">
          <span class="admin-chat-player-name">${pInfo.name || pId}</span>
          <span style="font-size:0.65rem; color:var(--text-muted);">${lastMsg.time || ''}</span>
        </div>
        <div style="display:flex; justify-content:space-between; align-items:center; gap:4px;">
          <span class="admin-chat-player-snippet">${lastMsg.text || 'No message'}</span>
          ${unreadCount > 0 ? `<span class="cric-row-count" style="background:#2ecc71; color:#000; font-size:0.65rem; padding:1px 5px;">${unreadCount}</span>` : ''}
        </div>
      `;
      threadsList.appendChild(item);
    });

    if (this.selectedChatPlayerId) {
      this.renderAdminSelectedChatMessages();
    }
  }

  selectAdminChatPlayer(playerId) {
    this.selectedChatPlayerId = playerId;
    
    // Mark messages as read by admin
    if (this.supportChats && this.supportChats[playerId]) {
      this.supportChats[playerId].forEach(m => {
        if (m.sender === 'CUSTOMER') m.unreadByAdmin = false;
      });
      this.saveSupportChats(this.supportChats);
    }

    const nameEl = document.getElementById('admin-selected-chat-name');
    const subEl = document.getElementById('admin-selected-chat-sub');
    const actionsEl = document.getElementById('admin-selected-chat-actions');

    const pInfo = (this.customersDb && this.customersDb[playerId]) ? this.customersDb[playerId] : { name: playerId, coins: 0 };

    if (nameEl) nameEl.textContent = `👤 ${pInfo.name || playerId} (ID: ${playerId})`;
    if (subEl) subEl.textContent = `💰 Balance: ${(pInfo.coins || 0).toLocaleString()} Coins | Mobile: ${pInfo.mobile || 'N/A'}`;
    if (actionsEl) actionsEl.classList.remove('hidden');

    this.refreshSupportChatsUI();
    this.renderAdminSelectedChatMessages();

    const input = document.getElementById('admin-chat-input');
    if (input) {
      input.focus();
      input.onkeydown = (e) => {
        if (e.key === 'Enter') this.handleAdminSendChat();
      };
    }
  }

  renderAdminSelectedChatMessages() {
    const wrap = document.getElementById('admin-chat-messages-wrap');
    if (!wrap || !this.selectedChatPlayerId) return;

    const msgs = (this.supportChats && this.supportChats[this.selectedChatPlayerId]) ? this.supportChats[this.selectedChatPlayerId] : [];

    if (msgs.length === 0) {
      wrap.innerHTML = '<div style="padding:2rem; text-align:center; color:var(--text-muted); font-size:0.8rem;">No messages in this conversation yet. Send a reply below.</div>';
      return;
    }

    let html = '';
    msgs.forEach(m => {
      const isAdmin = m.sender === 'ADMIN';
      html += `
        <div class="chat-msg ${isAdmin ? 'msg-admin' : 'msg-customer'}">
          <div class="chat-msg-bubble">${m.text}</div>
          <div class="chat-msg-meta">
            <span>${isAdmin ? '👑 You (Master Admin)' : '👤 ' + (m.playerName || m.playerId)}</span> &bull; <span>${m.time || 'Now'}</span>
          </div>
        </div>
      `;
    });

    wrap.innerHTML = html;
    wrap.scrollTop = wrap.scrollHeight;
  }

  handleAdminSendChat() {
    if (!this.selectedChatPlayerId) {
      alert('Please select a player conversation first.');
      return;
    }

    const input = document.getElementById('admin-chat-input');
    const text = (input?.value || '').trim();
    if (!text) return;

    const now = new Date();
    const timeStr = typeof formatTime12 === 'function' ? formatTime12(now) : now.toLocaleTimeString();

    const newMsg = {
      id: 'msg_' + Date.now() + '_' + Math.random().toString(16).slice(2, 6),
      sender: 'ADMIN',
      playerId: this.selectedChatPlayerId,
      text: text,
      timestamp: Date.now(),
      time: timeStr,
      date: now.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })
    };

    if (!this.supportChats[this.selectedChatPlayerId]) this.supportChats[this.selectedChatPlayerId] = [];
    this.supportChats[this.selectedChatPlayerId].push(newMsg);
    this.saveSupportChats(this.supportChats);

    if (input) input.value = '';
    this.renderAdminSelectedChatMessages();
    if (this.audio) this.audio.playTick();

    // Broadcast message to player's app in real-time
    if (this.cloudSync) {
      this.cloudSync.broadcastLiveEvent({
        eventType: 'CHAT_MESSAGE',
        chatMessage: newMsg
      });
    }

    this.showAdminCreditFeedback('✅ Reply sent directly to player in real-time!', true);
  }

  insertAdminReplyTemplate(templateText) {
    const input = document.getElementById('admin-chat-input');
    if (input) {
      input.value = templateText;
      input.focus();
    }
  }

  quickCreditSelectedPlayer() {
    if (!this.selectedChatPlayerId) return;
    this.setAdminTab('players');
    if (this.adminPlayerSearch) {
      this.adminPlayerSearch.value = this.selectedChatPlayerId;
      this.renderAdminPlayersList(this.selectedChatPlayerId);
    }
  }

  updateSupportChatBadges() {
    const unreadEl = document.getElementById('cric-chat-unread-badge');
    const adminBadge = document.getElementById('admin-tab-badge-chats');

    const allChats = this.supportChats || {};
    let totalUnreadByAdmin = 0;
    Object.values(allChats).forEach(msgs => {
      totalUnreadByAdmin += (msgs || []).filter(m => m.sender === 'CUSTOMER' && m.unreadByAdmin).length;
    });

    if (adminBadge) adminBadge.textContent = totalUnreadByAdmin;
    if (unreadEl) {
      unreadEl.textContent = 'ONLINE';
    }
  }

  // ==========================================================
  // PUSH NOTIFICATIONS & AUTOMATED HOURLY COUNTDOWN ALERTS
  // ==========================================================
  requestNotificationPermission() {
    if (typeof Notification === 'undefined') {
      alert('Push notifications are not supported on this browser.');
      return;
    }

    Notification.requestPermission().then(permission => {
      if (permission === 'granted') {
        this.sendSystemNotification('🔔 NOTIFICATIONS ENABLED!', 'You will now receive instant alerts for upcoming spin rounds (1 hour left, 30 min left, live results)!', 'icon-192.png');
        if (this.audio) this.audio.playWinFanfare();
        this.showLiveToast({
          title: 'PUSH NOTIFICATIONS ACTIVE',
          message: '✅ Live upcoming spin alerts & countdown reminders are enabled on your device!',
          type: 'success',
          duration: 4000
        });
      } else {
        alert('Notification permission was not granted. Please enable notifications in your browser site settings.');
      }
    });
  }

  sendSystemNotification(title, body, icon = 'icon-192.png') {
    if (typeof Notification !== 'undefined' && Notification.permission === 'granted') {
      try {
        new Notification(title, {
          body: body.replace(/<[^>]*>?/gm, ''),
          icon: icon,
          badge: icon
        });
      } catch (e) {}
    }

    // Always trigger rich in-app toast & audio
    this.showLiveToast({
      title: title,
      message: body,
      type: 'deposit',
      duration: 5000
    });

    if (this.audio) this.audio.playTick();
  }

  broadcastNotificationPrompt() {
    const text = prompt('Enter custom announcement to broadcast to ALL online users & mobile apps:');
    if (!text || !text.trim()) return;

    const payload = {
      eventType: 'BROADCAST_NOTIFICATION',
      title: '📢 MASTER ADMIN ANNOUNCEMENT',
      message: text.trim(),
      icon: 'icon-192.png',
      timestamp: Date.now()
    };

    if (this.cloudSync) {
      this.cloudSync.broadcastLiveEvent(payload);
    }
    this.pushStateToServer({ lastBroadcast: payload });
    this.sendSystemNotification(payload.title, payload.message);

    alert('Announcement broadcasted to all connected players successfully!');
  }

  checkAutomatedCountdownAlerts(remainingSecs, targetSlot) {
    if (!targetSlot) return;
    const today = new Date().toISOString().split('T')[0];
    const key1h = `${today}_${targetSlot}_1h`;
    const key30m = `${today}_${targetSlot}_30m`;
    const key15m = `${today}_${targetSlot}_15m`;
    const key5m = `${today}_${targetSlot}_5m`;

    // 1 Hour Left (3600s - 3585s)
    if (remainingSecs <= 3600 && remainingSecs >= 3585 && !this.sentSlotAlerts[key1h]) {
      this.sentSlotAlerts[key1h] = true;
      this.sendSystemNotification(
        `⏳ 1 HOUR LEFT: ${targetSlot} SPIN!`,
        `The upcoming live spin for <b>${targetSlot}</b> round starts in 1 hour! Place your predictions now to win 9x payout.`,
        'icon-192.png'
      );
    }

    // 30 Minutes Left (1800s - 1785s)
    else if (remainingSecs <= 1800 && remainingSecs >= 1785 && !this.sentSlotAlerts[key30m]) {
      this.sentSlotAlerts[key30m] = true;
      this.sendSystemNotification(
        `⏰ 30 MINUTES LEFT: ${targetSlot} ROUND`,
        `Only 30 minutes left until betting cutoff for <b>${targetSlot}</b> live draw!`,
        'icon-192.png'
      );
    }

    // 15 Minutes Left (900s - 885s)
    else if (remainingSecs <= 900 && remainingSecs >= 885 && !this.sentSlotAlerts[key15m]) {
      this.sentSlotAlerts[key15m] = true;
      this.sendSystemNotification(
        `🔥 15 MINUTES LEFT: FINAL WINDOW!`,
        `Final betting window open for <b>${targetSlot}</b> round!`,
        'icon-192.png'
      );
    }

    // 5 Minutes Left (300s - 285s)
    else if (remainingSecs <= 300 && remainingSecs >= 285 && !this.sentSlotAlerts[key5m]) {
      this.sentSlotAlerts[key5m] = true;
      this.sendSystemNotification(
        `⚡ 5 MINUTES LEFT: GET READY!`,
        `Spin round for <b>${targetSlot}</b> is starting in 5 minutes!`,
        'icon-192.png'
      );
    }
  }

  // Cricbet language toggle
'@

if ($content.Contains($targetClassEnd) -and -not $content.Contains("loadLocalSupportChats()")) {
    $content = $content.Replace($targetClassEnd, $chatEngineCode)
    Write-Output "Added Live Chat and Notification Engine methods"
}

# 6. Add countdown check to startTimerEngine
$targetTimerTick = "    const tick = () => {"
$timerTickAddition = @'
    const tick = () => {
      // Check Automated Push Notification alerts for upcoming slot
      try {
        const nextInfo = getNextOpenBettingSlotInfo(new Date());
        if (nextInfo && nextInfo.secondsRemaining !== undefined) {
          this.checkAutomatedCountdownAlerts(nextInfo.secondsRemaining, nextInfo.label);
        }
      } catch (e) {}
'@

if ($content.Contains($targetTimerTick) -and -not $content.Contains("this.checkAutomatedCountdownAlerts(")) {
    $content = $content.Replace($targetTimerTick, $timerTickAddition)
    Write-Output "Added checkAutomatedCountdownAlerts to startTimerEngine"
}

# 7. Add cric-support-chat-modal to closeCricModals
$oldCloseCric = "'cric-download-modal'"
$newCloseCric = "'cric-download-modal',`n      'cric-support-chat-modal'"
if ($content.Contains($oldCloseCric) -and -not $content.Contains("'cric-support-chat-modal'")) {
    $content = $content.Replace($oldCloseCric, $newCloseCric)
    Write-Output "Added cric-support-chat-modal to closeCricModals"
}

# 8. Wire notification drawer button to request permission
$oldNotifBind = "document.getElementById('cric-row-notification')?.addEventListener('click', () => {"
$newNotifBind = @"
    document.getElementById('cric-row-notification')?.addEventListener('click', () => {
      this.closeCricDrawer();
      this.requestNotificationPermission();
    });
    const oldNotifPlaceholder = () => {
"@
if ($content.Contains($oldNotifBind) -and -not $content.Contains("this.requestNotificationPermission();")) {
    $content = $content.Replace($oldNotifBind, $newNotifBind)
    Write-Output "Wired cric-row-notification to requestNotificationPermission"
}

# 9. In applyServerState, merge supportChats
$targetApplyState = "    if (state.deposits !== undefined) {"
$chatsApplyAddition = @"
    if (state.supportChats !== undefined && typeof state.supportChats === 'object') {
      this.supportChats = { ...(this.supportChats || {}), ...state.supportChats };
      try { localStorage.setItem('spinwheel_support_chats', JSON.stringify(this.supportChats)); } catch (e) {}
      this.updateSupportChatBadges();
      if (this.adminTabChatsPane && !this.adminTabChatsPane.classList.contains('hidden')) {
        this.refreshSupportChatsUI();
      }
    }

    if (state.deposits !== undefined) {
"@
if ($content.Contains($targetApplyState) -and -not $content.Contains("state.supportChats !== undefined")) {
    $content = $content.Replace($targetApplyState, $chatsApplyAddition)
    Write-Output "Added supportChats state synchronization"
}

[System.IO.File]::WriteAllText($path, $content, [System.Text.Encoding]::UTF8)
Write-Output "Successfully updated app.js with Live Support Chat & Notification engines"

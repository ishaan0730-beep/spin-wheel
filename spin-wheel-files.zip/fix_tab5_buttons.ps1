$f = "C:\Users\ishaa\.gemini\antigravity-ide\scratch\spin-wheel-app\index.html"
$lines = [System.IO.File]::ReadAllLines($f, [System.Text.Encoding]::UTF8)
for ($i = 0; $i -lt $lines.Length; $i++) {
    if ($lines[$i] -match "admin-test-wa-btn-pane") {
        $lines[$i+1] = "                    📲 Test WhatsApp Alert"
    }
    if ($lines[$i] -match "admin-test-tg-btn-pane") {
        $lines[$i+1] = "                    ⚡ Send Test Telegram Alert"
    }
}
[System.IO.File]::WriteAllLines($f, $lines, [System.Text.Encoding]::UTF8)
Write-Host "Fixed index.html Tab 5 buttons!"

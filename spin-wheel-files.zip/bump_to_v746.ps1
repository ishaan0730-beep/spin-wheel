﻿$htmlPath = "C:\Users\ishaa\.gemini\antigravity-ide\scratch\spin-wheel-app\index.html"
$swPath = "C:\Users\ishaa\.gemini\antigravity-ide\scratch\spin-wheel-app\sw.js"

$htmlContent = [System.IO.File]::ReadAllText($htmlPath, [System.Text.Encoding]::UTF8)
$htmlContent = $htmlContent.Replace('app.js?v=7.4.5', 'app.js?v=7.4.6')
$htmlContent = $htmlContent.Replace('style.css?v=7.4.5', 'style.css?v=7.4.6')
[System.IO.File]::WriteAllText($htmlPath, $htmlContent, [System.Text.Encoding]::UTF8)

$swContent = [System.IO.File]::ReadAllText($swPath, [System.Text.Encoding]::UTF8)
$swContent = $swContent.Replace('spin-wheel-v7.4.5', 'spin-wheel-v7.4.6')
[System.IO.File]::WriteAllText($swPath, $swContent, [System.Text.Encoding]::UTF8)

Write-Host "Updated index.html and sw.js to v7.4.6"

$file = "C:\Users\ishaa\.gemini\antigravity-ide\scratch\spin-wheel-app\index.html"
$lines = [System.IO.File]::ReadAllLines($file, [System.Text.Encoding]::UTF8)

for ($i = 0; $i -lt $lines.Length; $i++) {
    if ($lines[$i] -like "*Account Statement / Passbook*") {
        $lines[$i] = '        <h3 style="color:#00f0ff; font-weight:800; font-size:1.15rem;">🏛️ Account Statement / Passbook</h3>'
        $lines[$i+1] = '        <button type="button" class="icon-btn" onclick="app.closeCricModals()">&times;</button>'
        $lines[$i+2] = '      </div>'
        $lines[$i+3] = '      <div class="modal-body" style="padding:1rem;">'
        # remove i+4 if duplicate
        $newLines = @()
        for ($j = 0; $j -lt $lines.Length; $j++) {
            if ($j -eq ($i + 4) -or $j -eq ($i + 5)) {
                # skip duplicate lines
            } else {
                $newLines += $lines[$j]
            }
        }
        [System.IO.File]::WriteAllLines($file, $newLines, [System.Text.Encoding]::UTF8)
        Write-Host "Cleaned modal 2 header perfectly!"
        break
    }
}

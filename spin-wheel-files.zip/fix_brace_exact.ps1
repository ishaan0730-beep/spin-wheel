﻿$path = "C:\Users\ishaa\.gemini\antigravity-ide\scratch\spin-wheel-app\app.js"
$lines = [System.IO.File]::ReadAllLines($path, [System.Text.Encoding]::UTF8)

for ($i = 0; $i -lt $lines.Length; $i++) {
    if ($lines[$i].Trim() -eq "this.renderLast3Results();" -and $lines[$i+1].Contains("renderAllSpinHistoryModalList")) {
        $lines[$i] = "    this.renderLast3Results();`r`n  }"
        Write-Host "Replaced at line $($i + 1)"
        break
    }
}

[System.IO.File]::WriteAllLines($path, $lines, [System.Text.Encoding]::UTF8)
Write-Host "File written"

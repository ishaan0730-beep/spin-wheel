﻿# Let us test index.html by injecting an automated test snippet into the live index.html runtime
$testSnippet = @"
<script>
window.addEventListener('load', async () => {
  const results = [];
  try {
    // 1. Check window.app
    if (window.app) results.push('PASS: window.app is defined');
    else results.push('FAIL: window.app is missing');

    // 2. Slices
    if (window.app.slices && window.app.slices.length === 10) results.push('PASS: 10 slices verified');
    else results.push('FAIL: slices count ' + window.app?.slices?.length);

    // 3. Current Countdown & Next Round
    const nextHour = document.getElementById('current-hour-display')?.textContent;
    const timer = document.getElementById('countdown-timer')?.textContent;
    results.push('INFO: Next Round: ' + nextHour + ' | Timer: ' + timer);

    // 4. History
    const h = window.app.history || [];
    const item12 = h.find(x => x.date && x.date.includes('Oct 7') && (x.round === '12:00 PM' || String(x.time).includes('12:00')));
    const item4 = h.find(x => x.date && x.date.includes('Oct 7') && (x.round === '04:00 PM' || String(x.time).includes('04:00') || String(x.time).includes('4:00')));
    results.push('INFO: Oct 7 12PM winner: #' + item12?.number + ' | Oct 7 4PM winner: #' + item4?.number);

    // 5. Reload button
    const reloadBtn = document.getElementById('cric-reload-btn');
    if (reloadBtn) results.push('PASS: Reload button in header exists');
    else results.push('FAIL: Reload button missing');

    // 6. Test handleReload execution
    await window.app.handleReload();
    results.push('PASS: handleReload executed successfully');

  } catch(e) {
    results.push('ERROR: ' + e.message);
  }

  const out = document.createElement('div');
  out.id = 'automated-test-summary';
  out.style.display = 'none';
  out.textContent = JSON.stringify(results);
  document.body.appendChild(out);
});
</script>
"@

$indexContent = [System.IO.File]::ReadAllText("C:\Users\ishaa\.gemini\antigravity-ide\scratch\spin-wheel-app\index.html", [System.Text.Encoding]::UTF8)
$testPageContent = $indexContent.Replace("</body>", $testSnippet + "</body>")
[System.IO.File]::WriteAllText("C:\Users\ishaa\.gemini\antigravity-ide\scratch\spin-wheel-app\test_live_system.html", $testPageContent, [System.Text.Encoding]::UTF8)

# Run Edge headless against test_live_system.html
$p = Start-Process -FilePath "C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe" -ArgumentList "--headless", "--disable-gpu", "--virtual-time-budget=4000", "--dump-dom", "http://localhost:3000/test_live_system.html" -NoNewWindow -PassThru -RedirectStandardOutput "test_live_out.html"
$p.WaitForExit(6000)
Get-Content test_live_out.html | Select-String -Pattern "automated-test-summary" -Context 0,2

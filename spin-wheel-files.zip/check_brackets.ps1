$c = [System.IO.File]::ReadAllText("$PSScriptRoot\app.js")
$openBrace = [regex]::Matches($c, '\{').Count
$closeBrace = [regex]::Matches($c, '\}').Count
$openParen = [regex]::Matches($c, '\(').Count
$closeParen = [regex]::Matches($c, '\)').Count
$openBracket = [regex]::Matches($c, '\[').Count
$closeBracket = [regex]::Matches($c, '\]').Count

Write-Host "Braces { }: $openBrace vs $closeBrace (Diff: $($openBrace - $closeBrace))"
Write-Host "Parens ( ): $openParen vs $closeParen (Diff: $($openParen - $closeParen))"
Write-Host "Brackets [ ]: $openBracket vs $closeBracket (Diff: $($openBracket - $closeBracket))"

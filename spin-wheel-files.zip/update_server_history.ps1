$path = "C:\Users\ishaa\.gemini\antigravity-ide\scratch\spin-wheel-app\server_state.json"
$state = Get-Content $path -Raw | ConvertFrom-Json
$state.history = @(
    [PSCustomObject]@{
        id = 1791346800000
        number = 50
        source = "Scheduled Round"
        round = "11:00 PM"
        date = "Oct 6"
        timestamp = 1791346800000
        time = "11:00 PM"
    },
    [PSCustomObject]@{
        id = 1791336000000
        number = 10
        source = "Scheduled Round"
        round = "08:00 PM"
        date = "Oct 6"
        timestamp = 1791336000000
        time = "08:00 PM"
    },
    [PSCustomObject]@{
        id = 1791321600000
        number = 30
        source = "Scheduled Round"
        round = "04:00 PM"
        date = "Oct 6"
        timestamp = 1791321600000
        time = "04:00 PM"
    }
)
$json = $state | ConvertTo-Json -Depth 10
[System.IO.File]::WriteAllText($path, $json)
Write-Host "server_state.json history updated successfully!"

$indexFile = "C:\Users\ishaa\.gemini\antigravity-ide\scratch\spin-wheel-app\index.html"
$cssFile = "C:\Users\ishaa\.gemini\antigravity-ide\scratch\spin-wheel-app\style.css"
$swFile = "C:\Users\ishaa\.gemini\antigravity-ide\scratch\spin-wheel-app\sw.js"
$jsFile = "C:\Users\ishaa\.gemini\antigravity-ide\scratch\spin-wheel-app\app.js"

# 1. Update index.html
$indexContent = [System.IO.File]::ReadAllText($indexFile, [System.Text.Encoding]::UTF8)
$indexContent = $indexContent.Replace('Redeem Your Promo Code', 'Promo Code:')
$indexContent = [System.Text.RegularExpressions.Regex]::Replace($indexContent, 'style\.css\?v=[0-9\.]+', 'style.css?v=7.4.2')
$indexContent = [System.Text.RegularExpressions.Regex]::Replace($indexContent, 'app\.js\?v=[0-9\.]+', 'app.js?v=7.4.2')
[System.IO.File]::WriteAllText($indexFile, $indexContent, [System.Text.Encoding]::UTF8)

# 2. Update sw.js
$swContent = [System.IO.File]::ReadAllText($swFile, [System.Text.Encoding]::UTF8)
$swContent = [System.Text.RegularExpressions.Regex]::Replace($swContent, "CACHE_NAME = 'spin-wheel-v[0-9\.]+'", "CACHE_NAME = 'spin-wheel-v7.4.2'")
[System.IO.File]::WriteAllText($swFile, $swContent, [System.Text.Encoding]::UTF8)

# 3. Update style.css for 100% mobile fit
$cssLines = [System.IO.File]::ReadAllLines($cssFile, [System.Text.Encoding]::UTF8)
$cssCustom = @'

/* ==========================================================
   MOBILE-FIRST TOP NAVBAR & PROMO BAR 100% FIT FIX (v7.4.2)
   ========================================================== */
@media (max-width: 600px) {
  .cric-header {
    padding: 6px 8px !important;
    gap: 4px !important;
    width: 100% !important;
    max-width: 100vw !important;
    box-sizing: border-box !important;
    overflow: hidden !important;
    justify-content: space-between !important;
  }

  .cric-header-left {
    gap: 4px !important;
    min-width: 0 !important;
    flex: 0 1 auto !important;
  }

  .cric-home-btn {
    display: flex !important;
    padding: 0 !important;
  }

  .cric-home-btn svg {
    width: 18px !important;
    height: 18px !important;
  }

  .cric-logo-text {
    font-size: 0.82rem !important;
    letter-spacing: 0.2px !important;
    font-weight: 800 !important;
    white-space: nowrap !important;
  }

  .cric-header-center {
    display: flex !important;
    align-items: center !important;
    flex-shrink: 0 !important;
  }

  .cric-top-deposit-btn {
    padding: 4px 8px !important;
    font-size: 0.68rem !important;
    border-radius: 12px !important;
    gap: 3px !important;
    font-weight: 800 !important;
    letter-spacing: 0.3px !important;
  }

  .cric-top-deposit-btn svg {
    width: 12px !important;
    height: 12px !important;
  }

  .cric-header-right {
    gap: 4px !important;
    flex-shrink: 0 !important;
  }

  .cric-balance-pill {
    padding: 4px 7px !important;
    font-size: 0.70rem !important;
    border-radius: 12px !important;
    gap: 3px !important;
    max-width: 95px !important;
  }

  .cric-balance-val {
    font-size: 0.70rem !important;
    font-weight: 800 !important;
  }

  .cric-login-btn {
    padding: 4px 8px !important;
    font-size: 0.68rem !important;
    border-radius: 12px !important;
  }

  /* Hide secondary header buttons on narrow mobile so essential buttons never clip */
  #sound-btn,
  #cric-header-chat-btn,
  #cric-search-btn,
  #cric-lang-btn {
    display: none !important;
  }

  .cric-hamburger-btn {
    width: 22px !important;
    height: 20px !important;
    padding: 1px !important;
  }

  /* Promo Strip 100% Fit */
  .cric-promo-strip {
    padding: 5px 8px !important;
    gap: 6px !important;
    width: 100% !important;
    max-width: 100vw !important;
    box-sizing: border-box !important;
    overflow: hidden !important;
    display: flex !important;
    align-items: center !important;
    justify-content: space-between !important;
  }

  .cric-promo-label {
    font-size: 0.70rem !important;
    white-space: nowrap !important;
    flex-shrink: 0 !important;
    color: #ffd700 !important;
    font-weight: 800 !important;
  }

  .cric-promo-input-group {
    display: flex !important;
    align-items: center !important;
    gap: 4px !important;
    flex: 1 !important;
    min-width: 0 !important;
    max-width: 210px !important;
  }

  .cric-promo-input {
    width: 100% !important;
    flex: 1 !important;
    min-width: 0 !important;
    padding: 4px 6px !important;
    font-size: 0.70rem !important;
    border-radius: 5px !important;
    box-sizing: border-box !important;
  }

  .cric-promo-apply-btn {
    padding: 4px 10px !important;
    font-size: 0.70rem !important;
    font-weight: 800 !important;
    border-radius: 5px !important;
    flex-shrink: 0 !important;
  }

  /* Status Banner Fit */
  .hourly-status-bar {
    width: 100% !important;
    max-width: 100% !important;
    box-sizing: border-box !important;
    padding: 6px !important;
    gap: 4px !important;
  }

  .status-item {
    padding: 6px 4px !important;
  }

  .status-label {
    font-size: 0.58rem !important;
  }

  .status-value {
    font-size: 0.78rem !important;
  }
}
'@

$newCss = [System.IO.File]::ReadAllText($cssFile, [System.Text.Encoding]::UTF8) + "`n" + $cssCustom
[System.IO.File]::WriteAllText($cssFile, $newCss, [System.Text.Encoding]::UTF8)

Write-Host "All files updated cleanly!"

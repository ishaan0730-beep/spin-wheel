$appPath = "C:\Users\ishaa\.gemini\antigravity-ide\scratch\spin-wheel-app\app.js"
$content = [System.IO.File]::ReadAllText($appPath, [System.Text.Encoding]::UTF8)

# 1. Update loadLocalNotificationConfig defaults
$oldNotifBlock = @"
  loadLocalNotificationConfig() {
    try {
      const saved = localStorage.getItem(STATE_KEYS.NOTIFICATION_CONFIG);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed && typeof parsed === 'object') {
          return {
            telegramBotToken: parsed.telegramBotToken || '',
            telegramChatId: parsed.telegramChatId || '8187881990',
            telegramEnabled: parsed.telegramEnabled !== false,
            whatsappNumber: parsed.whatsappNumber || '7690900087',
            whatsappApiKey: parsed.whatsappApiKey || '',
            whatsappEnabled: parsed.whatsappEnabled !== false
          };
        }
      }
    } catch (e) {}
    return {
      telegramBotToken: '',
      telegramChatId: '8187881990',
      telegramEnabled: true,
      whatsappNumber: '7690900087',
      whatsappApiKey: '',
      whatsappEnabled: true
    };
  }
"@

$newNotifBlock = @"
  loadLocalNotificationConfig() {
    try {
      const saved = localStorage.getItem(STATE_KEYS.NOTIFICATION_CONFIG);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed && typeof parsed === 'object') {
          return {
            telegramBotToken: parsed.telegramBotToken || '8932355449:AAHCkhZKUMt',
            telegramChatId: parsed.telegramChatId || '8187881990',
            telegramEnabled: parsed.telegramEnabled !== false,
            whatsappNumber: parsed.whatsappNumber || '7690900087',
            whatsappApiKey: parsed.whatsappApiKey || '',
            whatsappEnabled: parsed.whatsappEnabled !== false
          };
        }
      }
    } catch (e) {}
    return {
      telegramBotToken: '8932355449:AAHCkhZKUMt',
      telegramChatId: '8187881990',
      telegramEnabled: true,
      whatsappNumber: '7690900087',
      whatsappApiKey: '',
      whatsappEnabled: true
    };
  }
"@

if ($content.Contains($oldNotifBlock)) {
    $content = $content.Replace($oldNotifBlock, $newNotifBlock)
    Write-Host "Updated loadLocalNotificationConfig successfully!"
} else {
    Write-Host "Old loadLocalNotificationConfig not found by exact string, checking regex..."
}

# 2. Update populateMasterConfigInputs
$oldPopulate = "const tgTokenVal = notifCfg.telegramBotToken || '';"
$newPopulate = "const tgTokenVal = notifCfg.telegramBotToken || '8932355449:AAHCkhZKUMt';"
if ($content.Contains($oldPopulate)) {
    $content = $content.Replace($oldPopulate, $newPopulate)
    Write-Host "Updated populateMasterConfigInputs default token!"
}

# 3. Replace Customer Deposit Success (Remove WhatsApp button & phone)
$regexDepSuccess = [regex]'(?s)if \(this\.custDepositSuccess\) \{\s*this\.custDepositSuccess\.innerHTML = `.*?`;\s*this\.custDepositSuccess\.classList\.remove\(''hidden''\);\s*\}'

$newDepSuccess = @"
if (this.custDepositSuccess) {
      this.custDepositSuccess.innerHTML = `
        <div style="background:rgba(46,204,113,0.12); border:1px solid rgba(46,204,113,0.4); border-radius:8px; padding:0.75rem; text-align:center;">
          <div style="font-size:0.92rem; font-weight:800; color:#2ecc71; margin-bottom:0.35rem;">
            ✅ Deposit Request of ₹${amountVal.toLocaleString()} Submitted!
          </div>
          <div style="font-size:0.78rem; color:var(--text-secondary); line-height:1.4;">
            Status: <b style="color:#ffd700;">PENDING APPROVAL BY MASTER</b> (UTR: <code style="color:#00f0ff;">${utrVal}</code>)<br>
            Your coin balance will be updated automatically as soon as Master verifies the payment.
          </div>
        </div>
      `;
      this.custDepositSuccess.classList.remove('hidden');
    }
"@

# Let's perform precise string replacement for Deposit Success
$oldDepHtml = @"
    if (this.custDepositSuccess) {
      this.custDepositSuccess.innerHTML = `
        <div style="font-size:0.85rem; font-weight:700; color:#2ecc71; margin-bottom:0.35rem;">
          ✅ Deposit request of ₹${amountVal.toLocaleString()} submitted!
        </div>
        <div style="font-size:0.75rem; color:var(--text-secondary); margin-bottom:0.6rem;">
          Status: <b>PENDING APPROVAL BY MASTER</b> (UTR: <code>${utrVal}</code>)
        </div>
        <a href="${waDepLink}" target="_blank" rel="noopener noreferrer" style="display:inline-flex; align-items:center; justify-content:center; gap:6px; background:#25D366; color:#000; font-weight:800; font-size:0.82rem; padding:0.5rem 1rem; border-radius:8px; text-decoration:none; box-shadow:0 4px 12px rgba(37,211,102,0.35); margin-top:2px;">
          📲 Send Screenshot to Master on WhatsApp (+91 7690900087)
        </a>
      `;
      this.custDepositSuccess.classList.remove('hidden');
    }
"@

if ($content.Contains($oldDepHtml)) {
    $content = $content.Replace($oldDepHtml, $newDepSuccess)
    Write-Host "Removed WhatsApp button from Deposit Success successfully!"
} else {
    Write-Host "Warning: oldDepHtml exact string not found, attempting regex..."
    $content = [regex]::Replace($content, '(?s)if \(this\.custDepositSuccess\) \{\s*this\.custDepositSuccess\.innerHTML = `\s*<div style="font-size:0.85rem;.*?</a>\s*`;\s*this\.custDepositSuccess\.classList\.remove\(''hidden''\);\s*\}', $newDepSuccess)
}

# 4. Replace Customer Withdrawal Success (Remove WhatsApp button & phone)
$oldWdHtml = @"
    if (this.custWithdrawSuccess) {
      this.custWithdrawSuccess.innerHTML = `
        <div style="font-size:0.85rem; font-weight:700; color:#2ecc71; margin-bottom:0.35rem;">
          ✅ Withdrawal request of 💰${amountVal.toLocaleString()} IHD Coins submitted!
        </div>
        <div style="font-size:0.75rem; color:var(--text-secondary); margin-bottom:0.6rem;">
          Status: <b>PENDING TRANSFER BY MASTER</b>
        </div>
        <a href="${waWdLink}" target="_blank" rel="noopener noreferrer" style="display:inline-flex; align-items:center; justify-content:center; gap:6px; background:#25D366; color:#000; font-weight:800; font-size:0.82rem; padding:0.5rem 1rem; border-radius:8px; text-decoration:none; box-shadow:0 4px 12px rgba(37,211,102,0.35); margin-top:2px;">
          📲 Send Details to Master on WhatsApp (+91 7690900087)
        </a>
      `;
      this.custWithdrawSuccess.classList.remove('hidden');
    }
"@

$newWdSuccess = @"
if (this.custWithdrawSuccess) {
      this.custWithdrawSuccess.innerHTML = `
        <div style="background:rgba(46,204,113,0.12); border:1px solid rgba(46,204,113,0.4); border-radius:8px; padding:0.75rem; text-align:center;">
          <div style="font-size:0.92rem; font-weight:800; color:#2ecc71; margin-bottom:0.35rem;">
            ✅ Withdrawal Request of 💰${amountVal.toLocaleString()} IHD Coins Submitted!
          </div>
          <div style="font-size:0.78rem; color:var(--text-secondary); line-height:1.4;">
            Status: <b style="color:#ffd700;">PENDING TRANSFER BY MASTER</b><br>
            Amount will be transferred directly to Bank A/C: <code>${accountNumber}</code> (${ifscCode}).
          </div>
        </div>
      `;
      this.custWithdrawSuccess.classList.remove('hidden');
    }
"@

if ($content.Contains($oldWdHtml)) {
    $content = $content.Replace($oldWdHtml, $newWdSuccess)
    Write-Host "Removed WhatsApp button from Withdrawal Success successfully!"
} else {
    Write-Host "Warning: oldWdHtml exact string not found, attempting regex..."
    $content = [regex]::Replace($content, '(?s)if \(this\.custWithdrawSuccess\) \{\s*this\.custWithdrawSuccess\.innerHTML = `\s*<div style="font-size:0.85rem;.*?</a>\s*`;\s*this\.custWithdrawSuccess\.classList\.remove\(''hidden''\);\s*\}', $newWdSuccess)
}

[System.IO.File]::WriteAllText($appPath, $content, (New-Object System.Text.UTF8Encoding $false))
Write-Host "Saved app.js successfully!"

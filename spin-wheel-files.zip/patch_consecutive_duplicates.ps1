$jsFile = 'C:\Users\ishaa\.gemini\antigravity-ide\scratch\spin-wheel-app\app.js'
$apiFile = 'C:\Users\ishaa\.gemini\antigravity-ide\scratch\spin-wheel-app\api\state.js'
$indexFile = 'C:\Users\ishaa\.gemini\antigravity-ide\scratch\spin-wheel-app\index.html'
$swFile = 'C:\Users\ishaa\.gemini\antigravity-ide\scratch\spin-wheel-app\sw.js'

# 1. Update api/state.js to strictly prevent consecutive duplicate winning numbers
$apiLines = [System.IO.File]::ReadAllLines($apiFile, [System.Text.Encoding]::UTF8)

for ($i = 0; $i -lt $apiLines.Length; $i++) {
    if ($apiLines[$i] -match "if \(winningNum === null\)\s*\{") {
        $apiLines[$i+1] = "            let hash = 0;"
        $apiLines[$i+2] = "            const str = `${dateStr}_${slotLabel}_lucky_salt_v8`;"
        $apiLines[$i+3] = "            for (let k = 0; k < str.length; k++) {"
        $apiLines[$i+4] = "              hash = ((hash << 5) - hash) + str.charCodeAt(k);"
        $apiLines[$i+5] = "              hash |= 0;"
        $apiLines[$i+6] = "            }"
        $apiLines[$i+7] = "            let idx = (Math.abs(hash) + (dayOffset * 3)) % slices.length;"
        $apiLines[$i+8] = "            winningNum = slices[idx];"
        $apiLines[$i+9] = "            const prev = (globalState.history || [])[0];"
        $apiLines[$i+10] = "           if (prev && prev.number === winningNum) winningNum = slices[(idx + 3) % slices.length];"
        break
    }
}

# Also sanitize globalState.history in api/state.js to fix any existing duplicate numbers in history
for ($i = 0; $i -lt $apiLines.Length; $i++) {
    if ($apiLines[$i] -match "globalState\.history = Array\.from\(histMap\.values\(\)\)") {
        $apiLines[$i+1] = "      .sort((a, b) => (b.timestamp || b.id || 0) - (a.timestamp || a.id || 0))"
        $apiLines[$i+2] = "      .slice(0, 150);"
        $apiLines[$i+3] = "    for (let hIdx = 0; hIdx < globalState.history.length; hIdx++) {"
        $apiLines[$i+4] = "      if (hIdx > 0 && globalState.history[hIdx - 1]) {"
        $apiLines[$i+5] = "        if (globalState.history[hIdx].number === globalState.history[hIdx - 1].number) {"
        $apiLines[$i+6] = "          const curI = slices.indexOf(Number(globalState.history[hIdx].number));"
        $apiLines[$i+7] = "          globalState.history[hIdx].number = slices[(curI + 3) % slices.length];"
        $apiLines[$i+8] = "        }"
        $apiLines[$i+9] = "      }"
        $apiLines[$i+10] = "    }"
        break
    }
}

[System.IO.File]::WriteAllLines($apiFile, $apiLines, [System.Text.Encoding]::UTF8)
Write-Host "api/state.js updated with duplicate number prevention!"

# 2. Update app.js settleElapsedSlots & history deduplication
$jsLines = [System.IO.File]::ReadAllLines($jsFile, [System.Text.Encoding]::UTF8)

for ($i = 0; $i -lt $jsLines.Length; $i++) {
    if ($jsLines[$i] -match "if \(winningNum === null\)\s*\{" -and $i -gt 8000) {
        $jsLines[$i+1] = "              let hash = 0;"
        $jsLines[$i+2] = "              const str = `${dateStr}_${slotLabel}_lucky_salt_v8`;"
        $jsLines[$i+3] = "              for (let k = 0; k < str.length; k++) {"
        $jsLines[$i+4] = "                hash = ((hash << 5) - hash) + str.charCodeAt(k);"
        $jsLines[$i+5] = "                hash |= 0;"
        $jsLines[$i+6] = "              }"
        $jsLines[$i+7] = "              let idx = (Math.abs(hash) + (dayOffset * 3)) % slices.length;"
        $jsLines[$i+8] = "              winningNum = slices[idx];"
        $jsLines[$i+9] = "              const prev = (this.history || [])[0];"
        $jsLines[$i+10] = "             if (prev && prev.number === winningNum) winningNum = slices[(idx + 3) % slices.length];"
        break
    }
}

# Sanitize local history so no two consecutive entries have identical numbers
for ($i = 0; $i -lt $jsLines.Length; $i++) {
    if ($jsLines[$i] -match "this\.history = state\.history;") {
        $sanitizeBlock = @'
          const rawHist = state.history || [];
          for (let hIdx = 0; hIdx < rawHist.length; hIdx++) {
            if (hIdx > 0 && rawHist[hIdx - 1]) {
              if (rawHist[hIdx].number === rawHist[hIdx - 1].number) {
                const curI = this.slices.indexOf(Number(rawHist[hIdx].number));
                rawHist[hIdx].number = this.slices[(curI + 3) % this.slices.length];
              }
            }
          }
          this.history = rawHist;
'@
        $jsLines[$i] = $sanitizeBlock
        break
    }
}

[System.IO.File]::WriteAllLines($jsFile, $jsLines, [System.Text.Encoding]::UTF8)
Write-Host "app.js updated with duplicate number sanitizer!"

# 3. Bump version to v7.4.5 in index.html and sw.js
$indexContent = [System.IO.File]::ReadAllText($indexFile, [System.Text.Encoding]::UTF8)
$indexContent = [System.Text.RegularExpressions.Regex]::Replace($indexContent, 'style\.css\?v=[0-9\.]+', 'style.css?v=7.4.5')
$indexContent = [System.Text.RegularExpressions.Regex]::Replace($indexContent, 'app\.js\?v=[0-9\.]+', 'app.js?v=7.4.5')
[System.IO.File]::WriteAllText($indexFile, $indexContent, [System.Text.Encoding]::UTF8)

$swContent = [System.IO.File]::ReadAllText($swFile, [System.Text.Encoding]::UTF8)
$swContent = [System.Text.RegularExpressions.Regex]::Replace($swContent, "CACHE_NAME = 'spin-wheel-v[0-9\.]+'", "CACHE_NAME = 'spin-wheel-v7.4.5'")
[System.IO.File]::WriteAllText($swFile, $swContent, [System.Text.Encoding]::UTF8)

Write-Host "All files updated to v7.4.5"

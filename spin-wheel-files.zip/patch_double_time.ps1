$jsFile = 'C:\Users\ishaa\.gemini\antigravity-ide\scratch\spin-wheel-app\app.js'
$cssFile = 'C:\Users\ishaa\.gemini\antigravity-ide\scratch\spin-wheel-app\style.css'
$indexFile = 'C:\Users\ishaa\.gemini\antigravity-ide\scratch\spin-wheel-app\index.html'
$swFile = 'C:\Users\ishaa\.gemini\antigravity-ide\scratch\spin-wheel-app\sw.js'

$jsLines = [System.IO.File]::ReadAllLines($jsFile, [System.Text.Encoding]::UTF8)

# 1. Replace renderLast3Results
$startR = -1
$endR = -1
for ($i = 0; $i -lt $jsLines.Length; $i++) {
    if ($jsLines[$i] -match "renderLast3Results\(\)\s*\{") {
        $startR = $i
    }
    if ($startR -ge 0 -and $jsLines[$i] -match "openAllSpinHistoryModal\(\)\s*\{") {
        $endR = $i
        break
    }
}

$newRenderLast3 = @'
  renderLast3Results() {
    if (!this.resultsGrid) return;
    this.resultsGrid.innerHTML = '';
    const last3 = (this.history || []).slice(0, 3);
    const ranks = ['1st Previous', '2nd Previous', '3rd Previous'];

    for (let i = 0; i < 3; i++) {
      const card = document.createElement('div');
      const item = last3[i];

      if (item) {
        card.className = `result-card ${i === 0 ? 'latest-win' : ''}`;
        const displayDate = item.date ? `${item.date} • ` : '';
        const displayTime = item.time || item.round || 'Completed';
        card.innerHTML = `
          <div class="result-rank">${i === 0 ? '🏆 Latest Winner' : ranks[i]}</div>
          <div class="result-number">${item.number}</div>
          <div class="result-meta">${displayDate}${displayTime}</div>
        `;
      } else {
        card.className = 'result-card empty-card';
        card.innerHTML = `
          <div class="result-rank">${ranks[i]}</div>
          <div class="result-number">--</div>
          <div class="result-meta">Awaiting Spin</div>
        `;
      }
      this.resultsGrid.appendChild(card);
    }

    if (this.allHistoryCountBadge) {
      this.allHistoryCountBadge.textContent = (this.history || []).length;
    }
  }

'@

if ($startR -ge 0 -and $endR -gt $startR) {
    $before = $jsLines[0..($startR - 1)]
    $after = $jsLines[$endR..($jsLines.Length - 1)]
    $jsLines = @($before) + @($newRenderLast3) + @($after)
}

# 2. Replace renderAllSpinHistoryModalList
$startM = -1
$endM = -1
for ($i = 0; $i -lt $jsLines.Length; $i++) {
    if ($jsLines[$i] -match "renderAllSpinHistoryModalList\(") {
        $startM = $i
    }
    if ($startM -ge 0 -and $jsLines[$i] -match "renderAdminSpinHistoryTable\(") {
        $endM = $i
        break
    }
}

$newRenderModal = @'
  renderAllSpinHistoryModalList(searchQuery = '', slotFilter = 'ALL') {
    const list = Array.isArray(this.history) ? this.history : [];
    const totalCount = list.length;

    if (this.allHistoryCountBadge) this.allHistoryCountBadge.textContent = totalCount;
    if (this.modalAllHistoryCount) this.modalAllHistoryCount.textContent = totalCount;

    if (!this.allHistoryTableBody) return;

    const q = (searchQuery || '').toLowerCase().trim();
    const filtered = list.filter(item => {
      if (!item) return false;
      if (slotFilter && slotFilter !== 'ALL') {
        const itemRound = (item.round || '').trim();
        const itemTime = (item.time || '').trim();
        if (itemRound !== slotFilter && !itemTime.includes(slotFilter)) return false;
      }
      if (!q) return true;
      const numStr = String(item.number || '');
      const roundStr = String(item.round || '').toLowerCase();
      const dateStr = String(item.date || '').toLowerCase();
      const timeStr = String(item.time || '').toLowerCase();
      const sourceStr = String(item.source || '').toLowerCase();
      return numStr.includes(q) || roundStr.includes(q) || dateStr.includes(q) || timeStr.includes(q) || sourceStr.includes(q);
    });

    if (filtered.length === 0) {
      this.allHistoryTableBody.innerHTML = `
        <tr>
          <td colspan="4" style="text-align:center; color:var(--text-muted); padding:1.2rem;">
            ${totalCount === 0 ? 'No spin rounds recorded yet.' : 'No spin results match the search/filter.'}
          </td>
        </tr>
      `;
      return;
    }

    this.allHistoryTableBody.innerHTML = '';
    filtered.forEach((item, idx) => {
      const tr = document.createElement('tr');
      const isLatest = (idx === 0);

      tr.innerHTML = `
        <td style="white-space:nowrap;">
          <div style="display:flex; align-items:center; gap:6px;">
            <strong style="color:var(--primary-gold-bright); font-size:0.84rem;">${item.round || item.time || 'Round'}</strong>
            ${isLatest ? '<span class="status-pill status-approved" style="font-size:0.60rem; padding:1px 5px;">Latest</span>' : ''}
          </div>
        </td>
        <td style="text-align:center; white-space:nowrap;">
          <span style="background:var(--primary-gold-gradient, linear-gradient(135deg, #ffd700, #f5b041)); color:#000; font-weight:900; padding:3px 10px; border-radius:12px; font-size:0.86rem; display:inline-block; box-shadow:0 0 8px rgba(245,176,65,0.4);">
            #${item.number}
          </span>
        </td>
        <td style="white-space:nowrap;">
          <span style="color:#f8fafc; font-weight:600; font-size:0.78rem;">${item.date || ''}</span>
        </td>
        <td style="white-space:nowrap;">
          <span style="font-size:0.68rem; color:#00f0ff; background:rgba(0,240,255,0.1); border:1px solid rgba(0,240,255,0.25); padding:2px 7px; border-radius:4px; font-weight:700;">
            ${item.source || 'Live Round'}
          </span>
        </td>
      `;
      this.allHistoryTableBody.appendChild(tr);
    });
  }

'@

if ($startM -ge 0 -and $endM -gt $startM) {
    $before = $jsLines[0..($startM - 1)]
    $after = $jsLines[$endM..($jsLines.Length - 1)]
    $jsLines = @($before) + @($newRenderModal) + @($after)
}

[System.IO.File]::WriteAllLines($jsFile, $jsLines, [System.Text.Encoding]::UTF8)

# 3. Update style.css
$cssCustom = @'

/* Complete Spin History Table Enhancements */
#all-spin-history-modal .schedule-table th,
#all-spin-history-modal .schedule-table td {
  white-space: nowrap !important;
  padding: 8px 10px !important;
}

#all-spin-history-modal .modal-card {
  max-width: 520px !important;
}
'@

$cssContent = [System.IO.File]::ReadAllText($cssFile, [System.Text.Encoding]::UTF8) + "`n" + $cssCustom
[System.IO.File]::WriteAllText($cssFile, $cssContent, [System.Text.Encoding]::UTF8)

# 4. Bump version to v7.4.4
$indexContent = [System.IO.File]::ReadAllText($indexFile, [System.Text.Encoding]::UTF8)
$indexContent = [System.Text.RegularExpressions.Regex]::Replace($indexContent, 'style\.css\?v=[0-9\.]+', 'style.css?v=7.4.4')
$indexContent = [System.Text.RegularExpressions.Regex]::Replace($indexContent, 'app\.js\?v=[0-9\.]+', 'app.js?v=7.4.4')
[System.IO.File]::WriteAllText($indexFile, $indexContent, [System.Text.Encoding]::UTF8)

$swContent = [System.IO.File]::ReadAllText($swFile, [System.Text.Encoding]::UTF8)
$swContent = [System.Text.RegularExpressions.Regex]::Replace($swContent, "CACHE_NAME = 'spin-wheel-v[0-9\.]+'", "CACHE_NAME = 'spin-wheel-v7.4.4'")
[System.IO.File]::WriteAllText($swFile, $swContent, [System.Text.Encoding]::UTF8)

Write-Host "app.js, style.css, index.html, and sw.js updated successfully!"

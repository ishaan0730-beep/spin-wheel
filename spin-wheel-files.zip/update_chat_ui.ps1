$path = "C:\Users\ishaa\.gemini\antigravity-ide\scratch\spin-wheel-app\app.js"
$content = [System.IO.File]::ReadAllText($path, [System.Text.Encoding]::UTF8)

# Target pattern: from 'refreshSupportChatsUI() {' to 'updateSupportChatBadges() {'
$targetPattern = '(?s)refreshSupportChatsUI\(\) \{.*?updateSupportChatBadges\(\) \{'

$replacement = @'
refreshSupportChatsUI() {
    const listEl = document.getElementById('admin-chat-threads-list');
    const feedEl = document.getElementById('admin-chat-messages-wrap') || document.getElementById('admin-chat-messages-feed');
    const nameEl = document.getElementById('admin-selected-chat-name');
    const subEl = document.getElementById('admin-selected-chat-sub');
    const actionsEl = document.getElementById('admin-selected-chat-actions');
    const countEl = document.getElementById('admin-active-chats-count');
    if (!listEl) return;

    if (!this.supportChats || typeof this.supportChats !== 'object') {
      this.supportChats = {};
    }
    const chats = this.supportChats;
    const customers = (this.customersDb && typeof this.customersDb === 'object') ? this.customersDb : {};

    // Get all unique player IDs from both support chats and registered customers database
    const chatPids = Object.keys(chats);
    const dbPids = Object.keys(customers);
    const allPids = Array.from(new Set([...chatPids, ...dbPids]));

    if (countEl) countEl.textContent = allPids.length;

    if (allPids.length === 0) {
      listEl.innerHTML = `
        <div style="padding:1.5rem; text-align:center; color:var(--text-muted); font-size:0.8rem; line-height:1.5;">
          <div style="font-size:1.4rem; margin-bottom:6px;">💬</div>
          <strong>No Active Inquiries Yet</strong><br>
          <span style="font-size:0.75rem; color:var(--text-secondary);">When players register or send support messages, they will appear here live with instant sound alert.</span>
          <div style="margin-top:10px;">
            <button type="button" class="btn btn-gold btn-xs" onclick="window.app.adminPromptStartNewChat()">➕ Message a Player ID</button>
          </div>
        </div>
      `;
      if (feedEl) {
        feedEl.innerHTML = `
          <div style="padding:2.5rem 1.5rem; text-align:center; color:var(--text-muted); font-size:0.85rem;">
            <div style="font-size:2rem; margin-bottom:8px;">🎧</div>
            <strong style="color:#fff; font-size:0.95rem;">Customer Live Support Desk Ready</strong>
            <p style="margin-top:6px; color:var(--text-secondary); font-size:0.78rem;">
              You can reply to customer inquiries, send deposit confirmations, or click below to message any player directly.
            </p>
            <button type="button" class="btn btn-gold btn-sm" style="margin-top:10px;" onclick="window.app.adminPromptStartNewChat()">➕ Start Direct Chat with Player</button>
          </div>
        `;
      }
      if (nameEl) nameEl.textContent = 'Select a conversation';
      if (subEl) subEl.textContent = 'Click any player from the list to view and reply';
      if (actionsEl) actionsEl.classList.add('hidden');
      return;
    }

    // Auto-select first thread if none selected or currently selected is invalid
    if (!this.selectedChatPlayerId || !allPids.includes(this.selectedChatPlayerId)) {
      this.selectedChatPlayerId = allPids[0];
    }

    // Sort players: unread messages first, then latest message timestamp, then alphabetical
    const sortedPids = [...allPids].sort((a, b) => {
      const threadA = chats[a] || [];
      const threadB = chats[b] || [];
      const unreadA = threadA.filter(m => m.sender === 'CUSTOMER' && !m.readByAdmin).length;
      const unreadB = threadB.filter(m => m.sender === 'CUSTOMER' && !m.readByAdmin).length;
      if (unreadB !== unreadA) return unreadB - unreadA;

      const lastA = threadA[threadA.length - 1]?.timestamp || 0;
      const lastB = threadB[threadB.length - 1]?.timestamp || 0;
      return lastB - lastA;
    });

    // Render thread list in left sidebar
    listEl.innerHTML = sortedPids.map(pid => {
      const cust = customers[pid] || {};
      const thread = chats[pid] || [];
      const lastMsg = thread[thread.length - 1] || {};
      const isSel = this.selectedChatPlayerId === pid;
      const unreadCount = thread.filter(m => m.sender === 'CUSTOMER' && !m.readByAdmin).length;
      const displayName = cust.name || lastMsg.playerName || pid;
      const displayCoins = (cust.coins !== undefined) ? ` • 💰₹${Number(cust.coins).toFixed(2)}` : '';
      const previewText = lastMsg.text ? (lastMsg.sender === 'ADMIN' ? '👑 You: ' + lastMsg.text : lastMsg.text) : '💬 Registered Player (Tap to chat)';

      return `
        <div class="admin-chat-thread-item ${isSel ? 'active' : ''}" style="padding:10px 12px; border-bottom:1px solid var(--border-subtle); cursor:pointer; background:${isSel ? 'rgba(217,119,6,0.22)' : 'transparent'}; border-left:${isSel ? '3px solid #f59e0b' : '3px solid transparent'}; transition:background 0.15s ease;" onclick="window.app.selectAdminChatPlayer('${pid}')">
          <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:3px;">
            <span style="font-weight:700; color:#f8fafc; font-size:0.85rem; display:flex; align-items:center; gap:5px;">
              👤 ${this.escapeHTML(displayName)}
            </span>
            <span style="font-size:0.68rem; color:var(--text-muted);">${lastMsg.timeFormatted || ''}</span>
          </div>
          <div style="font-size:0.7rem; color:var(--text-secondary); margin-bottom:3px;">
            ID: <span style="color:#00f0ff; font-family:monospace;">${pid}</span>${displayCoins}
          </div>
          <div style="display:flex; justify-content:space-between; align-items:center;">
            <div style="font-size:0.75rem; color:#cbd5e1; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; max-width:170px;">
              ${this.escapeHTML(previewText)}
            </div>
            ${unreadCount > 0 ? `<span style="background:#e11d48; color:#fff; font-size:10px; font-weight:800; padding:1px 6px; border-radius:10px; box-shadow:0 0 8px rgba(225,29,72,0.6);">${unreadCount} NEW</span>` : ''}
          </div>
        </div>
      `;
    }).join('');

    // If active player selected, render conversation feed on right
    if (this.selectedChatPlayerId) {
      const pid = this.selectedChatPlayerId;
      const cust = customers[pid] || {};
      const thread = chats[pid] || [];
      const firstMsg = thread[0] || {};
      const displayName = cust.name || firstMsg.playerName || pid;
      const displayMobile = cust.mobile || firstMsg.playerMobile || 'N/A';
      const displayCoins = (cust.coins !== undefined) ? Number(cust.coins).toFixed(2) : '0.00';

      if (nameEl) nameEl.innerHTML = `👤 <b>${this.escapeHTML(displayName)}</b> <span style="font-size:0.75rem; color:#ffd700; font-weight:700; margin-left:6px;">(Wallet: ₹${displayCoins})</span>`;
      if (subEl) subEl.textContent = `Player ID: ${pid} • Mobile: ${displayMobile}`;
      if (actionsEl) {
        actionsEl.classList.remove('hidden');
        actionsEl.innerHTML = `
          <div style="display:flex; gap:6px; flex-wrap:wrap;">
            <button type="button" class="btn btn-gold btn-xs" onclick="window.app.quickCreditSelectedPlayer()">💰 Quick Credit</button>
            <button type="button" class="btn btn-secondary btn-xs" onclick="window.app.adminSetPlayerExactCoins('${pid}', prompt('Enter new exact coin balance for ${pid}:', '${displayCoins}'))">🎯 Set Balance</button>
            <button type="button" class="btn btn-secondary btn-xs" style="color:#ff6b6b;" onclick="window.app.clearSelectedChatThread('${pid}')" title="Clear chat history for this player">🗑️ Clear</button>
          </div>
        `;
      }

      if (feedEl) {
        if (thread.length === 0) {
          feedEl.innerHTML = `
            <div style="padding:2rem 1rem; text-align:center; color:var(--text-muted); font-size:0.82rem;">
              <div style="font-size:1.8rem; margin-bottom:6px;">💬</div>
              <strong style="color:#fff;">Direct Channel with ${this.escapeHTML(displayName)}</strong>
              <p style="margin-top:4px; font-size:0.75rem; color:var(--text-secondary);">No messages sent yet. Use the quick reply chips below or type a custom message to greet the player.</p>
            </div>
          `;
        } else {
          feedEl.innerHTML = thread.map(m => {
            const isAdmin = m.sender === 'ADMIN';
            return `
              <div class="chat-msg ${isAdmin ? 'chat-msg-admin' : 'chat-msg-user'}" style="margin-bottom:10px; display:flex; flex-direction:column; align-items:${isAdmin ? 'flex-end' : 'flex-start'};">
                <div style="font-size:0.7rem; color:var(--text-muted); margin-bottom:2px; display:flex; align-items:center; gap:5px;">
                  <span>${isAdmin ? '👑 You (Master Admin)' : '👤 ' + this.escapeHTML(m.playerName || pid)}</span>
                </div>
                <div style="background:${isAdmin ? 'linear-gradient(135deg, #d97706, #b45309)' : 'rgba(255,255,255,0.1)'}; color:#fff; padding:8px 14px; border-radius:12px; max-width:80%; word-break:break-word; font-size:0.85rem; line-height:1.4; border:${isAdmin ? '1px solid rgba(245,158,11,0.4)' : '1px solid rgba(255,255,255,0.15)'};">
                  ${this.escapeHTML(m.text)}
                </div>
                <div style="font-size:0.65rem; color:var(--text-muted); margin-top:2px;">
                  ${m.timeFormatted || (m.timestamp ? new Date(m.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '')}
                </div>
              </div>
            `;
          }).join('');
          feedEl.scrollTop = feedEl.scrollHeight;
        }
      }
    }
  }

  adminPromptStartNewChat() {
    const pid = prompt('Enter Registered Player ID or Username to start direct Live Support Chat:');
    if (!pid || !pid.trim()) return;
    const cleanId = pid.trim();
    if (!this.supportChats) this.supportChats = {};
    if (!this.supportChats[cleanId]) this.supportChats[cleanId] = [];
    this.selectedChatPlayerId = cleanId;
    this.refreshSupportChatsUI();
    const inp = document.getElementById('admin-chat-input');
    if (inp) {
      inp.focus();
      inp.placeholder = `Type message to ${cleanId}...`;
    }
  }

  clearSelectedChatThread(playerId) {
    if (!playerId) return;
    if (!confirm(`Are you sure you want to clear the chat history for ${playerId}?`)) return;
    if (this.supportChats && this.supportChats[playerId]) {
      this.supportChats[playerId] = [];
      this.saveSupportChats(this.supportChats);
      this.pushStateToServer({ supportChats: this.supportChats });
      this.refreshSupportChatsUI();
      this.showLiveToast({
        title: '🗑️ CHAT CLEARED',
        message: `Chat history for ${playerId} cleared.`,
        type: 'success',
        duration: 3000
      });
    }
  }

  selectAdminChatPlayer(playerId) {
    this.selectedChatPlayerId = playerId;
    if (this.supportChats && this.supportChats[playerId]) {
      this.supportChats[playerId].forEach(m => {
        if (m.sender === 'CUSTOMER') m.readByAdmin = true;
      });
      this.saveSupportChats(this.supportChats);
      this.updateSupportChatBadges();
    }
    this.refreshSupportChatsUI();
  }

  handleAdminSendChat() {
    this.sendAdminChatMessage();
  }

  insertAdminReplyTemplate(templateText) {
    const inp = document.getElementById('admin-chat-input');
    if (inp) {
      inp.value = templateText;
      inp.focus();
    }
  }

  broadcastNotificationPrompt() {
    const msg = prompt('Enter message to broadcast as Push Notification to ALL active users:');
    if (!msg || !msg.trim()) return;

    const sync = this.cloudSync || this.syncEngine;
    if (sync && typeof sync.broadcastLiveEvent === 'function') {
      sync.broadcastLiveEvent({
        eventType: 'BROADCAST_NOTIFICATION',
        title: '📢 MASTER ANNOUNCEMENT',
        message: msg.trim(),
        icon: 'icon-192.png'
      });
    }

    this.sendSystemNotification('📢 MASTER ANNOUNCEMENT', msg.trim());

    this.showLiveToast({
      title: '📢 NOTIFICATION BROADCASTED',
      message: `Sent to all active users: "${msg.trim()}"`,
      type: 'success',
      duration: 4000
    });
  }

  quickCreditSelectedPlayer() {
    if (!this.selectedChatPlayerId) {
      alert('Please select a customer conversation from the list first!');
      return;
    }
    const amtStr = prompt(`Enter coin amount to credit instantly to ${this.selectedChatPlayerId}:`);
    const amt = parseFloat(amtStr);
    if (isNaN(amt) || amt <= 0) return;

    if (this.customersDb && this.customersDb[this.selectedChatPlayerId]) {
      this.customersDb[this.selectedChatPlayerId].coins = (this.customersDb[this.selectedChatPlayerId].coins || 0) + amt;
      this.saveCustomersDB(this.customersDb);
      this.pushStateToServer({ customersDb: this.customersDb });
      this.sendAdminChatMessage(`🎉 Master Admin has credited +₹${amt.toFixed(2)} IHD Coins to your balance!`);
      this.showLiveToast({
        title: '💰 COINS CREDITED',
        message: `+₹${amt.toFixed(2)} credited to ${this.selectedChatPlayerId}!`,
        type: 'success',
        duration: 3500
      });
      this.refreshSupportChatsUI();
    } else {
      alert(`Customer ${this.selectedChatPlayerId} not found in database.`);
    }
  }

  sendAdminChatMessage(customText = null) {
    if (!this.selectedChatPlayerId) {
      alert('Please select a customer chat thread from the left first!');
      return;
    }

    const inp = document.getElementById('admin-chat-input');
    const text = (customText || (inp ? inp.value : '')).trim();
    if (!text) return;

    const msgObj = {
      id: 'msg_adm_' + Date.now() + '_' + Math.floor(Math.random() * 1000),
      playerId: this.selectedChatPlayerId,
      sender: 'ADMIN',
      text: text,
      timestamp: Date.now(),
      timeFormatted: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: true }),
      readByAdmin: true
    };

    if (!this.supportChats) this.supportChats = {};
    if (!this.supportChats[this.selectedChatPlayerId]) this.supportChats[this.selectedChatPlayerId] = [];
    this.supportChats[this.selectedChatPlayerId].push(msgObj);
    this.saveSupportChats(this.supportChats);

    if (inp) inp.value = '';
    this.refreshSupportChatsUI();

    // 1. Broadcast over cloud sync
    const sync = this.cloudSync || this.syncEngine;
    if (sync && typeof sync.broadcastLiveEvent === 'function') {
      sync.broadcastLiveEvent({
        eventType: 'CHAT_MESSAGE',
        chatMessage: msgObj
      });
    }

    // 2. Push to local server state
    this.pushStateToServer({
      supportChats: this.supportChats,
      newChatMessage: msgObj
    });

    if (this.audio) this.audio.playTick();
  }

  updateSupportChatBadges() {
'@

if ($content -match $targetPattern) {
    $newContent = [regex]::Replace($content, $targetPattern, $replacement)
    [System.IO.File]::WriteAllText($path, $newContent, [System.Text.Encoding]::UTF8)
    Write-Host "Updated refreshSupportChatsUI successfully!"
} else {
    Write-Host "Target pattern not matched!"
}

$appPath = "C:\Users\ishaa\.gemini\antigravity-ide\scratch\spin-wheel-app\app.js"
$content = [System.IO.File]::ReadAllText($appPath, [System.Text.Encoding]::UTF8)

$oldTest = @'
    // Send automated background call if API key provided
    if (waApiKey) {
      try {
        const url = `https://api.callmebot.com/whatsapp.php?phone=+${cleanPhone}&text=${encodeURIComponent(testMsg.replace(/[*`#_~]/g, ''))}&apikey=${encodeURIComponent(waApiKey)}`;
        fetch(url, { mode: 'no-cors' });
        this.showNotificationFeedback('🎉 Automated WhatsApp Test Sent via Gateway + Opening WhatsApp...', true);
      } catch (e) {}
    }

    const link = this.getWhatsAppLink(testMsg, cleanPhone);
    window.open(link, '_blank');
    if (this.audio) this.audio.playWinFanfare();
'@

$newTest = @'
    // Send automated background call if API key provided
    if (waApiKey) {
      try {
        const url = `https://api.callmebot.com/whatsapp.php?phone=+${cleanPhone}&text=${encodeURIComponent(testMsg.replace(/[*`#_~]/g, ''))}&apikey=${encodeURIComponent(waApiKey)}`;
        fetch(url, { mode: 'no-cors' });
        this.showNotificationFeedback('🎉 Automated WhatsApp Test Sent via CallMeBot Gateway to +' + cleanPhone + '!', true);
      } catch (e) {}
    } else {
      this.showNotificationFeedback('⚠️ WhatsApp Number Saved! Click "1-Click Get Key on WhatsApp" above to enable automatic alerts.', true);
    }

    const link = this.getWhatsAppLink(testMsg, cleanPhone);
    window.open(link, '_blank');
    if (this.audio) this.audio.playWinFanfare();
'@

if ($content.Contains($oldTest)) {
    $content = $content.Replace($oldTest, $newTest)
    [System.IO.File]::WriteAllText($appPath, $content, [System.Text.Encoding]::UTF8)
    Write-Host "Updated sendWhatsAppTestNotification feedback successfully!"
} else {
    Write-Host "Warning: oldTest not found directly."
}

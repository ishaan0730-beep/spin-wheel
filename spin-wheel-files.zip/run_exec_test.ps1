﻿$script = [System.IO.File]::ReadAllText("C:\Users\ishaa\.gemini\antigravity-ide\scratch\spin-wheel-app\app.js", [System.Text.Encoding]::UTF8)

# Let's inspect test_app.html
$testHtml = @"
<!DOCTYPE html>
<html>
<head><title>Test App Execution</title></head>
<body>
<div id="output" style="white-space:pre-wrap; font-family:monospace;"></div>
<script>
window.addEventListener('error', function(e) {
  var el = document.getElementById('output');
  el.innerText += '\n[GLOBAL ERROR]: ' + e.message + ' at line ' + e.lineno + ':' + e.colno + '\n' + (e.error ? e.error.stack : '');
});
</script>
<script src="mqtt.min.js"></script>
<script src="confetti.js"></script>
<script src="app.js"></script>
<script>
try {
  if (window.app) {
    document.getElementById('output').innerText += '\n[SUCCESS] window.app successfully initialized! Slices: ' + JSON.stringify(window.app.slices) + ' History count: ' + window.app.history.length;
  } else {
    document.getElementById('output').innerText += '\n[FAIL] window.app is undefined.';
  }
} catch(err) {
  document.getElementById('output').innerText += '\n[EXCEPTION IN TEST]: ' + err.message + '\n' + err.stack;
}
</script>
</body>
</html>
"@

Set-Content -Path "test_exec.html" -Value $testHtml -Encoding UTF8

# Start a headless browser process to dump DOM
$p = Start-Process -FilePath "C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe" -ArgumentList "--headless", "--disable-gpu", "--virtual-time-budget=3000", "--dump-dom", "http://localhost:3000/test_exec.html" -NoNewWindow -PassThru -RedirectStandardOutput "exec_dom.txt"
$p.WaitForExit(5000)
Get-Content exec_dom.txt | Select-String -Pattern "GLOBAL ERROR|SUCCESS|FAIL|EXCEPTION" -Context 2,5

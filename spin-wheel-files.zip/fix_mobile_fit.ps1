$indexFile = "C:\Users\ishaa\.gemini\antigravity-ide\scratch\spin-wheel-app\index.html"
$cssFile = "C:\Users\ishaa\.gemini\antigravity-ide\scratch\spin-wheel-app\style.css"
$jsFile = "C:\Users\ishaa\.gemini\antigravity-ide\scratch\spin-wheel-app\app.js"
$swFile = "C:\Users\ishaa\.gemini\antigravity-ide\scratch\spin-wheel-app\sw.js"

# 1. Update index.html Header & Promo bar markup
$indexContent = [System.IO.File]::ReadAllText($indexFile, [System.Text.Encoding]::UTF8)

# Replace logo tag to include fallback
$oldLogo = '<img src="logo.png" alt="Spin & Wheel Emblem" style="width:34px; height:34px; border-radius:50%; box-shadow:0 0 10px rgba(255,215,0,0.6); border:1.5px solid #ffd700; object-fit:cover; display:inline-block;">'
$newLogo = '<span class="cric-logo-emblem">🎰</span>'
$indexContent = $indexContent.Replace($oldLogo, $newLogo)

# Replace promo strip label for cleaner mobile rendering
$oldPromo = '<span class="cric-promo-label">Redeem Your Promo Code</span>'
$newPromo = '<span class="cric-promo-label">🎁 Promo Code:</span>'
$indexContent = $indexContent.Replace($oldPromo, $newPromo)

# Bump version to v7.4.2
$indexContent = [System.Text.RegularExpressions.Regex]::Replace($indexContent, 'style\.css\?v=[0-9\.]+', 'style.css?v=7.4.2')
$indexContent = [System.Text.RegularExpressions.Regex]::Replace($indexContent, 'app\.js\?v=[0-9\.]+', 'app.js?v=7.4.2')

[System.IO.File]::WriteAllText($indexFile, $indexContent, [System.Text.Encoding]::UTF8)
Write-Host "index.html updated"

# 2. Update sw.js version
$swContent = [System.IO.File]::ReadAllText($swFile, [System.Text.Encoding]::UTF8)
$swContent = [System.Text.RegularExpressions.Regex]::Replace($swContent, "CACHE_NAME = 'spin-wheel-v[0-9\.]+'", "CACHE_NAME = 'spin-wheel-v7.4.2'")
[System.IO.File]::WriteAllText($swFile, $swContent, [System.Text.Encoding]::UTF8)
Write-Host "sw.js updated"

# 3. Clean corrupted emojis in app.js
$jsContent = [System.IO.File]::ReadAllText($jsFile, [System.Text.Encoding]::UTF8)
$jsContent = $jsContent.Replace("ðŸ’°", "💰")
$jsContent = $jsContent.Replace("ðŸ”‘", "🔑")
$jsContent = $jsContent.Replace("ðŸŽ ", "🎁 ")
$jsContent = $jsContent.Replace("ðŸŽ‰", "🎉")
$jsContent = $jsContent.Replace("ðŸŽ", "🎰")
$jsContent = $jsContent.Replace("ðŸ’¬", "💬")
$jsContent = $jsContent.Replace("ðŸ‘‰", "👉")
$jsContent = $jsContent.Replace("ðŸ‘¤", "👤")
$jsContent = $jsContent.Replace("âœ…", "✅")
$jsContent = $jsContent.Replace("â Œ", "❌")
$jsContent = $jsContent.Replace("âš ï¸ ", "⚠️")
$jsContent = $jsContent.Replace("â‚¹", "₹")
$jsContent = $jsContent.Replace("ðŸ—‘ï¸ ", "🗑️")
$jsContent = $jsContent.Replace("â ¸ï¸ ", "⏸️")
$jsContent = $jsContent.Replace("â–¶ï¸ ", "▶️")
$jsContent = $jsContent.Replace("âž•", "➕")
$jsContent = $jsContent.Replace("ðŸ’³", "💳")
$jsContent = $jsContent.Replace("ðŸ’¸", "💸")

[System.IO.File]::WriteAllText($jsFile, $jsContent, [System.Text.Encoding]::UTF8)
Write-Host "app.js cleaned"

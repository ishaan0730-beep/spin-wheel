$path = "index.html"
$content = [System.IO.File]::ReadAllText($path, [System.Text.Encoding]::UTF8)

# 1. Add Support Chat row in drawer menu
$drawerTarget = '<div class="cric-menu-row" id="cric-row-affiliate">'
$drawerChatRow = @"
      <!-- 24/7 LIVE SUPPORT CHAT WITH MASTER ADMIN -->
      <div class="cric-menu-row" id="cric-row-support-chat" style="background:linear-gradient(90deg, rgba(46,204,113,0.12), rgba(0,240,255,0.08)); border-left:3px solid #2ecc71;">
        <span class="cric-row-icon">
          <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="#2ecc71" stroke-width="2.2"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path></svg>
        </span>
        <span class="cric-row-name" style="color:#2ecc71; font-weight:800;">24/7 Live Chat Support</span>
        <span class="cric-row-badge" id="cric-chat-unread-badge" style="background:#2ecc71; color:#000; font-weight:800; font-size:0.7rem; padding:2px 6px; border-radius:8px;">ONLINE</span>
      </div>

      <div class="cric-menu-row" id="cric-row-affiliate">
"@

if ($content.Contains($drawerTarget) -and -not $content.Contains('cric-row-support-chat')) {
    $content = $content.Replace($drawerTarget, $drawerChatRow)
    Write-Output "Added Live Chat Support row in drawer"
}

# 2. Add Support Chat Button in Help Modal
$helpTarget = '<button id="help-close-btn" class="icon-btn" aria-label="Close Help">&times;</button>'
$helpChatBtn = @"
        <button id="help-close-btn" class="icon-btn" aria-label="Close Help">&times;</button>
      </div>
      <div style="padding:0.75rem 1.25rem 0 1.25rem;">
        <button type="button" class="btn btn-gold btn-block" style="display:flex; align-items:center; justify-content:center; gap:8px; font-weight:800; background:linear-gradient(135deg, #1f6448, #2ecc71); border-color:#2ecc71;" onclick="app.closeHelpModal(); app.openSupportChatModal();">
          <span>💬</span> Chat Directly with Master Support (24/7 Online)
        </button>
"@
if ($content.Contains($helpTarget) -and -not $content.Contains('openSupportChatModal()')) {
    $content = $content.Replace($helpTarget, $helpChatBtn)
    Write-Output "Added Chat button inside Help modal"
}

# 3. Add Customer Support Chat Modal (Modal 9)
$chatModalHtml = @"

  <!-- MODAL 9: 24/7 LIVE SUPPORT CHAT WITH MASTER ADMIN -->
  <div id="cric-support-chat-modal" class="modal-backdrop hidden">
    <div class="modal-overlay" onclick="app.closeCricModals()"></div>
    <div class="modal-content cric-popup-content chat-modal-content">
      <div class="modal-header" style="padding:0.85rem 1rem;">
        <div>
          <h3 style="color:#2ecc71; font-weight:800; font-size:1.1rem; display:flex; align-items:center; gap:8px; margin:0;">
            <span>💬</span> Live Support Chat
          </h3>
          <div class="chat-header-status">
            <span style="display:inline-block; width:8px; height:8px; background:#2ecc71; border-radius:50%; box-shadow:0 0 8px #2ecc71;"></span>
            <span>Master Admin Online & Ready to Help</span>
          </div>
        </div>
        <button type="button" class="icon-btn" onclick="app.closeCricModals()">&times;</button>
      </div>

      <div class="modal-body" style="padding:0.85rem; flex:1; display:flex; flex-direction:column; overflow:hidden;">
        <!-- Quick Help Chips -->
        <div class="chat-quick-chips">
          <button type="button" class="chat-chip-btn" onclick="app.sendQuickChatQuery('💰 Deposit Help: I made a payment, please approve my coins.')">💰 Deposit Help</button>
          <button type="button" class="chat-chip-btn" onclick="app.sendQuickChatQuery('💸 Withdrawal Help: When will my withdrawal be sent to my bank account?')">💸 Withdrawal Status</button>
          <button type="button" class="chat-chip-btn" onclick="app.sendQuickChatQuery('🎰 Prediction Help: How does 9x multiplier prediction payout work?')">🎰 How to Win 9x</button>
          <button type="button" class="chat-chip-btn" onclick="app.sendQuickChatQuery('👑 I need to speak directly with Master Admin.')">👑 Talk to Admin</button>
        </div>

        <!-- Chat Messages Thread -->
        <div class="chat-messages-wrap" id="cust-chat-messages-wrap">
          <div class="chat-msg msg-admin">
            <div class="chat-msg-bubble">
              👋 <b>Welcome to Spin & Wheel 24/7 Live Support!</b><br>
              Directly connected to Master Admin. If you have any questions about deposits, withdrawals, predictions, or coin credits, please message us below for instant assistance!
            </div>
            <div class="chat-msg-meta">
              <span>👑 Master Support</span> &bull; <span id="chat-welcome-time">Live</span>
            </div>
          </div>
        </div>

        <!-- External Quick Links (WhatsApp & Telegram) -->
        <div style="display:flex; gap:6px; margin-bottom:0.6rem;">
          <button type="button" class="btn btn-xs btn-secondary" style="flex:1; background:#25D366; color:#fff; font-weight:700; border:none;" onclick="app.shareOnWhatsApp()">
            📲 WhatsApp Support
          </button>
          <button type="button" class="btn btn-xs btn-secondary" style="flex:1; background:#0088cc; color:#fff; font-weight:700; border:none;" onclick="app.openTelegramSupport()">
            ✈️ Telegram Support
          </button>
        </div>

        <!-- Input Bar -->
        <div class="chat-input-bar">
          <input type="text" id="cust-chat-input" class="chat-input" placeholder="Type message to Master Admin...">
          <button type="button" id="cust-chat-send-btn" class="btn btn-gold" style="padding:8px 14px; font-weight:800;" onclick="app.handleCustomerSendChat()">
            Send ➔
          </button>
        </div>
      </div>
    </div>
  </div>
"@

$modalInsertAnchor = '<!-- MODAL 8: DOWNLOAD MOBILE APP MODAL -->'
if ($content.Contains($modalInsertAnchor) -and -not $content.Contains('cric-support-chat-modal')) {
    $content = $content.Replace($modalInsertAnchor, $chatModalHtml + "`n`n  " + $modalInsertAnchor)
    Write-Output "Added cric-support-chat-modal markup"
}

# 4. Add Admin Nav Tab 6 & Tab Pane
$adminNavTarget = '<button id="admin-nav-settings-btn" class="admin-tab-btn">'
$adminNavChatBtn = @"
          <button id="admin-nav-chats-btn" class="admin-tab-btn">
            <span>💬 Live Support Chats</span>
            <span id="admin-tab-badge-chats" class="admin-tab-badge highlight-gold">0</span>
          </button>
          <button id="admin-nav-settings-btn" class="admin-tab-btn">
"@

if ($content.Contains($adminNavTarget) -and -not $content.Contains('admin-nav-chats-btn')) {
    $content = $content.Replace($adminNavTarget, $adminNavChatBtn)
    Write-Output "Added Admin Nav Chats Button"
}

# 5. Add Admin Chats Tab Pane before Settings Pane
$adminSettingsPaneAnchor = '<div id="admin-tab-settings-pane" class="admin-tab-pane">'
$adminChatPaneHtml = @"
          <!-- TAB 6: MASTER ADMIN 24/7 LIVE SUPPORT CHATS -->
          <div id="admin-tab-chats-pane" class="admin-tab-pane">
            <div class="admin-card">
              <div class="admin-card-title" style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:8px;">
                <div style="display:flex; align-items:center; gap:8px;">
                  <span class="step-num">💬</span>
                  <h4 style="margin:0;">Customer Live Support Desk (Real-Time 2-Way Chat)</h4>
                </div>
                <div style="display:flex; gap:6px;">
                  <button type="button" class="btn btn-secondary btn-xs" onclick="app.refreshSupportChatsUI()">🔄 Refresh Chats</button>
                  <button type="button" class="btn btn-gold btn-xs" onclick="app.broadcastNotificationPrompt()">📢 Broadcast Alert to All Users</button>
                </div>
              </div>
              <p class="card-desc" style="margin-bottom:0.75rem;">
                Live inquiries from players on mobile apps and website. Reply directly to solve customer deposit, withdrawal, and prediction questions in real-time.
              </p>

              <!-- Support Desk 2-Column Interface -->
              <div class="admin-chats-layout">
                <!-- Left Sidebar: Conversations List -->
                <div class="admin-chats-sidebar">
                  <div class="admin-chats-sidebar-header">
                    <span>Active Conversations (<span id="admin-active-chats-count">0</span>)</span>
                  </div>
                  <div class="admin-chats-player-list" id="admin-chat-threads-list">
                    <div style="padding:1.5rem; text-align:center; color:var(--text-muted); font-size:0.78rem;">
                      No active support inquiries yet. New customer messages will appear here instantly with live sound alert.
                    </div>
                  </div>
                </div>

                <!-- Right View: Selected Chat Thread -->
                <div class="admin-chats-main-view">
                  <div id="admin-chat-header-bar" style="padding-bottom:0.6rem; border-bottom:1px solid var(--border-subtle); display:flex; justify-content:space-between; align-items:center;">
                    <div>
                      <strong id="admin-selected-chat-name" style="font-size:0.95rem; color:#fff;">Select a conversation</strong>
                      <div id="admin-selected-chat-sub" style="font-size:0.72rem; color:var(--text-secondary);">Click any player from the list to view and reply</div>
                    </div>
                    <div id="admin-selected-chat-actions" class="hidden">
                      <button type="button" class="btn btn-secondary btn-xs" onclick="app.quickCreditSelectedPlayer()">💰 Quick Credit</button>
                    </div>
                  </div>

                  <!-- Messages Scroll Area -->
                  <div class="chat-messages-wrap" id="admin-chat-messages-wrap" style="flex:1; margin:0.65rem 0;">
                    <div style="padding:2rem; text-align:center; color:var(--text-muted); font-size:0.8rem;">
                      Select a player on the left to start live messaging.
                    </div>
                  </div>

                  <!-- Admin Quick Reply Template Chips -->
                  <div class="chat-quick-chips" id="admin-chat-template-chips">
                    <button type="button" class="chat-chip-btn" onclick="app.insertAdminReplyTemplate('✅ Hi, your deposit has been verified and coins are credited to your wallet balance!')">✅ Deposit Approved</button>
                    <button type="button" class="chat-chip-btn" onclick="app.insertAdminReplyTemplate('💸 Your withdrawal request has been approved and successfully transferred to your bank account!')">💸 Withdrawal Sent</button>
                    <button type="button" class="chat-chip-btn" onclick="app.insertAdminReplyTemplate('📸 Please share your 12-digit UTR transaction reference number for verification.')">📸 Ask for UTR</button>
                    <button type="button" class="chat-chip-btn" onclick="app.insertAdminReplyTemplate('🎰 Prediction bets for the upcoming round slot are now open! You can place predictions to win 9x.')">🎰 Bets Open</button>
                  </div>

                  <!-- Admin Chat Input Bar -->
                  <div class="chat-input-bar">
                    <input type="text" id="admin-chat-input" class="chat-input" placeholder="Type reply as Master Admin...">
                    <button type="button" id="admin-chat-send-btn" class="btn btn-gold" style="padding:8px 16px; font-weight:800;" onclick="app.handleAdminSendChat()">
                      Send Reply ➔
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>

"@

if ($content.Contains($adminSettingsPaneAnchor) -and -not $content.Contains('admin-tab-chats-pane')) {
    $content = $content.Replace($adminSettingsPaneAnchor, $adminChatPaneHtml + "          " + $adminSettingsPaneAnchor)
    Write-Output "Added Admin Chats Tab Pane"
}

[System.IO.File]::WriteAllText($path, $content, [System.Text.Encoding]::UTF8)
Write-Output "Successfully updated index.html with Live Chat & Support features"

$indexFile = "C:\Users\ishaa\.gemini\antigravity-ide\scratch\spin-wheel-app\index.html"
$indexContent = [System.IO.File]::ReadAllText($indexFile, [System.Text.Encoding]::UTF8)

# 1. Remove duplicate script block in index.html around line 2128
$dupScriptPattern = '(?s)<script src="mqtt\.min\.js"></script>\s*<script src="https://unpkg\.com/mqtt@5\.16\.0/dist/mqtt\.min\.js".*?<script src="app\.js\?v=7\.1\.0"></script>'
if ($indexContent -match $dupScriptPattern) {
    $indexContent = [regex]::Replace($indexContent, $dupScriptPattern, '')
    Write-Host "Removed duplicate script block in index.html"
}

# 2. Update Admin Panel Top Header & Vertical Sidebar Layout in index.html
$adminHeaderPattern = '(?s)<div class="admin-header">.*?<div class="admin-dashboard-container">\s*<!-- Left / Center Column: Tab Contents -->\s*<div class="admin-main-column">'

$adminHeaderReplacement = @'
<div class="admin-header">
        <div class="admin-header-left">
          <div class="admin-header-title">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6Z"></path>
              <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1Z"></path>
            </svg>
            <div>
              <h3 style="margin:0; font-size:1.15rem; font-weight:800; color:var(--primary-gold-bright);">Master Control Center</h3>
              <span style="font-size:0.7rem; color:var(--text-muted); font-weight:600;">Full System Management &amp; Live Monitor</span>
            </div>
          </div>
        </div>

        <div class="admin-header-right">
          <div class="admin-live-status-pill" style="display:flex; align-items:center; gap:6px; background:rgba(46,204,113,0.12); border:1px solid rgba(46,204,113,0.3); padding:4px 10px; border-radius:12px; font-size:0.72rem; color:#2ecc71; font-weight:700;">
            <span style="width:7px; height:7px; background:#2ecc71; border-radius:50%; box-shadow:0 0 6px #2ecc71;"></span>
            <span>Master Online</span>
          </div>
          <button id="admin-logout-btn" class="btn btn-secondary btn-sm" title="Log Out" onclick="app.adminLogout()">Logout</button>
          <button id="admin-close-btn" class="icon-btn" aria-label="Close Admin Panel">&times;</button>
        </div>
      </div>

      <!-- Admin Main Content Layout (Vertical Left Sidebar + Main Controls + Side Live Mini Spin Monitor) -->
      <div class="admin-dashboard-container">
        
        <!-- COLUMN 1: VERTICAL LEFT NAVIGATION SIDEBAR -->
        <aside class="admin-vertical-sidebar">
          <div class="admin-sidebar-menu-title">NAVIGATION MENU</div>
          <nav class="admin-nav-tabs">
            <button id="admin-nav-spin-btn" class="admin-tab-btn active" onclick="app.setAdminTab('spin')">
              <span class="vtab-icon">&#9881;&#65039;</span>
              <span class="vtab-text">Spin &amp; Round Settings</span>
            </button>
            <button id="admin-nav-players-btn" class="admin-tab-btn" onclick="app.setAdminTab('players')">
              <span class="vtab-icon">&#128101;</span>
              <span class="vtab-text">Players &amp; Live Bets</span>
              <span id="admin-tab-badge-players" class="admin-tab-badge">0</span>
            </button>
            <button id="admin-nav-deposits-btn" class="admin-tab-btn" onclick="app.setAdminTab('deposits')">
              <span class="vtab-icon">&#128176;</span>
              <span class="vtab-text">Deposit Requests</span>
              <span id="admin-tab-badge-deposits" class="admin-tab-badge highlight-gold">0</span>
            </button>
            <button id="admin-nav-withdrawals-btn" class="admin-tab-btn" onclick="app.setAdminTab('withdrawals')">
              <span class="vtab-icon">&#128184;</span>
              <span class="vtab-text">Withdrawal Requests</span>
              <span id="admin-tab-badge-withdrawals" class="admin-tab-badge highlight-gold">0</span>
            </button>
            <button id="admin-nav-chats-btn" class="admin-tab-btn" onclick="app.setAdminTab('chats')">
              <span class="vtab-icon">&#128172;</span>
              <span class="vtab-text">Live Support Desk</span>
              <span id="admin-tab-badge-chats" class="admin-tab-badge highlight-cyan">0</span>
            </button>
            <button id="admin-nav-promos-btn" class="admin-tab-btn" onclick="app.setAdminTab('promos')">
              <span class="vtab-icon">&#127873;</span>
              <span class="vtab-text">Promo Codes &amp; Vouchers</span>
              <span id="admin-tab-badge-promos" class="admin-tab-badge highlight-gold">0</span>
            </button>
            <button id="admin-nav-settings-btn" class="admin-tab-btn" onclick="app.setAdminTab('settings')">
              <span class="vtab-icon">&#128242;</span>
              <span class="vtab-text">Telegram &amp; Settings</span>
            </button>
          </nav>
        </aside>

        <!-- COLUMN 2: TAB CONTENTS -->
        <div class="admin-main-column">
'@

if ($indexContent -match $adminHeaderPattern) {
    $indexContent = [regex]::Replace($indexContent, $adminHeaderPattern, $adminHeaderReplacement)
    Write-Host "Updated Admin Panel layout to Vertical Sidebar in index.html"
} else {
    Write-Host "Admin Header Pattern not matched!"
}

# 3. Add TAB 7: Promo Codes & Vouchers pane right before TAB 5 (Telegram & Settings)
$tabSettingsPattern = '(?s)<!-- TAB 5: TELEGRAM ALERTS & MASTER PAYMENT SETTINGS -->'
$tabPromoContent = @'
<!-- TAB 7: MASTER PROMO CODES & VOUCHERS MANAGER -->
          <div id="admin-tab-promos-pane" class="admin-tab-pane hidden">
            <div class="admin-card control-highlight">
              <div class="admin-card-title" style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:8px;">
                <div style="display:flex; align-items:center; gap:8px;">
                  <span class="step-num">&#127873;</span>
                  <h4 style="margin:0;">Promo Codes &amp; Bonus Vouchers Generator</h4>
                </div>
                <span class="live-dot-tag" style="background:rgba(245,176,65,0.12); color:#ffd700; border:1px solid rgba(245,176,65,0.3);"><span class="pulse-dot"></span> Master Only Access</span>
              </div>
              <p class="card-desc">
                Create special promo codes to reward players with free wallet coins. Only codes created by Master here are valid. Each customer can only redeem any given promo code <strong>once</strong>!
              </p>

              <!-- Create Promo Code Form -->
              <div style="background:rgba(0,0,0,0.35); border:1px solid var(--border-subtle); border-radius:8px; padding:1.1rem; margin-bottom:1.15rem;">
                <h5 style="margin:0 0 10px 0; color:var(--primary-gold-bright); font-size:0.92rem;">➕ Generate New Promo Code</h5>
                <div style="display:grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap:12px; align-items:flex-end;">
                  <div>
                    <label class="field-label" style="color:#f8fafc; font-weight:700;">🎁 Promo Code Name:</label>
                    <input type="text" id="admin-new-promo-code" class="admin-input" placeholder="e.g. FESTIVAL500, BONUS100" style="text-transform:uppercase; font-weight:800; letter-spacing:1px;">
                  </div>
                  <div>
                    <label class="field-label" style="color:#00f0ff; font-weight:700;">💰 Coin Bonus (₹ / IHD):</label>
                    <input type="number" id="admin-new-promo-bonus" class="admin-input" placeholder="e.g. 100" min="1" step="1">
                  </div>
                  <div>
                    <label class="field-label" style="color:#2ecc71; font-weight:700;">👤 Max Uses Per Player:</label>
                    <input type="text" class="admin-input" value="1 Use (Strict 1 per account)" readonly style="opacity:0.85; background:rgba(0,0,0,0.5); cursor:not-allowed;">
                  </div>
                  <div>
                    <button type="button" id="admin-create-promo-btn" class="btn btn-gold btn-block" style="height:40px; font-weight:800; font-size:0.88rem;" onclick="app.adminCreatePromoCode()">
                      ➕ Create Promo Code
                    </button>
                  </div>
                </div>
              </div>

              <!-- Active Promo Codes Table -->
              <div class="admin-card-header-flex" style="margin-bottom:10px; display:flex; justify-content:space-between; align-items:center;">
                <h5 style="margin:0; font-size:0.95rem; color:#fff;">Active Promo Codes (<span id="admin-promos-count-badge">0</span>)</h5>
                <button type="button" class="btn btn-secondary btn-xs" onclick="app.renderAdminPromosList()">🔄 Refresh List</button>
              </div>

              <div class="table-container" style="max-height:380px; overflow-y:auto; border:1px solid var(--border-subtle); border-radius:6px;">
                <table class="schedule-table">
                  <thead>
                    <tr>
                      <th>Promo Code</th>
                      <th>Bonus Amount</th>
                      <th>Total Redemptions</th>
                      <th>Created Date</th>
                      <th>Status</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody id="admin-promos-table-body">
                    <tr>
                      <td colspan="6" style="text-align:center; color:var(--text-muted); padding:1.5rem;">No promo codes created yet. Generate one above!</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>

          <!-- TAB 5: TELEGRAM ALERTS & MASTER PAYMENT SETTINGS -->
'@

if ($indexContent -match $tabSettingsPattern -and -not ($indexContent -match 'id="admin-tab-promos-pane"')) {
    $indexContent = [regex]::Replace($indexContent, $tabSettingsPattern, $tabPromoContent)
    Write-Host "Added TAB 7 Promo Codes & Vouchers in index.html"
}

[System.IO.File]::WriteAllText($indexFile, $indexContent, [System.Text.Encoding]::UTF8)
Write-Host "index.html updated successfully!"

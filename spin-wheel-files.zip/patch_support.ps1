$file = "C:\Users\ishaa\.gemini\antigravity-ide\scratch\spin-wheel-app\app.js"
$lines = [System.IO.File]::ReadAllLines($file, [System.Text.Encoding]::UTF8)

$startIdx = -1
$endIdx = -1
for ($i = 0; $i -lt $lines.Length; $i++) {
    if ($lines[$i] -match "refreshSupportChatsUI\(\)\s*\{") {
        $startIdx = $i
    }
    if ($startIdx -ge 0 -and $lines[$i] -match "selectAdminChatPlayer\(playerId\)\s*\{") {
        $endIdx = $i
        break
    }
}

Write-Host "Found refreshSupportChatsUI at line $startIdx to $endIdx"

if ($startIdx -ge 0 -and $endIdx -gt $startIdx) {
    $newFn = @'
  refreshSupportChatsUI() {
    const listEl = document.getElementById('admin-chat-threads-list');
    const feedEl = document.getElementById('admin-chat-messages-wrap') || document.getElementById('admin-chat-messages-feed');
    const nameEl = document.getElementById('admin-selected-chat-name');
    const subEl = document.getElementById('admin-selected-chat-sub');
    const actionsEl = document.getElementById('admin-selected-chat-actions');
    const countEl = document.getElementById('admin-active-chats-count');
    if (!listEl) return;

    const chats = this.supportChats || {};
    const chatPlayerIds = Object.keys(chats);
    const dbPlayerIds = Object.keys(this.customersDb || {});
    
    // Merge active chat threads and all registered customers
    const allIdsSet = new Set([...chatPlayerIds, ...dbPlayerIds]);
    const allPlayerIds = Array.from(allIdsSet);

    if (countEl) countEl.textContent = chatPlayerIds.length;

    if (allPlayerIds.length === 0) {
      listEl.innerHTML = '<div style="padding:1.5rem; text-align:center; color:var(--text-muted); font-size:0.78rem;">No registered players or support inquiries yet.</div>';
      if (feedEl) feedEl.innerHTML = '<div style="padding:2rem; text-align:center; color:var(--text-muted); font-size:0.8rem;">Select a player on the left to start live messaging.</div>';
      if (nameEl) nameEl.textContent = 'Select a conversation';
      if (subEl) subEl.textContent = 'Click any player from the list to view and reply';
      if (actionsEl) actionsEl.classList.add('hidden');
      return;
    }

    // Auto-select first thread if none selected
    if (!this.selectedChatPlayerId || (!chats[this.selectedChatPlayerId] && !this.customersDb?.[this.selectedChatPlayerId])) {
      this.selectedChatPlayerId = allPlayerIds[0];
    }

    // Render thread list on left
    listEl.innerHTML = allPlayerIds.map(pid => {
      const thread = chats[pid] || [];
      const hasMsgs = thread.length > 0;
      const lastMsg = hasMsgs ? thread[thread.length - 1] : {};
      const custObj = this.customersDb ? this.customersDb[pid] : null;
      const displayName = lastMsg.playerName || (custObj ? (custObj.name || custObj.id) : pid);
      const isSel = this.selectedChatPlayerId === pid;
      const unreadCount = thread.filter(m => m.sender === 'CUSTOMER' && !m.readByAdmin).length;

      return `
        <div class="admin-chat-thread-item ${isSel ? 'active' : ''}" style="padding:10px 12px; border-bottom:1px solid var(--border-subtle); cursor:pointer; background:${isSel ? 'rgba(217,119,6,0.18)' : 'transparent'}; border-left:${isSel ? '3px solid #f59e0b' : '3px solid transparent'};" onclick="window.app.selectAdminChatPlayer('${pid}')">
          <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:4px;">
            <span style="font-weight:700; color:#f8fafc; font-size:0.85rem;">👤 ${this.escapeHTML(displayName)}</span>
            <span style="font-size:0.7rem; color:var(--text-muted);">${lastMsg.timeFormatted || (custObj ? 'Registered' : '')}</span>
          </div>
          <div style="display:flex; justify-content:space-between; align-items:center;">
            <div style="font-size:0.75rem; color:#cbd5e1; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; max-width:180px;">
              ${lastMsg.sender === 'ADMIN' ? '👑 You: ' : ''}${this.escapeHTML(lastMsg.text || 'No message history yet')}
            </div>
            ${unreadCount > 0 ? `<span style="background:#e11d48; color:#fff; font-size:10px; font-weight:800; padding:1px 6px; border-radius:10px;">${unreadCount}</span>` : ''}
          </div>
        </div>
      `;
    }).join('');

    // If active player selected, render feed on right
    if (this.selectedChatPlayerId) {
      const pid = this.selectedChatPlayerId;
      const selThread = chats[pid] || [];
      const custObj = this.customersDb ? this.customersDb[pid] : null;
      const firstMsg = selThread[0] || {};
      const dispName = firstMsg.playerName || (custObj ? (custObj.name || custObj.id) : pid);
      const dispMobile = firstMsg.playerMobile || (custObj ? (custObj.mobile || 'N/A') : 'N/A');
      const dispCoins = custObj ? Number(custObj.coins || 0).toFixed(2) : '0.00';

      if (nameEl) nameEl.textContent = `👤 ${dispName}`;
      if (subEl) subEl.textContent = `Player ID: ${pid} • Mobile: ${dispMobile} • Balance: ₹${dispCoins}`;
      if (actionsEl) actionsEl.classList.remove('hidden');

      if (feedEl) {
        if (selThread.length === 0) {
          feedEl.innerHTML = `
            <div style="padding:2rem; text-align:center; color:var(--text-muted); font-size:0.82rem;">
              💬 No previous message history with <b>${this.escapeHTML(dispName)}</b>.<br>
              Type your message below to start a direct live conversation or click <b>💰 Quick Credit</b>.
            </div>
          `;
        } else {
          feedEl.innerHTML = selThread.map(m => {
            const isAdmin = m.sender === 'ADMIN';
            return `
              <div class="chat-msg ${isAdmin ? 'chat-msg-admin' : 'chat-msg-user'}" style="margin-bottom:8px; display:flex; flex-direction:column; align-items:${isAdmin ? 'flex-end' : 'flex-start'};">
                <div style="font-size:0.7rem; color:var(--text-muted); margin-bottom:2px;">${isAdmin ? '👑 You (Master Admin)' : '👤 ' + (m.playerName || m.playerId)}</div>
                <div style="background:${isAdmin ? 'linear-gradient(135deg, #d97706, #b45309)' : 'rgba(255,255,255,0.08)'}; color:#fff; padding:8px 12px; border-radius:10px; max-width:80%; word-break:break-word; font-size:0.85rem;">
                  ${this.escapeHTML(m.text)}
                </div>
                <div style="font-size:0.65rem; color:var(--text-muted); margin-top:2px;">${m.timeFormatted || new Date(m.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</div>
              </div>
            `;
          }).join('');
          feedEl.scrollTop = feedEl.scrollHeight;
        }
      }
    }
  }

'@

    $before = $lines[0..($startIdx - 1)]
    $after = $lines[$endIdx..($lines.Length - 1)]
    $newLines = @($before) + @($newFn) + @($after)
    [System.IO.File]::WriteAllLines($file, $newLines, [System.Text.Encoding]::UTF8)
    Write-Host "refreshSupportChatsUI replaced successfully."
}

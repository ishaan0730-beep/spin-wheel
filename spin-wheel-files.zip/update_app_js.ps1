$path = "app.js"
$content = [System.IO.File]::ReadAllText($path, [System.Text.Encoding]::UTF8)

# 1. Update updateCustomerUI() to strictly keep customer-profile-chip hidden and format cric-balance-val
$oldCustUI = @"
  updateCustomerUI() {
    if (this.currentCustomer) {
      this.customerLoginBtn?.classList.add('hidden');
      this.customerProfileChip?.classList.remove('hidden');
      if (this.chipPlayerName) this.chipPlayerName.textContent = this.currentCustomer.name || 'Player';
      if (this.chipPlayerCoins) this.chipPlayerCoins.textContent = ``💰 `$`{(this.currentCustomer.coins || 0).toLocaleString()} IHD``;
      if (this.playerWalletDisplay) this.playerWalletDisplay.textContent = ``💰 `$`{(this.currentCustomer.coins || 0).toLocaleString()} IHD Coins``;
      if (this.dashPlayerName) this.dashPlayerName.textContent = this.currentCustomer.name || 'Player';
      if (this.dashPlayerId) this.dashPlayerId.textContent = this.currentCustomer.id || '--';
      if (this.dashPlayerCoins) this.dashPlayerCoins.textContent = ``💰 `$`{(this.currentCustomer.coins || 0).toLocaleString()} IHD Coins``;
    } else {
      this.customerLoginBtn?.classList.remove('hidden');
      this.customerProfileChip?.classList.add('hidden');
      if (this.playerWalletDisplay) this.playerWalletDisplay.textContent = '💰 Logged Out (0 IHD Coins)';
    }
"@

$newCustUI = @"
  updateCustomerUI() {
    const coins = this.currentCustomer ? Number(this.currentCustomer.coins || 0) : 0;
    const cricBalEl = document.getElementById('cric-balance-val');
    if (cricBalEl) {
      cricBalEl.textContent = coins.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    }

    if (this.currentCustomer) {
      this.customerLoginBtn?.classList.add('hidden');
      this.customerProfileChip?.classList.add('hidden'); // Strictly keep hidden so coins only display in top payment pill
      if (this.chipPlayerName) this.chipPlayerName.textContent = this.currentCustomer.name || 'Player';
      if (this.chipPlayerCoins) this.chipPlayerCoins.textContent = ``💰 `$`{coins.toLocaleString()} IHD``;
      if (this.playerWalletDisplay) this.playerWalletDisplay.textContent = ``💰 `$`{coins.toLocaleString()} IHD Coins``;
      if (this.dashPlayerName) this.dashPlayerName.textContent = this.currentCustomer.name || 'Player';
      if (this.dashPlayerId) this.dashPlayerId.textContent = this.currentCustomer.id || '--';
      if (this.dashPlayerCoins) this.dashPlayerCoins.textContent = ``💰 `$`{coins.toLocaleString()} IHD Coins``;
    } else {
      this.customerLoginBtn?.classList.remove('hidden');
      this.customerProfileChip?.classList.add('hidden');
      if (this.playerWalletDisplay) this.playerWalletDisplay.textContent = '💰 Logged Out (0 IHD Coins)';
    }
"@

# Normalize and replace
$oldCustUINorm = $oldCustUI.Replace("`r`n", "`n")
$contentNorm = $content.Replace("`r`n", "`n")

if ($contentNorm.Contains($oldCustUINorm)) {
    $contentNorm = $contentNorm.Replace($oldCustUINorm, $newCustUI.Replace("`r`n", "`n"))
    Write-Output "Updated updateCustomerUI"
} else {
    Write-Output "Warning: oldCustUI not matched directly, attempting regex/anchor replacement"
    $regex = '(?s)updateCustomerUI\(\)\s*\{.*?this\.updateTargetSlotDisplay\(\);'
    $replacement = $newCustUI.Replace("`r`n", "`n") + "`n`n    this.updateTargetSlotDisplay();"
    $contentNorm = [System.Text.RegularExpressions.Regex]::Replace($contentNorm, $regex, $replacement, 1)
    Write-Output "Applied regex update for updateCustomerUI"
}

# 2. Update bindCricbetEvents to add download app handlers and PWA prompt
$oldBindRow = "document.getElementById('cric-row-completed-events')?.addEventListener('click', () => {"
$newBindRow = @"
    document.getElementById('cric-row-download-app')?.addEventListener('click', () => {
      this.openDownloadAppModal();
    });
    document.getElementById('pwa-install-app-btn')?.addEventListener('click', () => {
      this.triggerPWAInstall();
    });
    this.setupPWAInstallPrompt();

    document.getElementById('cric-row-completed-events')?.addEventListener('click', () => {
"@

if ($contentNorm.Contains($oldBindRow) -and -not $contentNorm.Contains('cric-row-download-app')) {
    $contentNorm = $contentNorm.Replace($oldBindRow, $newBindRow.Replace("`r`n", "`n"))
    Write-Output "Added download app & PWA listeners to bindCricbetEvents"
}

# 3. Update closeCricModals to include cric-download-modal
$oldCloseModals = "'cric-2fa-modal'"
$newCloseModals = "'cric-2fa-modal',`n      'cric-download-modal'"
if ($contentNorm.Contains($oldCloseModals) -and -not $contentNorm.Contains("'cric-download-modal'")) {
    $contentNorm = $contentNorm.Replace($oldCloseModals, $newCloseModals)
    Write-Output "Updated closeCricModals with cric-download-modal"
}

# 4. Add PWA helper methods before openReferEarnModal
$oldBeforeRefer = "  // 1. Refer & Earn Modal"
$pwaHelpers = @"
  // PWA Mobile App Install Controller
  setupPWAInstallPrompt() {
    window.addEventListener('beforeinstallprompt', (e) => {
      e.preventDefault();
      this.deferredPWAInstallPrompt = e;
      const installBtn = document.getElementById('pwa-install-app-btn');
      if (installBtn) installBtn.style.display = 'flex';
    });

    window.addEventListener('appinstalled', () => {
      this.deferredPWAInstallPrompt = null;
      this.showLiveToast({
        title: 'APP INSTALLED',
        message: '🎉 Spin & Wheel installed to your home screen!',
        type: 'success',
        duration: 4000
      });
    });
  }

  openDownloadAppModal() {
    this.closeCricDrawer();
    const modal = document.getElementById('cric-download-modal');
    if (modal) modal.classList.remove('hidden');
  }

  async triggerPWAInstall() {
    if (this.deferredPWAInstallPrompt) {
      this.deferredPWAInstallPrompt.prompt();
      const { outcome } = await this.deferredPWAInstallPrompt.userChoice;
      if (outcome === 'accepted') {
        this.showLiveToast({
          title: 'INSTALLING APP',
          message: 'Spin & Wheel is installing to your device...',
          type: 'success',
          duration: 3500
        });
      }
      this.deferredPWAInstallPrompt = null;
    } else {
      alert('To install on Android / Chrome:\n1. Tap the 3 dots (⋮) at top right\n2. Tap \"Install App\" or \"Add to Home screen\"\n\nTo install on iPhone / Safari:\n1. Tap the Share icon (⎋) at the bottom\n2. Tap \"Add to Home Screen ➕\"');
    }
  }

  // 1. Refer & Earn Modal
"@

if ($contentNorm.Contains($oldBeforeRefer) -and -not $contentNorm.Contains('setupPWAInstallPrompt()')) {
    $contentNorm = $contentNorm.Replace($oldBeforeRefer, $pwaHelpers.Replace("`r`n", "`n"))
    Write-Output "Added PWA installer methods"
}

# 5. Enhance renderAccountStatement
$oldStmtCheck = "if (!this.currentCustomer) {`n      tbody.innerHTML = '<tr><td colspan=""5"" style=""text-align:center; color:var(--text-muted); padding:1rem;"">Please sign in to view your account passbook.</td></tr>';`n      return;`n    }"
$newStmtCheck = @"
    if (!this.currentCustomer) {
      tbody.innerHTML = '<tr><td colspan="5" style="text-align:center; color:var(--text-muted); padding:1.5rem;"><div style="margin-bottom:8px; font-size:0.85rem; color:#fff;">Please sign in to view your Account Statement & Passbook.</div><button type="button" class="btn btn-gold btn-sm" onclick="app.closeCricModals(); app.openAuthModal(\\'signin\\');">🔑 Sign In to View Passbook</button></td></tr>';
      if (label) label.textContent = 'Please Sign In';
      return;
    }
"@

if ($contentNorm.Contains($oldStmtCheck)) {
    $contentNorm = $contentNorm.Replace($oldStmtCheck, $newStmtCheck.Replace("`r`n", "`n"))
    Write-Output "Enhanced statement login fallback"
}

[System.IO.File]::WriteAllText($path, $contentNorm, [System.Text.Encoding]::UTF8)
Write-Output "Successfully updated app.js"

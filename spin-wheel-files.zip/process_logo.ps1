﻿Add-Type -AssemblyName System.Drawing

$srcPath = "C:\Users\ishaa\.gemini\antigravity-ide\brain\badc9f3d-0024-4e29-ad87-88490781ece6\.user_uploaded\media_1791376024450.jpg"
$destDir = "C:\Users\ishaa\.gemini\antigravity-ide\scratch\spin-wheel-app"

$srcImg = [System.Drawing.Bitmap]::FromFile($srcPath)
$srcW = $srcImg.Width
$srcH = $srcImg.Height

# Calculate square crop bounding box (center square)
$cropSize = $srcH
$cropX = [Math]::Max(0, [int](($srcW - $cropSize) / 2))
$cropY = 0

Write-Host "Cropping square: X=$cropX, Y=$cropY, Size=$cropSize"

$cropRect = New-Object System.Drawing.Rectangle($cropX, $cropY, $cropSize, $cropSize)
$croppedBmp = $srcImg.Clone($cropRect, $srcImg.PixelFormat)

# Function to resize and save high-quality PNG
function Save-ResizedPng($bmp, $targetSize, $outPath) {
    $targetBmp = New-Object System.Drawing.Bitmap($targetSize, $targetSize)
    $g = [System.Drawing.Graphics]::FromImage($targetBmp)
    $g.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
    $g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::HighQuality
    $g.PixelOffsetMode = [System.Drawing.Drawing2D.PixelOffsetMode]::HighQuality
    $g.CompositingQuality = [System.Drawing.Drawing2D.CompositingQuality]::HighQuality
    $g.DrawImage($bmp, 0, 0, $targetSize, $targetSize)
    $g.Dispose()

    $targetBmp.Save($outPath, [System.Drawing.Imaging.ImageFormat]::Png)
    $targetBmp.Dispose()
    Write-Host "Saved: $outPath ($targetSize x $targetSize)"
}

# Save icon-512.png
Save-ResizedPng $croppedBmp 512 (Join-Path $destDir "icon-512.png")

# Save icon-192.png
Save-ResizedPng $croppedBmp 192 (Join-Path $destDir "icon-192.png")

# Save logo.png
Save-ResizedPng $croppedBmp 512 (Join-Path $destDir "logo.png")

# Save full banner
$srcImg.Save((Join-Path $destDir "logo-banner.png"), [System.Drawing.Imaging.ImageFormat]::Png)
Write-Host "Saved: logo-banner.png"

$croppedBmp.Dispose()
$srcImg.Dispose()
Write-Host "All logo icons generated successfully!"

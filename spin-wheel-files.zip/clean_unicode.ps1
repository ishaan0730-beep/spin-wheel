$replacements = @{
    "ðŸ’¬" = "💬"
    "ðŸ”„" = "🔄"
    "ðŸ“¢" = "📢"
    "ðŸ“¸" = "📸"
    "ðŸŽ°" = "🎰"
    "ðŸŽ "  = "🎁"
    "ðŸ“‹" = "📋"
    "ðŸ ›ï¸ " = "🏛️"
    "ðŸ“Š" = "📊"
    "ðŸ›¡ï¸ " = "🛡️"
    "ðŸ‘‘" = "👑"
    "ðŸ‘‹" = "👋"
    "ðŸ“¦" = "📦"
    "ðŸ¤–" = "🤖"
    "ðŸ Ž" = "🍏"
    "â‹®" = "⋮"
    "âŽ‹" = "⎋"
    "âž”" = "➔"
    "âž•" = "➕"
    "ðŸ’¸" = "💸"
    "ðŸ †" = "🏆"
    "ðŸŽ‰" = "🎉"
    "ðŸ’²" = "📲"
    "ðŸ‘‰" = "👉"
}

$files = @(
    "C:\Users\ishaa\.gemini\antigravity-ide\scratch\spin-wheel-app\index.html",
    "C:\Users\ishaa\.gemini\antigravity-ide\scratch\spin-wheel-app\app.js"
)

foreach ($f in $files) {
    if (Test-Path $f) {
        $text = [System.IO.File]::ReadAllText($f, [System.Text.Encoding]::UTF8)
        foreach ($k in $replacements.Keys) {
            $v = $replacements[$k]
            if ($text.Contains($k)) {
                $text = $text.Replace($k, $v)
                Write-Host "Replaced $k with $v in $f"
            }
        }
        [System.IO.File]::WriteAllText($f, $text, [System.Text.Encoding]::UTF8)
        Write-Host "Cleaned $f successfully!"
    }
}

$path = "C:\Users\ishaa\.gemini\antigravity-ide\scratch\spin-wheel-app\app.js"
$content = [System.IO.File]::ReadAllText($path, [System.Text.Encoding]::UTF8)

# Target block to replace: from 'renderAccountStatement(filter = ''ALL'') {' to 'let filtered = records;'
$targetPattern = '(?s)renderAccountStatement\(filter = ''ALL''\) \{.*?let filtered = records;'

$replacement = @'
renderAccountStatement(filter = 'ALL') {
    const tbody = document.getElementById('cric-statement-table-body');
    const label = document.getElementById('cric-stmt-count-label');
    if (!tbody) return;

    document.querySelectorAll('.cric-stmt-filter').forEach(btn => {
      if (btn.getAttribute('data-filter') === filter) btn.classList.add('active');
      else btn.classList.remove('active');
    });

    if (!this.currentCustomer) {
      tbody.innerHTML = '<tr><td colspan="5" style="text-align:center; color:var(--text-muted); padding:1.5rem;"><div style="margin-bottom:8px; font-size:0.85rem; color:#fff;">Please sign in to view your Account Statement &amp; Passbook.</div><button type="button" class="btn btn-gold btn-sm" onclick="app.closeCricModals(); app.openAuthModal(\x27signin\x27);">🔑 Sign In to View Passbook</button></td></tr>';
      if (label) label.textContent = 'Please Sign In';
      return;
    }

    const playerId = String(this.currentCustomer.id || '').toLowerCase();
    const records = [];

    // 1. Initial signup welcome bonus
    records.push({
      date: new Date(this.currentCustomer.joinedAt || Date.now() - 86400000),
      desc: '🎁 Welcome Bonus Credited',
      type: 'DEPOSIT',
      amount: '+10.00',
      color: '#2ecc71',
      rawAmt: 10
    });

    // 2. Deposits
    (this.deposits || []).filter(d => String(d.customerId || '').toLowerCase() === playerId).forEach(d => {
      records.push({
        date: new Date(d.requestedAt || Date.now()),
        desc: `💳 Deposit (${d.utr ? 'UTR: ' + d.utr : d.id}) [${d.status}]`,
        type: 'DEPOSIT',
        amount: d.status === 'APPROVED' ? `+${d.amount}.00` : `${d.amount}.00 (${d.status})`,
        color: d.status === 'APPROVED' ? '#2ecc71' : '#ffd700',
        rawAmt: d.status === 'APPROVED' ? Number(d.amount) : 0
      });
    });

    // 3. Withdrawals
    (this.withdrawals || []).filter(w => String(w.customerId || '').toLowerCase() === playerId).forEach(w => {
      records.push({
        date: new Date(w.requestedAt || Date.now()),
        desc: `💸 Withdrawal Request [${w.status}]`,
        type: 'WITHDRAW',
        amount: `-${w.amount}.00`,
        color: '#ff6b6b',
        rawAmt: -Number(w.amount)
      });
    });

    // 4. Bets
    (this.activeBets || []).filter(b => String(b.playerId || b.customerId || '').toLowerCase() === playerId).forEach(b => {
      records.push({
        date: new Date(b.timestamp || Date.now()),
        desc: `🎯 Prediction Bet #${b.number || b.no} (${b.targetSlot || 'Slot'})`,
        type: 'BETS',
        amount: `-${b.amount || b.coins}.00`,
        color: '#ff6b6b',
        rawAmt: -Number(b.amount || b.coins)
      });
    });

    // 5. Settled Bet History (Wins & Losses)
    if (this.currentCustomer && Array.isArray(this.currentCustomer.betHistory)) {
      this.currentCustomer.betHistory.forEach(b => {
        if (b.status === 'WON') {
          records.push({
            date: new Date(b.timestamp || Date.now()),
            desc: `🏆 Won Prediction #${b.number || b.no} (9x Payout)`,
            type: 'BETS',
            amount: `+${b.payout || (Number(b.amount) * 9)}.00`,
            color: '#2ecc71',
            rawAmt: Number(b.payout || (Number(b.amount) * 9))
          });
        }
      });
    }

    records.sort((a, b) => b.date - a.date);

    let filtered = records;
'@

if ($content -match $targetPattern) {
    $newContent = [regex]::Replace($content, $targetPattern, $replacement)
    [System.IO.File]::WriteAllText($path, $newContent, [System.Text.Encoding]::UTF8)
    Write-Host "Replaced renderAccountStatement successfully!"
} else {
    Write-Host "Pattern not matched!"
}

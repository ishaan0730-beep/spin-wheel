$htmlPath = "C:\Users\ishaa\.gemini\antigravity-ide\scratch\spin-wheel-app\index.html"
$content = [System.IO.File]::ReadAllText($htmlPath, [System.Text.Encoding]::UTF8)

$target = @'
                    <div class="form-group" style="margin-top:0.4rem;">
                      <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:2px;">
                        <label class="field-label" style="font-size:0.75rem; color:#cbd5e1; margin:0;">CallMeBot WhatsApp API Key (Free):</label>
                        <a href="https://api.whatsapp.com/send?phone=34644442439&text=I%20allow%20callmebot%20to%20send%20me%20messages" target="_blank" rel="noopener noreferrer" style="font-size:0.68rem; color:#25D366; text-decoration:none; font-weight:700;">📲 1-Click Get Key on WhatsApp</a>
                      </div>
                      <input type="text" id="admin-cfg-wa-apikey" class="admin-input" placeholder="e.g. 1234567" style="padding:0.4rem 0.6rem; font-size:0.8rem; font-family:monospace;">
                      <span style="font-size:0.65rem; color:var(--text-muted); display:block; margin-top:2px;">
                        Free Key in 5 secs: Click "1-Click Get Key", send message to <strong>+34 644 44 24 39</strong> &amp; paste key above.
                      </span>
                    </div>
'@

$replacement = @'
                    <div class="form-group" style="margin-top:0.4rem;">
                      <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:2px;">
                        <label class="field-label" style="font-size:0.75rem; color:#cbd5e1; margin:0;">CallMeBot WhatsApp API Key (Free):</label>
                        <a href="https://api.whatsapp.com/send?phone=34644992698&text=I%20allow%20callmebot%20to%20send%20me%20messages" target="_blank" rel="noopener noreferrer" style="font-size:0.68rem; color:#25D366; text-decoration:none; font-weight:700;">📲 1-Click Get Key on WhatsApp</a>
                      </div>
                      <input type="text" id="admin-cfg-wa-apikey" class="admin-input" placeholder="e.g. 1234567 (Send to +34 644 99 26 98)" style="padding:0.4rem 0.6rem; font-size:0.8rem; font-family:monospace;">
                      <span style="font-size:0.65rem; color:var(--text-muted); display:block; margin-top:2px;">
                        Free Key: Click button above to send message to <strong>+34 644 99 26 98</strong> (Backup: <a href="https://api.whatsapp.com/send?phone=34644263377&text=I%20allow%20callmebot%20to%20send%20me%20messages" target="_blank" rel="noopener" style="color:#00f0ff;">+34 644 26 33 77</a>) &amp; paste key here.
                      </span>
                    </div>
'@

if ($content.Contains($target)) {
    $content = $content.Replace($target, $replacement)
    [System.IO.File]::WriteAllText($htmlPath, $content, [System.Text.Encoding]::UTF8)
    Write-Host "Updated active CallMeBot numbers in index.html!"
} else {
    Write-Host "Warning: target block not found directly."
}

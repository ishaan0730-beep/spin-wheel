$path = "C:\Users\ishaa\.gemini\antigravity-ide\scratch\spin-wheel-app\server_state.json"
$state = Get-Content $path -Raw | ConvertFrom-Json

# Clean and sort history
$cleanHistory = @(
    [PSCustomObject]@{
        id = 1791346800000
        number = 80
        source = "Scheduled Round"
        round = "11:00 PM"
        date = "Oct 6"
        timestamp = 1791346800000
        time = "11:00 PM"
    },
    [PSCustomObject]@{
        id = 1791336000000
        number = 40
        source = "Scheduled Round"
        round = "08:00 PM"
        date = "Oct 6"
        timestamp = 1791336000000
        time = "08:00 PM"
    },
    [PSCustomObject]@{
        id = 1791321600000
        number = 60
        source = "Scheduled Round"
        round = "04:00 PM"
        date = "Oct 6"
        timestamp = 1791321600000
        time = "04:00 PM"
    },
    [PSCustomObject]@{
        id = 1791307200000
        number = 50
        source = "Scheduled Round"
        round = "12:00 PM"
        date = "Oct 6"
        timestamp = 1791307200000
        time = "12:00 PM"
    },
    [PSCustomObject]@{
        id = 1791260400000
        number = 70
        source = "Scheduled Round"
        round = "11:00 PM"
        date = "Oct 5"
        timestamp = 1791260400000
        time = "11:00 PM"
    },
    [PSCustomObject]@{
        id = 1791249600000
        number = 20
        source = "Scheduled Round"
        round = "08:00 PM"
        date = "Oct 5"
        timestamp = 1791249600000
        time = "08:00 PM"
    },
    [PSCustomObject]@{
        id = 1791235200000
        number = 90
        source = "Scheduled Round"
        round = "04:00 PM"
        date = "Oct 5"
        timestamp = 1791235200000
        time = "04:00 PM"
    },
    [PSCustomObject]@{
        id = 1791220800000
        number = 30
        source = "Scheduled Round"
        round = "12:00 PM"
        date = "Oct 5"
        timestamp = 1791220800000
        time = "12:00 PM"
    }
)

$state.history = $cleanHistory
$json = $state | ConvertTo-Json -Depth 10
[System.IO.File]::WriteAllText($path, $json)
Write-Host "server_state.json history successfully cleaned and sorted in sequence!"

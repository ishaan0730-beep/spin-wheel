$file = "C:\Users\ishaa\.gemini\antigravity-ide\scratch\spin-wheel-app\app.js"
$rawBytes = [System.IO.File]::ReadAllBytes($file)
$str = [System.Text.Encoding]::UTF8.GetString($rawBytes)

# Replace leaked promo code alert
$oldAlert = "alert('Please enter a valid Promo Code (e.g. WELCOME100, CRIC99, BONUS50, LUCKY10)');"
$newAlert = "this.showLiveToast({ title: 'PROMO CODE', message: 'Please enter a valid Promo Code.', type: 'deposit', duration: 3000 });"
$str = $str.Replace($oldAlert, $newAlert)

# Replace Support Chat Desk implementation in refreshSupportChatsUI to also list registered customers
$oldSupportFn = @"
  refreshSupportChatsUI() {
    const listEl = document.getElementById('admin-chat-threads-list');
    const feedEl = document.getElementById('admin-chat-messages-wrap') || document.getElementById('admin-chat-messages-feed');
    const nameEl = document.getElementById('admin-selected-chat-name');
    const subEl = document.getElementById('admin-selected-chat-sub');
    const actionsEl = document.getElementById('admin-selected-chat-actions');
    const countEl = document.getElementById('admin-active-chats-count');
    if (!listEl) return;

    const chats = this.supportChats || {};
    const playerIds = Object.keys(chats);

    if (countEl) countEl.textContent = playerIds.length;

    if (playerIds.length === 0) {
      listEl.innerHTML = `<div style="padding:1.5rem; text-align:center; color:var(--text-muted); font-size:0.78rem;">No active support inquiries yet. New customer messages will appear here instantly.</div>`;
      if (feedEl) feedEl.innerHTML = `<div style="padding:2rem; text-align:center; color:var(--text-muted); font-size:0.8rem;">Select a player on the left to start live messaging.</div>`;
      if (nameEl) nameEl.textContent = 'Select a conversation';
      if (subEl) subEl.textContent = 'Click any player from the list to view and reply';
      if (actionsEl) actionsEl.classList.add('hidden');
      return;
    }
"@

$newSupportFn = @"
  refreshSupportChatsUI() {
    const listEl = document.getElementById('admin-chat-threads-list');
    const feedEl = document.getElementById('admin-chat-messages-wrap') || document.getElementById('admin-chat-messages-feed');
    const nameEl = document.getElementById('admin-selected-chat-name');
    const subEl = document.getElementById('admin-selected-chat-sub');
    const actionsEl = document.getElementById('admin-selected-chat-actions');
    const countEl = document.getElementById('admin-active-chats-count');
    if (!listEl) return;

    const chats = this.supportChats || {};
    const chatPlayerIds = Object.keys(chats);
    const dbPlayerIds = Object.keys(this.customersDb || {});
    
    // Combine chat threads and registered customers
    const allPlayerIdsSet = new Set([...chatPlayerIds, ...dbPlayerIds]);
    const allPlayerIds = Array.from(allPlayerIdsSet);

    if (countEl) countEl.textContent = chatPlayerIds.length;

    if (allPlayerIds.length === 0) {
      listEl.innerHTML = `<div style="padding:1.5rem; text-align:center; color:var(--text-muted); font-size:0.78rem;">No registered players or support inquiries yet.</div>`;
      if (feedEl) feedEl.innerHTML = `<div style="padding:2rem; text-align:center; color:var(--text-muted); font-size:0.8rem;">Select a player on the left to start live messaging.</div>`;
      if (nameEl) nameEl.textContent = 'Select a conversation';
      if (subEl) subEl.textContent = 'Click any player from the list to view and reply';
      if (actionsEl) actionsEl.classList.add('hidden');
      return;
    }
"@

$str = $str.Replace($oldSupportFn, $newSupportFn)

[System.IO.File]::WriteAllBytes($file, [System.Text.Encoding]::UTF8.GetBytes($str))
Write-Host "app.js updated successfully."

$jsFile = 'C:\Users\ishaa\.gemini\antigravity-ide\scratch\spin-wheel-app\app.js'
$lines = [System.IO.File]::ReadAllLines($jsFile, [System.Text.Encoding]::UTF8)

$bag = [string][char]0xD83D + [string][char]0xDCB0

for ($i = 0; $i -lt $lines.Length; $i++) {
    if ($lines[$i] -match 'Logged Out \(0 IHD Coins\)') {
        $lines[$i] = '      if (this.playerWalletDisplay) this.playerWalletDisplay.textContent = "' + $bag + ' Logged Out (0 IHD Coins)";'
    }
    if ($lines[$i] -match 'chipPlayerCoins.*textContent') {
        $lines[$i] = '      if (this.chipPlayerCoins) this.chipPlayerCoins.textContent = "' + $bag + ' " + coins.toLocaleString() + " IHD";'
    }
    if ($lines[$i] -match 'playerWalletDisplay.*textContent = `') {
        $lines[$i] = '      if (this.playerWalletDisplay) this.playerWalletDisplay.textContent = "' + $bag + ' " + coins.toLocaleString() + " IHD Coins";'
    }
    if ($lines[$i] -match 'dashPlayerCoins.*textContent') {
        $lines[$i] = '      if (this.dashPlayerCoins) this.dashPlayerCoins.textContent = "' + $bag + ' " + coins.toLocaleString() + " IHD Coins";'
    }
}

[System.IO.File]::WriteAllLines($jsFile, $lines, [System.Text.Encoding]::UTF8)
Write-Host 'app.js wallet displays updated cleanly!'

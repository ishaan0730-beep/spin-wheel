$appPath = "C:\Users\ishaa\.gemini\antigravity-ide\scratch\spin-wheel-app\app.js"
$content = [System.IO.File]::ReadAllText($appPath, [System.Text.Encoding]::UTF8)

# Target pattern: from '// 8. Promo Code Redeemer' to '// ==========================================\s*// DRAWER HELPERS'
$targetPattern = '(?s)// 8\. Promo Code Redeemer.*?// ==========================================\s*// DRAWER HELPERS'

$replacement = @'
// 8. Master Promo Codes Subsystem (Only Master Generates + Strict 1-Use Per Account)
  loadLocalPromoCodes() {
    try {
      const raw = localStorage.getItem('lucky_spin_promo_codes_v7');
      if (raw) return JSON.parse(raw);
    } catch (e) {}
    return {
      'WELCOME100': {
        code: 'WELCOME100',
        bonus: 100,
        active: true,
        maxUsesPerUser: 1,
        createdAt: Date.now() - 86400000 * 3,
        redeemedBy: {}
      }
    };
  }

  savePromoCodes(promos) {
    this.promoCodes = promos || {};
    try {
      localStorage.setItem('lucky_spin_promo_codes_v7', JSON.stringify(this.promoCodes));
    } catch (e) {}
    this.updatePromoBadges();
  }

  updatePromoBadges() {
    const badge = document.getElementById('admin-tab-badge-promos') || this.adminTabBadgePromos;
    const countBadge = document.getElementById('admin-promos-count-badge');
    const totalActive = Object.values(this.promoCodes || {}).filter(p => p && p.active).length;
    if (badge) badge.textContent = totalActive;
    if (countBadge) countBadge.textContent = Object.keys(this.promoCodes || {}).length;
  }

  adminCreatePromoCode() {
    const codeInp = document.getElementById('admin-new-promo-code');
    const bonusInp = document.getElementById('admin-new-promo-bonus');
    const code = (codeInp?.value || '').trim().toUpperCase().replace(/[^A-Z0-9_-]/g, '');
    const bonus = parseFloat(bonusInp?.value || '0');

    if (!code || code.length < 3) {
      alert('Please enter a valid Promo Code name (at least 3 characters, e.g. BONUS500).');
      return;
    }
    if (isNaN(bonus) || bonus <= 0) {
      alert('Please enter a valid positive Coin Bonus amount (e.g. 100).');
      return;
    }

    if (!this.promoCodes) this.promoCodes = {};
    if (this.promoCodes[code]) {
      if (!confirm(`Promo Code "${code}" already exists! Do you want to update its bonus to ₹${bonus.toFixed(2)}?`)) {
        return;
      }
    }

    this.promoCodes[code] = {
      code: code,
      bonus: bonus,
      active: true,
      maxUsesPerUser: 1,
      createdAt: Date.now(),
      redeemedBy: (this.promoCodes[code] && this.promoCodes[code].redeemedBy) ? this.promoCodes[code].redeemedBy : {}
    };

    this.savePromoCodes(this.promoCodes);
    this.pushStateToServer({ promoCodes: this.promoCodes });

    if (codeInp) codeInp.value = '';
    if (bonusInp) bonusInp.value = '';

    this.renderAdminPromosList();

    this.showLiveToast({
      title: '🎁 PROMO CODE CREATED',
      message: `Code <b>${code}</b> created with <b>+${bonus} Coins</b> bonus!`,
      type: 'success',
      duration: 4000
    });
  }

  adminTogglePromoCode(code) {
    if (!this.promoCodes || !this.promoCodes[code]) return;
    this.promoCodes[code].active = !this.promoCodes[code].active;
    this.savePromoCodes(this.promoCodes);
    this.pushStateToServer({ promoCodes: this.promoCodes });
    this.renderAdminPromosList();
    this.showLiveToast({
      title: this.promoCodes[code].active ? '✅ PROMO ACTIVATED' : '⏸️ PROMO DEACTIVATED',
      message: `Code ${code} is now ${this.promoCodes[code].active ? 'ACTIVE' : 'DISABLED'}.`,
      type: 'success',
      duration: 3000
    });
  }

  adminDeletePromoCode(code) {
    if (!this.promoCodes || !this.promoCodes[code]) return;
    if (!confirm(`Are you sure you want to permanently delete Promo Code "${code}"?`)) return;
    delete this.promoCodes[code];
    this.savePromoCodes(this.promoCodes);
    this.pushStateToServer({ promoCodes: this.promoCodes });
    this.renderAdminPromosList();
    this.showLiveToast({
      title: '🗑️ PROMO DELETED',
      message: `Code ${code} deleted successfully.`,
      type: 'success',
      duration: 3000
    });
  }

  renderAdminPromosList() {
    const tbody = document.getElementById('admin-promos-table-body');
    const badge = document.getElementById('admin-promos-count-badge');
    if (!tbody) return;

    const promos = this.promoCodes || {};
    const keys = Object.keys(promos);
    if (badge) badge.textContent = keys.length;

    if (keys.length === 0) {
      tbody.innerHTML = '<tr><td colspan="6" style="text-align:center; color:var(--text-muted); padding:1.5rem;">No promo codes created yet. Generate one above!</td></tr>';
      return;
    }

    tbody.innerHTML = keys.map(k => {
      const p = promos[k];
      const redCount = p.redeemedBy ? Object.keys(p.redeemedBy).length : 0;
      const createdStr = p.createdAt ? new Date(p.createdAt).toLocaleDateString([], { month: 'short', day: 'numeric', year: 'numeric' }) : 'N/A';
      const isActive = p.active !== false;

      return `
        <tr>
          <td><strong style="color:var(--primary-gold-bright); letter-spacing:1px; font-size:0.88rem;">🎁 ${this.escapeHTML(p.code)}</strong></td>
          <td><span style="color:#2ecc71; font-weight:800; font-size:0.9rem;">+₹${Number(p.bonus).toFixed(2)}</span></td>
          <td><span style="font-size:0.8rem; color:#00f0ff; font-weight:700;">👤 ${redCount} player${redCount === 1 ? '' : 's'}</span></td>
          <td style="font-size:0.75rem; color:var(--text-secondary);">${createdStr}</td>
          <td>
            <span style="font-size:0.72rem; font-weight:800; padding:2px 8px; border-radius:10px; background:${isActive ? 'rgba(46,204,113,0.2)' : 'rgba(239,68,68,0.2)'}; color:${isActive ? '#2ecc71' : '#ef4444'}; border:1px solid ${isActive ? 'rgba(46,204,113,0.4)' : 'rgba(239,68,68,0.4)'};">
              ${isActive ? 'ACTIVE' : 'DISABLED'}
            </span>
          </td>
          <td>
            <div style="display:flex; gap:6px;">
              <button type="button" class="btn btn-secondary btn-xs" onclick="window.app.adminTogglePromoCode('${this.escapeHTML(p.code)}')" title="Toggle Active">
                ${isActive ? '⏸️ Disable' : '▶️ Enable'}
              </button>
              <button type="button" class="btn btn-secondary btn-xs" style="color:#ef4444;" onclick="window.app.adminDeletePromoCode('${this.escapeHTML(p.code)}')" title="Delete Promo">
                🗑️ Delete
              </button>
            </div>
          </td>
        </tr>
      `;
    }).join('');
  }

  applyPromoCode(code) {
    if (!this.currentCustomer) {
      this.openAuthModal('signin');
      this.showLiveToast({
        title: '🔑 PLEASE SIGN IN',
        message: 'Please sign in or register to redeem promo codes!',
        type: 'deposit',
        duration: 4000
      });
      return;
    }

    const cleanCode = (code || '').trim().toUpperCase();
    if (!cleanCode) {
      this.showLiveToast({
        title: '🎁 ENTER PROMO CODE',
        message: 'Please enter a promo code to apply.',
        type: 'deposit',
        duration: 3000
      });
      return;
    }

    if (!this.promoCodes) this.promoCodes = this.loadLocalPromoCodes();
    const promoObj = this.promoCodes[cleanCode];

    if (!promoObj || promoObj.active === false) {
      this.showLiveToast({
        title: '❌ INVALID PROMO CODE',
        message: 'This promo code is invalid or has expired.',
        type: 'withdrawal',
        duration: 4000
      });
      return;
    }

    const custId = String(this.currentCustomer.id || '').toLowerCase();
    const redeemedBy = promoObj.redeemedBy || {};

    if (redeemedBy[custId] || redeemedBy[this.currentCustomer.id]) {
      this.showLiveToast({
        title: '⚠️ ALREADY REDEEMED',
        message: 'You have already redeemed this promo code once! (Only 1 redemption per player).',
        type: 'withdrawal',
        duration: 5000
      });
      return;
    }

    const bonus = Number(promoObj.bonus) || 0;
    if (bonus <= 0) {
      this.showLiveToast({
        title: '❌ INVALID PROMO CODE',
        message: 'This promo code is no longer active.',
        type: 'withdrawal',
        duration: 4000
      });
      return;
    }

    // Mark as redeemed for this player
    if (!promoObj.redeemedBy) promoObj.redeemedBy = {};
    promoObj.redeemedBy[custId] = Date.now();
    promoObj.redeemedBy[this.currentCustomer.id] = Date.now();
    this.savePromoCodes(this.promoCodes);

    // Credit coins to customer
    this.currentCustomer.coins = (Number(this.currentCustomer.coins) || 0) + bonus;
    if (this.customersDb && this.customersDb[this.currentCustomer.id]) {
      this.customersDb[this.currentCustomer.id].coins = this.currentCustomer.coins;
      this.saveCustomersDB(this.customersDb);
    }
    this.saveCustomerSession(this.currentCustomer);
    this.updateCustomerUI();

    // Push state update to server
    this.pushStateToServer({
      promoCodes: this.promoCodes,
      customersDb: this.customersDb
    });

    // Celebration Fanfare & Confetti
    if (this.confetti) this.confetti.fire(3000);
    if (this.audio) this.audio.playWinFanfare();

    this.showLiveToast({
      title: '🎉 PROMO CODE APPLIED!',
      message: `Code <b>${cleanCode}</b> applied! 💰<b>+${bonus.toFixed(2)} IHD Coins</b> credited instantly to your wallet!`,
      type: 'success',
      duration: 6000
    });

    const promoInp = document.getElementById('cric-promo-input');
    if (promoInp) promoInp.value = '';
  }

  // ==========================================
  // DRAWER HELPERS
'@

if ($content -match $targetPattern) {
    $content = [regex]::Replace($content, $targetPattern, $replacement)
    Write-Host "Replaced applyPromoCode with Master Promo Subsystem in app.js"
} else {
    Write-Host "Target pattern for applyPromoCode not matched!"
}

# Also update pushStateToServer in app.js
$pushPattern = '(?s)this\.pushStateToServer\(\{\s*supportChats: this\.supportChats'
if ($content -match $pushPattern) {
    $content = $content -replace 'supportChats: this\.supportChats', 'supportChats: this.supportChats, promoCodes: this.promoCodes'
    Write-Host "Added promoCodes to pushStateToServer in app.js"
}

# Also update applyServerState in app.js
$applyServerPattern = 'if \(state\.supportChats && typeof state\.supportChats === ''object''\) \{'
$applyServerReplacement = @'
if (state.promoCodes && typeof state.promoCodes === 'object') {
      this.promoCodes = state.promoCodes;
      this.savePromoCodes(this.promoCodes);
      this.renderAdminPromosList();
    }

    if (state.supportChats && typeof state.supportChats === 'object') {
'@
if ($content -match $applyServerPattern) {
    $content = $content.Replace($applyServerPattern, $applyServerReplacement)
    Write-Host "Added promoCodes handling in applyServerState in app.js"
}

[System.IO.File]::WriteAllText($appPath, $content, [System.Text.Encoding]::UTF8)
Write-Host "app.js updated safely!"

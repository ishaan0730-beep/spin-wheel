﻿$appPath = "C:\Users\ishaa\.gemini\antigravity-ide\scratch\spin-wheel-app\app.js"
$content = [System.IO.File]::ReadAllText($appPath, [System.Text.Encoding]::UTF8)

# Check for presence of buggy string
$hasBug = $content.Contains('${dateStr}__lucky_salt_v8')
Write-Host "Has buggy salt v8: $hasBug"

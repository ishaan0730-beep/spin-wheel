$statePath = "C:\Users\ishaa\.gemini\antigravity-ide\scratch\spin-wheel-app\server_state.json"
$stateObj = Get-Content $statePath -Raw -Encoding UTF8 | ConvertFrom-Json

if ($null -eq $stateObj.promoCodes) {
    $promoObj = [PSCustomObject]@{
        WELCOME100 = [PSCustomObject]@{
            code = "WELCOME100"
            bonus = 100
            active = $true
            maxUsesPerUser = 1
            createdAt = 1791181200000
            redeemedBy = [PSCustomObject]@{}
        }
    }
    $stateObj | Add-Member -MemberType NoteProperty -Name "promoCodes" -Value $promoObj -Force
    $newJson = $stateObj | ConvertTo-Json -Depth 25
    [System.IO.File]::WriteAllText($statePath, $newJson, (New-Object System.Text.UTF8Encoding($false)))
    Write-Host "Initialized promoCodes in server_state.json successfully!"
} else {
    Write-Host "promoCodes already exists in server_state.json"
}

﻿Add-Type -AssemblyName System.Drawing

$srcPath = "C:\Users\ishaa\.gemini\antigravity-ide\brain\badc9f3d-0024-4e29-ad87-88490781ece6\.user_uploaded\media_1791376024450.jpg"
$img = [System.Drawing.Image]::FromFile($srcPath)
Write-Host "Original Dimensions: $($img.Width) x $($img.Height)"
$img.Dispose()

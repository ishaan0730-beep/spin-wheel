﻿$appPath = "C:\Users\ishaa\.gemini\antigravity-ide\scratch\spin-wheel-app\app.js"
$content = [System.IO.File]::ReadAllText($appPath, [System.Text.Encoding]::UTF8)

# 1. Add sanitizeHistory method to WheelApp class (just above loadLocalSlices)
$oldLoadSlices = "  loadLocalSlices() {"
$newSanitizeAndSlices = @"
  sanitizeHistory(list) {
    if (!Array.isArray(list)) return [];
    const slices = [10, 20, 30, 40, 50, 60, 70, 80, 90, 100];
    const histMap = new Map();

    list.forEach(item => {
      if (!item) return;
      let cleanTime = String(item.time || item.round || 'Completed').replace(/\s*\([^)]*\)/g, '').trim();
      let cleanRound = String(item.round || item.time || 'Round').replace(/\s*\([^)]*\)/g, '').trim();
      let num = Number(item.number);
      let dateStr = String(item.date || '').trim();

      // Fix 12:00 PM on Oct 7 if it was incorrectly set to 60
      if ((dateStr.includes('Oct 7') || dateStr.includes('7')) && (cleanRound === '12:00 PM' || cleanTime.includes('12:00'))) {
        num = 40;
      }
      if ((dateStr.includes('Oct 7') || dateStr.includes('7')) && (cleanRound === '04:00 PM' || cleanTime.includes('04:00') || cleanTime.includes('4:00'))) {
        num = 90;
      }

      const cleanItem = {
        ...item,
        number: num,
        time: cleanTime,
        round: cleanRound,
        date: dateStr,
        timestamp: item.timestamp || item.id || Date.now()
      };

      const key = `${dateStr}_${cleanRound}`;
      if (!histMap.has(key)) {
        histMap.set(key, cleanItem);
      }
    });

    const sorted = Array.from(histMap.values())
      .sort((a, b) => (b.timestamp || b.id || 0) - (a.timestamp || a.id || 0))
      .slice(0, 150);

    for (let i = 0; i < sorted.length; i++) {
      if (i > 0 && sorted[i - 1]) {
        if (sorted[i].number === sorted[i - 1].number) {
          const curI = slices.indexOf(Number(sorted[i].number));
          sorted[i].number = slices[(curI + 3) % slices.length];
        }
      }
    }
    return sorted;
  }

  loadLocalSlices() {
"@

if ($content.Contains($oldLoadSlices) -and -not $content.Contains("sanitizeHistory(list)")) {
    $content = $content.Replace($oldLoadSlices, $newSanitizeAndSlices)
    Write-Host "Added sanitizeHistory method"
}

# 2. Update loadLocalHistory
$oldLoadHistory = @"
  loadLocalHistory() {
    try {
      const saved = localStorage.getItem(STATE_KEYS.HISTORY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch (e) {}
    return [];
  }
"@

$newLoadHistory = @"
  loadLocalHistory() {
    try {
      const saved = localStorage.getItem(STATE_KEYS.HISTORY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return this.sanitizeHistory(parsed);
        }
      }
    } catch (e) {}
    return [
      { id: 1791369600000, number: 90, time: '04:00 PM', date: 'Oct 7', round: '04:00 PM', source: 'Scheduled Round', timestamp: 1791369600000 },
      { id: 1791355200000, number: 40, time: '12:00 PM', date: 'Oct 7', round: '12:00 PM', source: 'Slot 12:00 PM', timestamp: 1791355200000 },
      { id: 1791308400000, number: 80, time: '11:00 PM', date: 'Oct 6', round: '11:00 PM', source: 'Scheduled Round', timestamp: 1791308400000 },
      { id: 1791297600000, number: 30, time: '08:00 PM', date: 'Oct 6', round: '08:00 PM', source: 'Scheduled Round', timestamp: 1791297600000 },
      { id: 1791283200000, number: 50, time: '04:00 PM', date: 'Oct 6', round: '04:00 PM', source: 'Scheduled Round', timestamp: 1791283200000 },
      { id: 1791268800000, number: 70, time: '12:00 PM', date: 'Oct 6', round: '12:00 PM', source: 'Scheduled Round', timestamp: 1791268800000 }
    ];
  }
"@

if ($content.Contains($oldLoadHistory)) {
    $content = $content.Replace($oldLoadHistory, $newLoadHistory)
    Write-Host "Updated loadLocalHistory"
}

# 3. Update applyServerState history handling
$oldApplyHist = @"
    // 2. History (STRICT SYNCHRONIZED CLOUD REPLICATION)
    if (Array.isArray(state.history)) {
      if (state.history.length > 0) {
        const currJson = JSON.stringify(this.history || []);
        const newJson = JSON.stringify(state.history);
        if (currJson !== newJson) {
          const rawHist = state.history || [];
          for (let hIdx = 0; hIdx < rawHist.length; hIdx++) {
            if (hIdx > 0 && rawHist[hIdx - 1]) {
              if (rawHist[hIdx].number === rawHist[hIdx - 1].number) {
                const curI = this.slices.indexOf(Number(rawHist[hIdx].number));
                rawHist[hIdx].number = this.slices[(curI + 3) % this.slices.length];
              }
            }
          }
          this.history = rawHist;
          localStorage.setItem(STATE_KEYS.HISTORY, JSON.stringify(this.history));
          historyNeedsRedraw = true;
        }
      }
    }
"@

$newApplyHist = @"
    // 2. History (STRICT SYNCHRONIZED CLOUD REPLICATION)
    if (Array.isArray(state.history) && state.history.length > 0) {
      const sanitized = this.sanitizeHistory(state.history);
      const currJson = JSON.stringify(this.history || []);
      const newJson = JSON.stringify(sanitized);
      if (currJson !== newJson) {
        this.history = sanitized;
        localStorage.setItem(STATE_KEYS.HISTORY, JSON.stringify(this.history));
        historyNeedsRedraw = true;
      }
    }
"@

if ($content.Contains($oldApplyHist)) {
    $content = $content.Replace($oldApplyHist, $newApplyHist)
    Write-Host "Updated applyServerState history block"
}

# 4. Update renderLast3Results
$oldRenderLast3 = @"
  renderLast3Results() {
    if (!this.resultsGrid) return;
    this.resultsGrid.innerHTML = '';
    const last3 = (this.history || []).slice(0, 3);
    const ranks = ['1st Previous', '2nd Previous', '3rd Previous'];

    for (let i = 0; i < 3; i++) {
      const card = document.createElement('div');
      const item = last3[i];

      if (item) {
        card.className = ``result-card `${i === 0 ? 'latest-win' : ''}``;
        const displayDate = item.date ? ````${item.date} â€¢ ```` : '';
        const displayTime = item.time || item.round || 'Completed';
        card.innerHTML = ``
          <div class="result-rank">`${i === 0 ? 'ðŸ † Latest Winner' : ranks[i]}</div>
          <div class="result-number">`${item.number}</div>
          <div class="result-meta">`${displayDate}`${displayTime}</div>
        ``;
      } else {
        card.className = 'result-card empty-card';
        card.innerHTML = ``
          <div class="result-rank">`${ranks[i]}</div>
          <div class="result-number">--</div>
          <div class="result-meta">Awaiting Spin</div>
        ``;
      }
      this.resultsGrid.appendChild(card);
    }

    if (this.allHistoryCountBadge) {
      this.allHistoryCountBadge.textContent = (this.history || []).length;
    }
  }
"@

# Let's use regex or search for renderLast3Results
$renderIdx = $content.IndexOf("renderLast3Results() {")
if ($renderIdx -ge 0) {
    $renderEnd = $content.IndexOf("openAllSpinHistoryModal()", $renderIdx)
    if ($renderEnd -gt $renderIdx) {
        $oldRenderBlock = $content.Substring($renderIdx, $renderEnd - $renderIdx)
        $newRenderBlock = @"
renderLast3Results() {
    if (!this.resultsGrid) return;
    this.resultsGrid.innerHTML = '';
    const last3 = (this.history || []).slice(0, 3);
    const ranks = ['1st Previous', '2nd Previous', '3rd Previous'];

    for (let i = 0; i < 3; i++) {
      const card = document.createElement('div');
      const item = last3[i];

      if (item) {
        card.className = `result-card `${i === 0 ? 'latest-win' : ''}`;
        const cleanTime = String(item.time || item.round || 'Completed').replace(/\s*\([^)]*\)/g, '').trim();
        const displayDate = item.date ? `${item.date} • ` : '';
        card.innerHTML = `
          <div class="result-rank">${i === 0 ? '🏆 Latest Winner' : ranks[i]}</div>
          <div class="result-number">${item.number}</div>
          <div class="result-meta">${displayDate}${cleanTime}</div>
        `;
      } else {
        card.className = 'result-card empty-card';
        card.innerHTML = `
          <div class="result-rank">${ranks[i]}</div>
          <div class="result-number">--</div>
          <div class="result-meta">Awaiting Spin</div>
        `;
      }
      this.resultsGrid.appendChild(card);
    }

    if (this.allHistoryCountBadge) {
      this.allHistoryCountBadge.textContent = (this.history || []).length;
    }
  }

  
"@
        $content = $content.Substring(0, $renderIdx) + $newRenderBlock + $content.Substring($renderEnd)
        Write-Host "Updated renderLast3Results successfully"
    }
}

[System.IO.File]::WriteAllText($appPath, $content, [System.Text.Encoding]::UTF8)
Write-Host "Finished initial patch pass"

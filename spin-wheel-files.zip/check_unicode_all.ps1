﻿$files = @("app.js", "index.html", "style.css", "api/state.js")

foreach ($f in $files) {
    $c = [System.IO.File]::ReadAllText($f, [System.Text.Encoding]::UTF8)
    $hasGarbage = $c -match "ðŸ|â€|ï¿½"
    Write-Host "File $f has corrupted unicode: $hasGarbage"
}

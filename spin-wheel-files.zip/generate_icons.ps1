Add-Type -AssemblyName System.Drawing

function Create-AppIcon([int]$size, [string]$path) {
    $bmp = New-Object System.Drawing.Bitmap($size, $size)
    $g = [System.Drawing.Graphics]::FromImage($bmp)
    $g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
    $g.TextRenderingHint = [System.Drawing.Text.TextRenderingHint]::AntiAliasGridFit

    # Background dark luxury circle
    $bgBrush = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::FromArgb(255, 5, 7, 12))
    $g.FillRectangle($bgBrush, 0, 0, $size, $size)

    # Outer Gold Glow Ring
    $center = [float]($size / 2.0)
    $radius = [float]($size * 0.44)
    $rect = New-Object System.Drawing.RectangleF(($center - $radius), ($center - $radius), ($radius * 2), ($radius * 2))

    $wheelBrush = New-Object System.Drawing.Drawing2D.LinearGradientBrush($rect, [System.Drawing.Color]::FromArgb(255, 245, 176, 65), [System.Drawing.Color]::FromArgb(255, 234, 88, 12), [float]45.0)
    $g.FillEllipse($wheelBrush, $rect)

    # Inner Dark Wheel
    $innerRadius = [float]($size * 0.39)
    $innerRect = New-Object System.Drawing.RectangleF(($center - $innerRadius), ($center - $innerRadius), ($innerRadius * 2), ($innerRadius * 2))
    $innerBrush = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::FromArgb(255, 15, 23, 42))
    $g.FillEllipse($innerBrush, $innerRect)

    # 10 Wheel Segments
    $numSegments = 10
    $angleStep = 360.0 / $numSegments
    for ($i = 0; $i -lt $numSegments; $i++) {
        $startAngle = $i * $angleStep
        $color = if ($i % 2 -eq 0) { [System.Drawing.Color]::FromArgb(220, 245, 176, 65) } else { [System.Drawing.Color]::FromArgb(220, 0, 240, 255) }
        $segPen = New-Object System.Drawing.Pen($color, [float]($size * 0.015))
        $rad = [Math]::PI * $startAngle / 180.0
        $x2 = [float]($center + $innerRadius * [Math]::Cos($rad))
        $y2 = [float]($center + $innerRadius * [Math]::Sin($rad))
        $g.DrawLine($segPen, $center, $center, $x2, $y2)
        $segPen.Dispose()
    }

    # Center Gold Hub
    $hubRadius = [float]($size * 0.18)
    $hubRect = New-Object System.Drawing.RectangleF(($center - $hubRadius), ($center - $hubRadius), ($hubRadius * 2), ($hubRadius * 2))
    $hubBrush = New-Object System.Drawing.Drawing2D.LinearGradientBrush($hubRect, [System.Drawing.Color]::FromArgb(255, 255, 215, 0), [System.Drawing.Color]::FromArgb(255, 245, 176, 65), [float]90.0)
    $g.FillEllipse($hubBrush, $hubRect)

    # Inner Hub Ring
    $hubPen = New-Object System.Drawing.Pen([System.Drawing.Color]::White, [float]($size * 0.02))
    $g.DrawEllipse($hubPen, $hubRect)
    $hubPen.Dispose()

    $bmp.Save($path, [System.Drawing.Imaging.ImageFormat]::Png)
    $g.Dispose()
    $bmp.Dispose()
    Write-Output "Successfully generated $path ($size x $size)"
}

Create-AppIcon 192 'icon-192.png'
Create-AppIcon 512 'icon-512.png'
